# BookNest - Smart Library Management System

**College PBL (Project-Based Learning) Submission**  
- **Student Name:** Dhruv Munjal  
- **Roll Number / UID:** 24BCS10561  
- **Branch & Semester:** B.Tech Computer Science & Engineering (5th Semester)  
- **Technology:** Java (Servlets & JSP), MySQL, Apache Tomcat 9, JDBC, Bootstrap 5  

---

## 1. About the Project

**BookNest** is a web-based Library Management System that I built for my 5th-semester PBL project. 

In our college library, keeping manual register records for issued books, returns, and calculating late fines by hand is slow and can cause mistakes. I created BookNest to automate this entire process using a simple, standard **MVC (Model-View-Controller)** architecture in Java.

### Key Rules Implemented:
1. **Borrowing Limit:** A student can borrow at most **3 active books** at a time.
2. **Stock Tracking:** If a book has 0 available copies, it cannot be issued.
3. **Automatic Inventory Update:** Issuing a book decreases available copies by 1, and returning it increases available copies by 1.
4. **Loan Duration:** Standard loan period is **14 days**.
5. **Overdue Fine:** Automatically calculates a fine of **₹2 per day** after the due date.
6. **Data Integrity:** Database operations use JDBC transactions (`commit` and `rollback`) so counts never get corrupted.
7. **Security:** Passwords are encrypted using salted BCrypt hashing.

---

## 2. Technology Stack

- **Backend:** Java 17, Java Servlets (`javax.servlet` API for Tomcat 9), JDBC
- **Frontend:** JSP (JavaServer Pages), JSTL, HTML5, CSS3, Bootstrap 5, JavaScript
- **Database:** MySQL
- **Server:** Apache Tomcat 9
- **Build Tool:** Apache Maven
- **Password Hashing:** jBCrypt

---

## 3. Simple Project Structure

I kept the folder structure clean and simple without unnecessary enterprise nesting:

```
BookNest/
├── pom.xml                     # Maven dependencies
├── database.sql                # MySQL tables and sample data
├── .gitignore
├── README.md                   # Project documentation
├── VIVA_QUESTIONS.md           # 25+ viva questions & answers for viva defense
└── src/
    ├── main/
    │   ├── java/com/booknest/
    │   │   ├── model/          # JavaBeans (Book, Student, Admin, IssueRecord)
    │   │   ├── dao/            # JDBC database operations (BookDAO, StudentDAO, IssueDAO, AdminDAO)
    │   │   ├── servlet/        # Controllers (AuthServlet, DashboardServlet, BookServlet, StudentServlet, IssueServlet)
    │   │   └── util/           # DBConnection.java (connection + BCrypt + fines) & AuthFilter.java
    │   ├── resources/
    │   │   └── db.properties   # MySQL username & password config
    │   └── webapp/             # JSP Views directly accessible in webapp
    │       ├── index.jsp       # Redirects to /dashboard
    │       ├── login.jsp       # Login page with demo credentials
    │       ├── navbar.jsp      # Shared top navigation bar
    │       ├── dashboard.jsp   # Summary cards & recent activity
    │       ├── books.jsp       # Books catalog, search, add & edit modal
    │       ├── students.jsp    # Student roster, quota, add & edit modal
    │       ├── issues.jsp      # Issue checkout form & return modal with fine calculator
    │       ├── css/style.css   # Custom CSS
    │       └── js/script.js    # Modal handling & fine preview
    └── test/
        └── java/com/booknest/
            └── LibraryTest.java # Automated tests for all 7 business rules
```

---

## 4. How to Setup and Run

### Step 1: Import the Database in MySQL
1. Make sure your MySQL service is running.
2. Open terminal and run:
   ```bash
   mysql -u root -p < database.sql
   ```
   *(Enter your MySQL root password)*
3. Check `src/main/resources/db.properties` to ensure the username and password match your local MySQL settings (defaults to `root` / `root`).

### Step 2: Build the Project with Maven
Open terminal in the `BookNest` directory and run:
```bash
mvn clean package
```
This will compile the Java classes, run the automated tests in `LibraryTest.java`, and create `target/booknest.war`.

### Step 3: Run on Apache Tomcat 9
1. Copy the generated `target/booknest.war` to your Tomcat 9 `webapps` folder:
   ```bash
   cp target/booknest.war /path/to/tomcat9/webapps/
   ```
2. Start Tomcat:
   ```bash
   /path/to/tomcat9/bin/startup.sh
   ```
3. Open your browser and go to:
   ```
   http://localhost:8080/booknest/
   ```

---

## 5. Demo Admin Credentials

- **Username:** `admin`
- **Password:** `admin123`

*(The password is saved in `database.sql` as a BCrypt hash, verified by `DBConnection.checkPassword`)*

---

## 6. How the Application Works

1. **Login:** Admin logs in using `admin` / `admin123`. `AuthFilter` protects all other pages so nobody can open them without logging in first.
2. **Dashboard:** Displays total books, available books, active loans, students count, and overdue loans count.
3. **Books Tab:** Allows searching by title, author, or ISBN. New books can be added with title, author, category, and total copies.
4. **Students Tab:** Lists students with their active borrowing quota (e.g. `1 / 3 Active`). You can enroll new students with their Roll Number and department.
5. **Issue & Return Tab:**
   - **To Issue:** Select an available book and a student who has not reached the 3-book limit. The issue date and 14-day due date are set automatically.
   - **To Return:** Click "Return" on any active loan. A popup opens where you pick the return date. If it's returned after the due date, the system calculates the fine at ₹2/day (e.g., 5 days late = ₹10 fine).
