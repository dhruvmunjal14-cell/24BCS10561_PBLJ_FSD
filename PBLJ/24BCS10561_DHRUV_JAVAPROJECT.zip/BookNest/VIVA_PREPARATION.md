# BookNest – Viva Preparation Guide & Defense Reference

> **Tailored for 5th-Semester Computer Science PBL Viva & Practical Defense**  
> Everything you need to explain, demonstrate, and defend your Library Management System project with confidence.

---

## 1. Project Explanation in Simple Language

### What is BookNest?
BookNest is a web-based **Library Management System** built to automate and digitize manual library operations in educational institutions. 

In a traditional library, librarians maintain physical registers to record issued and returned books, manually count remaining copies, and mentally calculate overdue fines. This process is prone to human errors, lost records, duplicate book entries, and incorrect fine collections.

BookNest solves this by providing:
1. **Inventory Management:** Instant tracking of total vs. shelf-available physical book copies.
2. **Student Membership Tracking:** Fast student lookup with active borrowing limits (maximum 3 books).
3. **Automated Issue and Return Workflow:** Real-time stock decrement on issue, stock increment on return, and automated overdue penalty calculations (₹2/day beyond the standard 14-day loan).
4. **Administrative Security:** Session-based authentication with BCrypt password hashing.

---

## 2. Architecture Explanation

### 2.1 The MVC (Model-View-Controller) Pattern
BookNest is structured strictly according to the industry-standard **MVC** architectural pattern:

```
    [Browser Client]
           │
      HTTP Request
           ▼
    ┌──────────────┐
    │  CONTROLLER  │ ◄── Handles HTTP requests, extracts parameters,
    │  (Servlets)  │     validates inputs, coordinates business logic
    └──────┬───────┘
           │ Calls
           ▼
    ┌──────────────┐       ┌──────────────┐
    │     DAO      │ ◄───► │   DATABASE   │ Executes PreparedStatements &
    │ (JDBC Layer) │       │   (MySQL)    │ atomic transactions
    └──────┬───────┘       └──────────────┘
           │ Populates
           ▼
    ┌──────────────┐
    │    MODEL     │ ◄── Pure Java Beans (Admin, Book, Student, IssueRecord)
    │   (POJOs)    │     transporting data between layers
    └──────┬───────┘
           │ Forwards Data (request.setAttribute)
           ▼
    ┌──────────────┐
    │     VIEW     │ ◄── Renders dynamic HTML using JSTL and Bootstrap 5
    │ (JSP Pages)  │     returned to the client as an HTTP response
    └──────────────┘
```

1. **Model (`com.booknest.model`):**
   - Plain Old Java Objects (POJOs) that encapsulate domain entities (`Book`, `Student`, `Admin`, `IssueRecord`).
   - Contain attributes, constructors, getters, setters, and lightweight business helpers (e.g., `isOverdue()`, `getAvailabilityPercent()`).
2. **View (`src/main/webapp/WEB-INF/views/`):**
   - JavaServer Pages (JSP) combined with JSTL (JSP Standard Tag Library) and Bootstrap 5.
   - Kept in `WEB-INF/views/` so users cannot bypass servlets and access raw JSP files directly via URL.
3. **Controller (`com.booknest.controller`):**
   - Java Servlets extending `HttpServlet`.
   - Intercept requests, validate form inputs, invoke DAO operations, and forward responses to the appropriate JSP view using `RequestDispatcher.forward()`.

---

## 3. Database Table Explanations

The relational database `booknest` is in **3rd Normal Form (3NF)** with clear primary-foreign key relationships:

### 3.1 `admins`
Stores authenticated staff credentials.
- `admin_id` (INT, Primary Key, Auto Increment)
- `username` (VARCHAR(50), Unique, Not Null)
- `password_hash` (VARCHAR(255), Not Null) – 60-character BCrypt hash.
- `full_name` (VARCHAR(100), Not Null)
- `email` (VARCHAR(100), Unique, Not Null)
- `created_at` (TIMESTAMP)

### 3.2 `books`
Represents the catalog of physical books.
- `book_id` (INT, Primary Key, Auto Increment)
- `isbn` (VARCHAR(20), Unique, Not Null) – Standard book identifier.
- `title`, `author`, `category`, `publisher`, `publication_year`
- `total_copies` (INT, Not Null) – Total physical copies owned by the library.
- `available_copies` (INT, Not Null) – Copies currently sitting on shelves ready to issue.
- **Constraint:** `chk_copies CHECK (available_copies >= 0 AND available_copies <= total_copies)`.

### 3.3 `students`
Represents registered library patrons.
- `student_id` (INT, Primary Key, Auto Increment)
- `student_code` (VARCHAR(30), Unique, Not Null) – College Roll Number / Enrollment ID.
- `name`, `email`, `phone`, `department`, `semester`
- `created_at` (TIMESTAMP)

### 3.4 `issue_records`
Associative transaction table mapping book loans between `books` and `students`.
- `issue_id` (INT, Primary Key, Auto Increment)
- `book_id` (INT, Foreign Key referencing `books.book_id`)
- `student_id` (INT, Foreign Key referencing `students.student_id`)
- `issue_date` (DATE, Not Null)
- `due_date` (DATE, Not Null) – Defaults to `issue_date + 14 days`.
- `return_date` (DATE, Nullable) – Recorded when book is physically returned.
- `fine_amount` (DECIMAL(8,2), Default 0.00) – Overdue fine collected.
- `status` (ENUM('ISSUED', 'RETURNED'), Default 'ISSUED')
- `remarks` (VARCHAR(255))

---

## 4. Explanation of Important Java Classes

### 4.1 `AuthFilter.java` (`javax.servlet.Filter`)
- Acts as a security boundary before requests reach protected servlets (`/dashboard`, `/books/*`, `/students/*`, `/issues/*`).
- Checks `httpRequest.getSession(false)`. If no active session or `session.getAttribute("admin") == null`, it redirects the client to `/login?error=unauthorized`.
- Injects HTTP headers (`Cache-Control: no-cache, no-store, must-revalidate`) preventing users from clicking the browser's "Back" button to view cached protected pages after logging out.

### 4.2 `DBConnection.java` & `DatabaseConfig.java`
- Implements a centralized JDBC connection provider.
- Reads `db.properties` at runtime via `ClassLoader.getResourceAsStream("db.properties")`.
- Decouples database credentials from compiled bytecode.

### 4.3 `PasswordUtil.java`
- Uses **jBCrypt** to hash administrative passwords.
- BCrypt incorporates an internal cryptographic salt and an adaptive work factor (10 rounds), preventing rainbow table attacks and dictionary attacks.
- Provides `checkPassword(plain, hashed)` to verify candidate credentials safely.

### 4.4 `DateUtil.java`
- Encapsulates date arithmetic using Java 8 `java.time.LocalDate` and `java.time.temporal.ChronoUnit`.
- Enforces loan length: `DEFAULT_LOAN_DAYS = 14`.
- Computes overdue days: `ChronoUnit.DAYS.between(dueDate, returnDateOrToday)`.
- Calculates fine: `overdueDays * 2.00`.

---

## 5. Explanation of Servlets, JSP, JDBC, and MVC

### 5.1 What is a Servlet?
A Servlet is a Java class that runs inside a Web Container (like Apache Tomcat) to handle HTTP client requests and generate dynamic responses.
- **Lifecycle:**
  1. `init()`: Called once when the servlet is first instantiated.
  2. `service()` / `doGet()` / `doPost()`: Called concurrently for each incoming client request on a dedicated worker thread.
  3. `destroy()`: Called once when the servlet container shuts down.

### 5.2 What is a JSP?
JavaServer Pages (JSP) is a server-side template technology. When Tomcat receives a request for a JSP, it compiles the `.jsp` file into a standard Java Servlet class behind the scenes, executes it, and outputs raw HTML to the client browser.

### 5.3 What is JDBC and why use `PreparedStatement`?
JDBC (Java Database Connectivity) is the standard Java API to communicate with relational databases.
We use **`PreparedStatement`** instead of raw `Statement` because:
1. **Prevents SQL Injection:** Parameter placeholders (`?`) treat all user inputs as literal data rather than executable SQL commands.
2. **Pre-compiled Performance:** The SQL execution plan is parsed and compiled once by the DBMS engine, making repeated queries significantly faster.

---

## 6. Crucial SQL Queries in the Project

### 6.1 Counting Active Issued Books for Each Student (Left Outer Join + Group By)
Used on the Students screen to display each student's current active borrowings:
```sql
SELECT s.student_id, s.student_code, s.name, s.department, s.semester,
       COUNT(CASE WHEN ir.status = 'ISSUED' THEN 1 END) AS active_books
FROM students s
LEFT JOIN issue_records ir ON s.student_id = ir.student_id
GROUP BY s.student_id, s.student_code, s.name, s.department, s.semester;
```

### 6.2 Atomic Copy Decrement on Issue
Ensures a book copy cannot be issued if `available_copies` has already reached 0:
```sql
UPDATE books 
SET available_copies = available_copies - 1 
WHERE book_id = ? AND available_copies > 0;
```
*If this query returns `affectedRows == 0`, the application knows the book went out of stock and aborts the transaction.*

### 6.3 Overdue Books Query for Dashboard
Identifies active loans that have passed their due date:
```sql
SELECT ir.issue_id, b.title, s.name, ir.due_date,
       DATEDIFF(CURRENT_DATE, ir.due_date) AS overdue_days
FROM issue_records ir
JOIN books b ON ir.book_id = b.book_id
JOIN students s ON ir.student_id = s.student_id
WHERE ir.status = 'ISSUED' AND ir.due_date < CURRENT_DATE
ORDER BY ir.due_date ASC;
```

---

## 7. Step-by-Step Issue and Return Transaction Workflow

### Issue Workflow (Atomic Transaction):
```
1. Start Transaction: conn.setAutoCommit(false);
2. Check Student: Verify student exists and active_books < 3.
3. Decrement Inventory: UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ? AND available_copies > 0;
   -> If affected rows == 0: Throw Exception ("Out of stock").
4. Insert Transaction: INSERT INTO issue_records (book_id, student_id, issue_date, due_date, status) VALUES (?, ?, ?, ?, 'ISSUED');
5. Commit: conn.commit();
   -> If any error occurs: conn.rollback(); (Inventory remains intact!)
```

### Return Workflow (Atomic Transaction):
```
1. Start Transaction: conn.setAutoCommit(false);
2. Verify Record: SELECT status, due_date FROM issue_records WHERE issue_id = ?;
   -> If status == 'RETURNED': Throw Exception ("Cannot return twice").
3. Calculate Fine: If (returnDate > dueDate) Fine = (returnDate - dueDate) * ₹2.00; Else Fine = 0.00;
4. Update Transaction: UPDATE issue_records SET return_date = ?, fine_amount = ?, status = 'RETURNED' WHERE issue_id = ?;
5. Increment Inventory: UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?;
6. Commit: conn.commit();
   -> If any error occurs: conn.rollback();
```

---

## 8. 25+ Common Viva Questions & Model Answers

### Q1: What is the primary objective of BookNest?
**Answer:** BookNest is a smart library management system that automates book cataloging, student registrations, issue/return tracking, borrowing limits (max 3 books), and overdue fine calculations (₹2/day after 14 days).

### Q2: What architecture did you follow and why?
**Answer:** I followed the standard **MVC (Model-View-Controller)** pattern. It separates business logic (DAOs & Servlets) from data representation (Models) and UI rendering (JSP views), resulting in clean, maintainable, and loosely coupled code.

### Q3: Why did you choose Java Servlets and JSP instead of Spring Boot?
**Answer:** As a 5th-semester Computer Science student, building this project with pure Servlets and JSP allows me to demonstrate a core understanding of fundamental web concepts—HTTP request/response lifecycles, session tracking, filters, and raw JDBC—without relying on heavy abstraction frameworks.

### Q4: Why did you use `javax.servlet` instead of `jakarta.servlet`?
**Answer:** This project is targeted for **Apache Tomcat 9**, which implements the Java EE 8 specification where servlets reside in `javax.servlet`. `jakarta.servlet` was introduced in Tomcat 10 under Jakarta EE 9+.

### Q5: How do you prevent unauthorized users from accessing admin pages?
**Answer:** Through `AuthFilter`, a `javax.servlet.Filter`. It intercepts protected URL patterns (`/dashboard`, `/books/*`, `/students/*`, `/issues/*`). If the user does not have an active session with an authenticated `Admin` object, they are immediately redirected to `/login`.

### Q6: How do you handle password security in BookNest?
**Answer:** Passwords are never stored in plain text. We use the **BCrypt** hashing algorithm via the `jBCrypt` library. BCrypt incorporates a random 128-bit salt and an adaptive work factor (10 rounds) to defeat rainbow table attacks.

### Q7: What is the loan duration and fine rate in your project?
**Answer:** The standard loan period is **14 calendar days**. If a book is returned after the due date, a fine of **₹2.00 per overdue day** is automatically computed and applied.

### Q8: What happens if a student attempts to borrow a 4th book?
**Answer:** The business rule restricts students to a maximum of 3 active books. In `IssueDAO.issueBook()`, the application queries active borrowings (`status = 'ISSUED'`). If the count is 3 or more, an `IllegalStateException` is thrown, the transaction is aborted, and an error alert is shown in the UI.

### Q9: What happens if an admin attempts to issue a book with 0 available copies?
**Answer:** The application executes `UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ? AND available_copies > 0`. If copies are 0, zero rows are affected, triggering an exception that rejects the checkout.

### Q10: How do you maintain data consistency if an error occurs while issuing a book?
**Answer:** We use **JDBC Transactions**. We set `conn.setAutoCommit(false)` before executing queries. If either the book inventory decrement or the issue record insertion fails, we call `conn.rollback()` so neither change persists.

### Q11: What is the difference between `Statement` and `PreparedStatement`?
**Answer:** `Statement` compiles and executes raw SQL strings every time, making it vulnerable to SQL Injection. `PreparedStatement` pre-compiles parameterized SQL with `?` placeholders, ensuring secure parameter binding and faster repeated execution.

### Q12: How do you prevent SQL Injection in BookNest?
**Answer:** Every database operation across `AdminDAO`, `BookDAO`, `StudentDAO`, and `IssueDAO` exclusively uses parameterized `PreparedStatement`. User inputs are passed strictly as parameters (`setString`, `setInt`), never concatenated directly into SQL queries.

### Q13: What is the purpose of `web.xml`?
**Answer:** `web.xml` is the deployment descriptor of a Java web application. It defines application configurations, welcome files, session timeout intervals (30 minutes in BookNest), and optional servlet/filter mappings.

### Q14: Why are your JSP files stored in `WEB-INF/views/`?
**Answer:** Any file placed under `WEB-INF/` is inaccessible to direct URL requests from external web browsers. This forces every request to flow through the controller Servlets first, enforcing validation and authentication.

### Q15: How does HTTP Session tracking work?
**Answer:** HTTP is a stateless protocol. Tomcat maintains state by creating an `HttpSession` on the server and passing a unique session token (`JSESSIONID`) to the browser via an HTTP cookie. On subsequent requests, the browser sends this cookie, allowing Tomcat to retrieve the user's session data.

### Q16: How do you prevent browser back-button caching after logout?
**Answer:** In `AuthFilter`, we set HTTP response headers:
- `Cache-Control: no-cache, no-store, must-revalidate`
- `Pragma: no-cache`
- `Expires: 0`  
This forces the browser to request a fresh copy from the server instead of displaying cached pages from history.

### Q17: Can a book be returned twice?
**Answer:** No. In `IssueDAO.returnBook()`, we check the current transaction status. If the status is already `'RETURNED'`, the method throws an `IllegalStateException` and aborts.

### Q18: Can a book or student be deleted if active loans exist?
**Answer:** No. Both `BookDAO.deleteBook()` and `StudentDAO.deleteStudent()` check if any active records with `status = 'ISSUED'` exist. If so, deletion is blocked with a descriptive error message to preserve referential integrity.

### Q19: What database indexes did you create and why?
**Answer:** Indexes were created on `books(isbn)`, `books(title)`, `students(student_code)`, `issue_records(status)`, and `issue_records(due_date)`. These indexes accelerate search queries, duplicate constraint checks, and overdue book lookups from $O(N)$ table scans to $O(\log N)$ B-Tree lookups.

### Q20: How is the fine calculated if a book is returned before or on the due date?
**Answer:** In `DateUtil.calculateOverdueDays()`, we check if `targetDate.isAfter(dueDate)`. If it is not, overdue days return 0, and the fine evaluates to `₹0.00`.

### Q21: What is JSTL and why use it?
**Answer:** JSTL stands for JSP Standard Tag Library. It provides tags like `<c:forEach>`, `<c:if>`, and `<c:choose>`, allowing us to write clean logic in JSP without mixing messy Java scriptlets (`<% %>`).

### Q22: What happens if total copies of a book are edited?
**Answer:** In `BookDAO.updateBook()`, the system calculates currently issued copies (`total - available`). Total copies cannot be reduced below the number of currently borrowed copies. If valid, `new_available_copies = new_total_copies - issued_copies`.

### Q23: How do you configure MySQL credentials without changing Java code?
**Answer:** Database settings are externalized into `src/main/resources/db.properties`. `DatabaseConfig.java` reads this file using Java's `Properties` class at application startup.

### Q24: How did you test your project before deployment?
**Answer:** I created an automated test suite containing **19 unit and integration tests** using **JUnit 5** and an in-memory **H2 database** in MySQL mode. These tests verify all 9 core business rules without needing an external MySQL server running during compilation.

### Q25: How does Maven build this project?
**Answer:** Maven uses `pom.xml` to manage dependencies (Servlet API, MySQL Connector, jBCrypt, JUnit 5). Running `mvn package` compiles Java 17 bytecode, executes all 19 automated tests, and packages the web application into a deployable `booknest.war` archive.

### Q26: What are the demo credentials for the viva presentation?
**Answer:** The demo admin account is **Username:** `admin` and **Password:** `admin123`.
