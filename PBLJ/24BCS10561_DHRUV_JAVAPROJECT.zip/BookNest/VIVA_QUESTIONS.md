# BookNest - Viva Preparation & Common Questions

**Student Name:** Dhruv Munjal  
**Roll No / UID:** 24BCS10561  
**Project:** BookNest – Smart Library Management System (5th Sem PBL)

---

## 1. Quick Project Introduction (For Viva Opening)

> *"Good morning/afternoon, Sir/Ma'am. My project is BookNest, a web-based Library Management System developed using Java Servlets, JSP, JDBC, and MySQL. It follows the standard MVC architecture. I built this system to automate college library tasks like cataloging books, tracking student borrowings, managing book checkouts, enforcing a maximum limit of 3 books per student, and automatically computing late fines at ₹2 per day after a 14-day borrowing period."*

---

## 2. Project Architecture in Simple Words

In my project, I used the **MVC (Model-View-Controller)** pattern:

1. **Model:** Java classes in `com.booknest.model` (`Book.java`, `Student.java`, `IssueRecord.java`, `Admin.java`). They hold the data with standard getters and setters.
2. **View:** JSP files (`dashboard.jsp`, `books.jsp`, `students.jsp`, `issues.jsp`, `login.jsp`) that display the HTML interface using Bootstrap 5 and JSTL tags.
3. **Controller:** Servlets in `com.booknest.servlet` (`BookServlet`, `StudentServlet`, `IssueServlet`, `AuthServlet`, `DashboardServlet`). They receive user requests from forms, call the DAO methods, and send the data to the JSPs.
4. **DAO (Data Access Object):** Java classes in `com.booknest.dao` that write and execute the SQL queries using JDBC `PreparedStatement`.

---

## 3. Top 25 Viva Questions & Simple Answers

### Q1: Why did you choose Servlets and JSP instead of Spring Boot?
**Answer:** I wanted to understand the core working of Java web development first—how HTTP requests and responses work, how sessions are created, how JDBC interacts with the database, and how servlets forward data to JSP pages without depending on heavy framework magic.

### Q2: What is the role of `AuthFilter.java`?
**Answer:** It is a Servlet Filter that checks if an admin is logged in before letting anyone open protected pages like `/dashboard`, `/books`, `/students`, and `/issues`. If there is no active session, it redirects them to `/login`. It also sets cache headers so the browser back button doesn't show protected pages after logging out.

### Q3: How do you store passwords safely in the database?
**Answer:** I used the **BCrypt** hashing algorithm using the `jBCrypt` library. Instead of saving plain text passwords, it adds a random salt and hashes it with 10 rounds of encryption. Even if someone views the database, they cannot read the original password.

### Q4: How is the fine calculated?
**Answer:** The standard loan period is 14 days. If the student returns the book after the due date, the system calculates the number of days between the due date and the return date, and multiplies it by ₹2.00 per day. If returned on or before the due date, the fine is ₹0.00.

### Q5: How do you enforce the 3-book limit per student?
**Answer:** In `IssueDAO.java`, before issuing a book, the query `SELECT COUNT(*) FROM issue_records WHERE student_id = ? AND status = 'ISSUED'` runs. If the active count is 3 or more, the method throws an exception and stops the checkout.

### Q6: What happens if a book has 0 available copies?
**Answer:** The system executes `UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ? AND available_copies > 0`. If copies are 0, this update updates 0 rows, which triggers an error saying the book is out of stock.

### Q7: Why do you use JDBC Transactions in `IssueDAO`?
**Answer:** When issuing a book, two things must happen:
1. Reduce book copies by 1.
2. Insert a record into `issue_records`.  
I used `conn.setAutoCommit(false)`. If either step fails, `conn.rollback()` runs so the copy count never gets messed up. When both succeed, `conn.commit()` saves them together.

### Q8: What is the difference between `Statement` and `PreparedStatement`?
**Answer:** `Statement` runs raw SQL strings and is vulnerable to SQL injection attacks. `PreparedStatement` uses parameter placeholders (`?`), pre-compiles the query on the database, and prevents SQL injection because user inputs are treated strictly as data.

### Q9: Can a book be returned twice?
**Answer:** No. When returning a book, `IssueDAO.returnBook()` checks if the record's status is already `'RETURNED'`. If so, it rejects the action.

### Q10: Can a student be deleted if they currently have books issued?
**Answer:** No. In `StudentDAO.java`, before deleting, it checks if the student has any active unreturned books (`status = 'ISSUED'`). If yes, deletion is blocked to prevent lost library books.

### Q11: How do you prevent duplicate ISBNs and Roll Numbers?
**Answer:** At the database level, both `isbn` in the `books` table and `student_code` in the `students` table have `UNIQUE` constraints. In addition, the DAOs check for existing records before inserting.

### Q12: What is `HttpSession` and how is it used here?
**Answer:** HTTP is stateless. When an admin logs in, `request.getSession(true)` creates a session on Tomcat and stores the `Admin` object using `session.setAttribute("admin", admin)`. On subsequent requests, Tomcat identifies the user via the `JSESSIONID` cookie.

### Q13: What does `session.invalidate()` do?
**Answer:** When the admin clicks Logout, `session.invalidate()` destroys the active session on the server, removing all logged-in attributes.

### Q14: What is JSTL and why did you use it?
**Answer:** JSTL stands for JSP Standard Tag Library. It allows me to write loops (`<c:forEach>`) and conditional checks (`<c:if>`, `<c:choose>`) cleanly in JSP without writing messy Java scriptlet tags (`<% %>`).

### Q15: Why did you use `javax.servlet` instead of `jakarta.servlet`?
**Answer:** Because Apache Tomcat 9 uses the Java EE 8 specification, which uses the `javax.servlet` package. Tomcat 10 moved to `jakarta.servlet`.

### Q16: How do you connect to MySQL?
**Answer:** Through `DBConnection.java`. It loads MySQL's JDBC driver (`com.mysql.cj.jdbc.Driver`) and gets connections using `DriverManager.getConnection(url, user, password)` with parameters loaded from `db.properties`.

### Q17: Where are the database credentials configured?
**Answer:** Inside `src/main/resources/db.properties`. This keeps MySQL username and password outside the Java source code so anyone can change credentials without recompiling.

### Q18: What tables are there in your database?
**Answer:** 
1. `admins`: stores admin username, BCrypt password, and email.
2. `books`: stores book details, total copies, and available copies.
3. `students`: stores roll number, name, department, and contact.
4. `issue_records`: stores loan transactions, issue date, due date, return date, and fines.

### Q19: What indexes did you create in MySQL?
**Answer:** I created indexes on `books(isbn)`, `books(title)`, `students(student_code)`, and `issue_records(due_date)`. These speed up book search and overdue lookups.

### Q20: What is the relationship between `issue_records`, `books`, and `students`?
**Answer:** It is a Many-to-Many relationship between books and students. `issue_records` acts as the junction table containing foreign keys `book_id` (referencing `books`) and `student_id` (referencing `students`).

### Q21: What happens if total copies of a book are reduced during editing?
**Answer:** In `BookDAO.java`, the system calculates how many copies are currently issued (`total - available`). You cannot set total copies lower than the number of copies currently borrowed by students.

### Q22: How did you test your code?
**Answer:** I wrote automated tests in `src/test/java/com/booknest/LibraryTest.java` using JUnit 5. It runs against an in-memory H2 database in MySQL mode, verifying login, book adding, student enrollment, 3-book limit, out-of-stock check, and fine calculation.

### Q23: How do you run the Maven build?
**Answer:** In terminal, I run `mvn clean package`. It compiles all Java classes, executes the tests, and packages everything into `target/booknest.war`.

### Q24: How do you deploy the project on Tomcat?
**Answer:** I copy `target/booknest.war` to Tomcat's `webapps/` folder and start Tomcat with `./startup.sh`. Then I open `http://localhost:8080/booknest/`.

### Q25: What are the demo login credentials?
**Answer:** Username: `admin`, Password: `admin123`.

### Q26: What are some future improvements you could add to BookNest?
**Answer:** 
1. Adding automated email/SMS reminders before the 14-day due date.
2. Adding a student login portal where students can view their borrowed books.
3. Adding an online payment gateway (UPI/Razorpay) to pay overdue fines directly.
