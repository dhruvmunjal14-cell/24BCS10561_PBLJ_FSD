<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookNest - Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<jsp:include page="/navbar.jsp">
    <jsp:param name="page" value="books" />
</jsp:include>

<div class="container pb-5">

    <!-- Edit Book Form (Only appears when editing) -->
    <c:if test="${not empty editBook}">
        <div class="card mb-4 border-primary shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-pencil-square me-1"></i> Edit Book: ${editBook.title}</span>
                <a href="${pageContext.request.contextPath}/books" class="btn btn-sm btn-light">Cancel</a>
            </div>
            <div class="card-body">
                <form action="${pageContext.request.contextPath}/books" method="post">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="bookId" value="${editBook.bookId}">

                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">ISBN</label>
                            <input type="text" name="isbn" class="form-control" value="${editBook.isbn}" required>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">Book Title</label>
                            <input type="text" name="title" class="form-control" value="${editBook.title}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Author</label>
                            <input type="text" name="author" class="form-control" value="${editBook.author}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Category</label>
                            <input type="text" name="category" class="form-control" value="${editBook.category}">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">Publisher</label>
                            <input type="text" name="publisher" class="form-control" value="${editBook.publisher}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Total Copies</label>
                            <input type="number" name="copies" class="form-control" value="${editBook.totalCopies}" min="1" required>
                        </div>
                    </div>
                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-primary px-4">Update Book</button>
                    </div>
                </form>
            </div>
        </div>
    </c:if>

    <!-- Header Actions & Search -->
    <div class="card shadow-sm mb-4">
        <div class="card-body d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div>
                <h5 class="fw-bold mb-0">Library Books Catalog</h5>
                <small class="text-muted">Total: ${books.size()} books listed</small>
            </div>

            <div class="d-flex gap-2 w-100 w-md-auto">
                <!-- Search Form -->
                <form action="${pageContext.request.contextPath}/books" method="get" class="d-flex gap-1 flex-grow-1">
                    <input type="text" name="search" class="form-control form-control-sm"
                           placeholder="Search title, author, ISBN..." value="${searchQuery}">
                    <button class="btn btn-sm btn-outline-primary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                    <c:if test="${not empty searchQuery}">
                        <a href="${pageContext.request.contextPath}/books" class="btn btn-sm btn-outline-secondary">Reset</a>
                    </c:if>
                </form>

                <!-- Add Book Modal Trigger Button -->
                <button type="button" class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addBookModal">
                    <i class="bi bi-plus-lg me-1"></i> Add Book
                </button>
            </div>
        </div>
    </div>

    <!-- Books Table -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                    <tr>
                        <th>ISBN</th>
                        <th>Book Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th class="text-center">Available / Total</th>
                        <th class="text-center">Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty books}">
                            <c:forEach var="b" items="${books}">
                                <tr>
                                    <td><code>${b.isbn}</code></td>
                                    <td>
                                        <div class="fw-bold">${b.title}</div>
                                        <c:if test="${not empty b.publisher}">
                                            <small class="text-muted">${b.publisher}</small>
                                        </c:if>
                                    </td>
                                    <td>${b.author}</td>
                                    <td><span class="badge bg-light text-dark border">${b.category}</span></td>
                                    <td class="text-center">
                                        <strong>${b.availableCopies}</strong> / ${b.totalCopies}
                                    </td>
                                    <td class="text-center">
                                        <c:choose>
                                            <c:when test="${b.availableCopies > 0}">
                                                <span class="badge bg-success">In Stock</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-danger">Out of Stock</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="${pageContext.request.contextPath}/books?editId=${b.bookId}" class="btn btn-outline-primary" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="${pageContext.request.contextPath}/books?action=delete&id=${b.bookId}"
                                               class="btn btn-outline-danger"
                                               onclick="return confirm('Are you sure you want to delete this book?');"
                                               title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">No books found.</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Book Modal -->
<div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-6 fw-bold" id="addBookModalLabel">Add New Book</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/books" method="post">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">ISBN <span class="text-danger">*</span></label>
                        <input type="text" name="isbn" class="form-control" placeholder="e.g. 978-0132350884" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Book Title <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="e.g. Clean Code" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Author <span class="text-danger">*</span></label>
                        <input type="text" name="author" class="form-control" placeholder="e.g. Robert C. Martin" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Category</label>
                            <input type="text" name="category" class="form-control" placeholder="e.g. Software Engg">
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-semibold">Total Copies <span class="text-danger">*</span></label>
                            <input type="number" name="copies" class="form-control" min="1" value="1" required>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Publisher</label>
                        <input type="text" name="publisher" class="form-control" placeholder="e.g. Pearson">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary btn-sm">Save Book</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/js/script.js"></script>
</body>
</html>
