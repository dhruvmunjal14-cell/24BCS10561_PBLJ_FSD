// BookNest Scripts - Dhruv Munjal (24BCS10561)

document.addEventListener("DOMContentLoaded", function () {
    // Auto close alert notifications after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) bsAlert.close();
        }, 5000);
    });

    // Populate Return Book Modal
    const returnModal = document.getElementById("returnModal");
    if (returnModal) {
        returnModal.addEventListener("show.bs.modal", function (event) {
            const btn = event.relatedTarget;
            const issueId = btn.getAttribute("data-id");
            const bookTitle = btn.getAttribute("data-title");
            const student = btn.getAttribute("data-student");
            const dueDate = btn.getAttribute("data-due");

            document.getElementById("modalIssueId").value = issueId;
            document.getElementById("modalBookTitle").innerText = bookTitle;
            document.getElementById("modalStudent").innerText = student;
            document.getElementById("modalDueDate").innerText = dueDate;

            // Set today as default return date
            const today = new Date().toISOString().split("T")[0];
            const returnDateInput = document.getElementById("modalReturnDate");
            returnDateInput.value = today;

            calculateFinePreview(dueDate, returnDateInput.value);

            returnDateInput.onchange = function () {
                calculateFinePreview(dueDate, returnDateInput.value);
            };
        });
    }

    function calculateFinePreview(dueDateStr, returnDateStr) {
        const preview = document.getElementById("finePreview");
        if (!preview) return;

        const due = new Date(dueDateStr);
        const ret = new Date(returnDateStr);
        const diffMs = ret.getTime() - due.getTime();
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays > 0) {
            const fine = (diffDays * 2.0).toFixed(2);
            preview.className = "alert alert-warning py-2 mb-0 small";
            preview.innerHTML = "<strong>Overdue by " + diffDays + " day(s).</strong> Applicable Fine: <strong>Rs " + fine + "</strong> (Rs 2.00/day)";
        } else {
            preview.className = "alert alert-success py-2 mb-0 small";
            preview.innerHTML = "<strong>Returned on time.</strong> Fine: Rs 0.00";
        }
    }
});
