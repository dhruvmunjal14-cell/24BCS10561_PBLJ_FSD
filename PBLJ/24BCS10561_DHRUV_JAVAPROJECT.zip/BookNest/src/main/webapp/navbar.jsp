<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!-- Top Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="${pageContext.request.contextPath}/dashboard">
            <i class="bi bi-book-half fs-4"></i>
            <span>BookNest</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link ${param.page == 'dashboard' ? 'active fw-bold' : ''}" href="${pageContext.request.contextPath}/dashboard">
                        <i class="bi bi-grid-fill me-1"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${param.page == 'books' ? 'active fw-bold' : ''}" href="${pageContext.request.contextPath}/books">
                        <i class="bi bi-journal-bookmark-fill me-1"></i> Books
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${param.page == 'students' ? 'active fw-bold' : ''}" href="${pageContext.request.contextPath}/students">
                        <i class="bi bi-people-fill me-1"></i> Students
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link ${param.page == 'issues' ? 'active fw-bold' : ''}" href="${pageContext.request.contextPath}/issues">
                        <i class="bi bi-arrow-left-right me-1"></i> Issue &amp; Return
                    </a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <span class="text-white-50 small">
                    <i class="bi bi-person-circle text-white me-1"></i>
                    ${sessionScope.admin != null ? sessionScope.admin.fullName : 'Admin'}
                </span>
                <a href="${pageContext.request.contextPath}/logout" class="btn btn-sm btn-light text-danger fw-semibold">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<!-- Reusable Flash Notification Messages -->
<div class="container">
    <c:if test="${not empty sessionScope.msgSuccess}">
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> ${sessionScope.msgSuccess}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <c:remove var="msgSuccess" scope="session" />
    </c:if>

    <c:if test="${not empty sessionScope.msgError}">
        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> ${sessionScope.msgError}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <c:remove var="msgError" scope="session" />
    </c:if>
</div>
