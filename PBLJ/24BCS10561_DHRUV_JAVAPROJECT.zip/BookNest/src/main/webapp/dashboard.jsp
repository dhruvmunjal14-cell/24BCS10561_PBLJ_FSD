<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookNest - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<jsp:include page="/navbar.jsp">
    <jsp:param name="page" value="dashboard" />
</jsp:include>

<div class="container pb-5">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-1">Library Overview</h4>
            <p class="text-muted small mb-0">Welcome back, ${sessionScope.admin.fullName}!</p>
        </div>
        <div>
            <a href="${pageContext.request.contextPath}/issues" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-circle me-1"></i> Issue a Book
            </a>
        </div>
    </div>

    <!-- Overdue Alert Notice -->
    <c:if test="${overdueBooks > 0}">
        <div class="alert alert-warning d-flex align-items-center justify-content-between p-3 mb-4 rounded shadow-sm">
            <div>
                <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                <strong>Notice:</strong> There are <strong>${overdueBooks}</strong> overdue book loans that need attention (Fine: Rs 2.00/day).
            </div>
            <a href="${pageContext.request.contextPath}/issues?filter=OVERDUE" class="btn btn-sm btn-outline-dark">
                View Overdue
            </a>
        </div>
    </c:if>

    <!-- Stat Cards -->
    <div class="row g-3 mb-4">
        <div class="col-md-4 col-lg">
            <div class="stat-card border-start border-4 border-primary">
                <div class="stat-number text-primary">${totalBooks}</div>
                <div class="stat-title">Total Books</div>
            </div>
        </div>
        <div class="col-md-4 col-lg">
            <div class="stat-card border-start border-4 border-success">
                <div class="stat-number text-success">${availableBooks}</div>
                <div class="stat-title">Available Books</div>
            </div>
        </div>
        <div class="col-md-4 col-lg">
            <div class="stat-card border-start border-4 border-warning">
                <div class="stat-number text-warning">${issuedBooks}</div>
                <div class="stat-title">Issued Books</div>
            </div>
        </div>
        <div class="col-md-6 col-lg">
            <div class="stat-card border-start border-4 border-info">
                <div class="stat-number text-info">${totalStudents}</div>
                <div class="stat-title">Total Students</div>
            </div>
        </div>
        <div class="col-md-6 col-lg">
            <div class="stat-card border-start border-4 border-danger">
                <div class="stat-number text-danger">${overdueBooks}</div>
                <div class="stat-title">Overdue Books</div>
            </div>
        </div>
    </div>

    <!-- Recent Activity Table -->
    <div class="card mb-4 shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="bi bi-clock-history text-primary me-2"></i> Recent Transactions</span>
            <a href="${pageContext.request.contextPath}/issues" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                    <tr>
                        <th>Book Title</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty recentIssues}">
                            <c:forEach var="item" items="${recentIssues}">
                                <tr>
                                    <td>
                                        <div class="fw-semibold">${item.bookTitle}</div>
                                        <small class="text-muted">ISBN: ${item.bookIsbn}</small>
                                    </td>
                                    <td>
                                        <div>${item.studentName}</div>
                                        <small class="text-muted">${item.studentCode}</small>
                                    </td>
                                    <td>${item.formattedIssueDate}</td>
                                    <td>${item.formattedDueDate}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${item.status == 'RETURNED'}">
                                                <span class="badge bg-success">Returned</span>
                                            </c:when>
                                            <c:when test="${item.overdue}">
                                                <span class="badge bg-danger">Overdue (${item.overdueDays}d)</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-primary">Issued</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">No transactions recorded yet.</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Quick Rules Card -->
    <div class="card bg-light p-3">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h6 class="fw-bold mb-1"><i class="bi bi-info-circle text-primary me-1"></i> Library Rules</h6>
                <p class="text-muted small mb-0">
                    Max 3 active books per student &bull; Standard borrowing duration: 14 days &bull; Overdue fine: Rs 2.00 per day after due date.
                </p>
            </div>
            <div class="col-md-4 text-md-end mt-2 mt-md-0">
                <span class="badge bg-secondary p-2">PBL Project - Java &amp; MySQL</span>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/js/script.js"></script>
</body>
</html>
