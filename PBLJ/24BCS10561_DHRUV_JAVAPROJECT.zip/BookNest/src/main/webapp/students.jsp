<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookNest - Students</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<jsp:include page="/navbar.jsp">
    <jsp:param name="page" value="students" />
</jsp:include>

<div class="container pb-5">

    <!-- Edit Student Card (Only appears when editing) -->
    <c:if test="${not empty editStudent}">
        <div class="card mb-4 border-primary shadow-sm">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-pencil-square me-1"></i> Edit Student: ${editStudent.name}</span>
                <a href="${pageContext.request.contextPath}/students" class="btn btn-sm btn-light">Cancel</a>
            </div>
            <div class="card-body">
                <form action="${pageContext.request.contextPath}/students" method="post">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="studentId" value="${editStudent.studentId}">

                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Student ID / Roll No</label>
                            <input type="text" name="studentCode" class="form-control" value="${editStudent.studentCode}" required>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">Full Name</label>
                            <input type="text" name="name" class="form-control" value="${editStudent.name}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" value="${editStudent.email}" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Phone</label>
                            <input type="tel" name="phone" class="form-control" value="${editStudent.phone}">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold">Department</label>
                            <input type="text" name="department" class="form-control" value="${editStudent.department}" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Semester</label>
                            <select name="semester" class="form-select">
                                <c:forEach var="s" begin="1" end="8">
                                    <option value="${s}" ${editStudent.semester == s ? 'selected' : ''}>Semester ${s}</option>
                                </c:forEach>
                            </select>
                        </div>
                    </div>
                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-primary px-4">Update Student</button>
                    </div>
                </form>
            </div>
        </div>
    </c:if>

    <!-- Header Actions & Search -->
    <div class="card shadow-sm mb-4">
        <div class="card-body d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div>
                <h5 class="fw-bold mb-0">Registered Students</h5>
                <small class="text-muted">Total: ${students.size()} members enrolled</small>
            </div>

            <div class="d-flex gap-2 w-100 w-md-auto">
                <!-- Search Form -->
                <form action="${pageContext.request.contextPath}/students" method="get" class="d-flex gap-1 flex-grow-1">
                    <input type="text" name="search" class="form-control form-control-sm"
                           placeholder="Search name, roll no, dept..." value="${searchQuery}">
                    <button class="btn btn-sm btn-outline-primary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                    <c:if test="${not empty searchQuery}">
                        <a href="${pageContext.request.contextPath}/students" class="btn btn-sm btn-outline-secondary">Reset</a>
                    </c:if>
                </form>

                <!-- Add Student Modal Trigger Button -->
                <button type="button" class="btn btn-primary btn-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                    <i class="bi bi-person-plus me-1"></i> Add Student
                </button>
            </div>
        </div>
    </div>

    <!-- Students Table -->
    <div class="card shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                    <tr>
                        <th>Roll No / ID</th>
                        <th>Student Name</th>
                        <th>Department</th>
                        <th>Semester</th>
                        <th>Contact</th>
                        <th class="text-center">Issued Books</th>
                        <th class="text-end">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty students}">
                            <c:forEach var="s" items="${students}">
                                <tr>
                                    <td><code>${s.studentCode}</code></td>
                                    <td><strong>${s.name}</strong></td>
                                    <td>${s.department}</td>
                                    <td>Sem ${s.semester}</td>
                                    <td>
                                        <div class="small">${s.email}</div>
                                        <div class="small text-muted">${s.phone}</div>
                                    </td>
                                    <td class="text-center">
                                        <c:choose>
                                            <c:when test="${s.activeIssuedBooksCount >= 3}">
                                                <span class="badge bg-danger">3 / 3 (Limit Reached)</span>
                                            </c:when>
                                            <c:when test="${s.activeIssuedBooksCount > 0}">
                                                <span class="badge bg-warning text-dark">${s.activeIssuedBooksCount} / 3 Active</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-success">0 / 3 Active</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="${pageContext.request.contextPath}/students?editId=${s.studentId}" class="btn btn-outline-primary" title="Edit">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <a href="${pageContext.request.contextPath}/students?action=delete&id=${s.studentId}"
                                               class="btn btn-outline-danger"
                                               onclick="return confirm('Are you sure you want to delete this student?');"
                                               title="Delete">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">No students found.</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-6 fw-bold" id="addStudentModalLabel">Register Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/students" method="post">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Student ID / Roll No <span class="text-danger">*</span></label>
                        <input type="text" name="studentCode" class="form-control" placeholder="e.g. 24BCS10561" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Dhruv Munjal" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Email Address <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" placeholder="e.g. dhruv@college.edu" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Phone Number</label>
                        <input type="tel" name="phone" class="form-control" placeholder="e.g. 9876543210">
                    </div>
                    <div class="row g-2">
                        <div class="col-8">
                            <label class="form-label small fw-semibold">Department <span class="text-danger">*</span></label>
                            <input type="text" name="department" class="form-control" placeholder="e.g. Computer Science" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label small fw-semibold">Semester <span class="text-danger">*</span></label>
                            <select name="semester" class="form-select">
                                <c:forEach var="s" begin="1" end="8">
                                    <option value="${s}" ${s == 5 ? 'selected' : ''}>Sem ${s}</option>
                                </c:forEach>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary btn-sm">Register Student</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/js/script.js"></script>
</body>
</html>
