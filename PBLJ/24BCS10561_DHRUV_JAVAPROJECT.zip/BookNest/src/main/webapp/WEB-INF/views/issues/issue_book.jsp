<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Issue a Book" scope="request" />
<c:set var="activePage" value="issues" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="bn-card">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-box-arrow-up-right text-primary"></i> Issue Book to Student
                </h5>
                <a href="${pageContext.request.contextPath}/issues" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to History
                </a>
            </div>

            <div class="bn-card-body">
                <!-- Policy Notice -->
                <div class="alert alert-light border d-flex align-items-center gap-2 p-3 mb-4 rounded-3 small text-secondary">
                    <i class="bi bi-shield-check text-primary fs-5"></i>
                    <div>
                        <strong>Rules Enforced:</strong> Max <strong>3 active books</strong> per student &bull;
                        Standard Loan: <strong>14 days</strong> &bull; Overdue Fine: <strong>₹2.00/day</strong>.
                    </div>
                </div>

                <form action="${pageContext.request.contextPath}/issues" method="post" autocomplete="off">
                    <input type="hidden" name="action" value="issue">

                    <div class="row g-3">
                        <!-- Select Book -->
                        <div class="col-12">
                            <label for="bookSelect" class="form-label fw-semibold small">
                                Select Book <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="bookSelect" name="bookId" required>
                                <option value="">-- Choose an Available Book --</option>
                                <c:forEach var="b" items="${books}">
                                    <option value="${b.bookId}" ${selectedBookId == b.bookId ? 'selected' : ''}>
                                        ${b.title} &bull; by ${b.author} (ISBN: ${b.isbn}) [${b.availableCopies} available]
                                    </option>
                                </c:forEach>
                            </select>
                            <c:if test="${empty books}">
                                <div class="form-text text-danger">No books are currently in stock to issue.</div>
                            </c:if>
                        </div>

                        <!-- Select Student -->
                        <div class="col-12">
                            <label for="studentSelect" class="form-label fw-semibold small">
                                Select Student <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" id="studentSelect" name="studentId" required>
                                <option value="">-- Choose a Registered Student --</option>
                                <c:forEach var="s" items="${students}">
                                    <option value="${s.studentId}"
                                            data-active="${s.activeIssuedBooksCount}"
                                            ${selectedStudentId == s.studentId ? 'selected' : ''}
                                            ${s.activeIssuedBooksCount >= 3 ? 'disabled' : ''}>
                                        ${s.name} (${s.studentCode}) &bull; ${s.department}
                                        <c:choose>
                                            <c:when test="${s.activeIssuedBooksCount >= 3}">
                                                [MAX LIMIT REACHED - 3 BOOKS ACTIVE]
                                            </c:when>
                                            <c:otherwise>
                                                [${s.activeIssuedBooksCount}/3 Active Books]
                                            </c:otherwise>
                                        </c:choose>
                                    </option>
                                </c:forEach>
                            </select>
                            <div id="studentQuotaBadge" class="badge bg-light text-dark border mt-1">
                                Select a student to verify their active borrowing quota.
                            </div>
                        </div>

                        <!-- Issue Date -->
                        <div class="col-md-6">
                            <label for="issueDate" class="form-label fw-semibold small">
                                Issue Date <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control" id="issueDate" name="issueDate"
                                   value="${todayDate}" required>
                        </div>

                        <!-- Due Date -->
                        <div class="col-md-6">
                            <label for="dueDate" class="form-label fw-semibold small">
                                Due Date (14 Days Loan) <span class="text-danger">*</span>
                            </label>
                            <input type="date" class="form-control" id="dueDate" name="dueDate"
                                   value="${defaultDueDate}" required>
                            <div class="form-text">Defaults to 14 days from issue date.</div>
                        </div>

                        <!-- Remarks -->
                        <div class="col-12">
                            <label for="remarks" class="form-label fw-semibold small">Remarks / Notes (Optional)</label>
                            <input type="text" class="form-control" id="remarks" name="remarks"
                                   placeholder="e.g. For semester PBL research project">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="${pageContext.request.contextPath}/issues" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check2-circle me-1"></i> Issue Book
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
