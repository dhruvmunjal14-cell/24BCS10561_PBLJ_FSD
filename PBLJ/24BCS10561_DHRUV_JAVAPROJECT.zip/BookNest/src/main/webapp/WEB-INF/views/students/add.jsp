<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Register Student" scope="request" />
<c:set var="activePage" value="students" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="bn-card">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-person-plus text-primary"></i> Register New Student
                </h5>
                <a href="${pageContext.request.contextPath}/students" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Students
                </a>
            </div>

            <div class="bn-card-body">
                <form action="${pageContext.request.contextPath}/students" method="post" autocomplete="off">
                    <input type="hidden" name="action" value="insert">

                    <div class="row g-3">
                        <!-- Student Code / Roll No -->
                        <div class="col-md-6">
                            <label for="studentCode" class="form-label fw-semibold small">Student ID / Roll No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="studentCode" name="studentCode"
                                   placeholder="e.g. CS2023001" value="${form_studentCode}" required>
                            <div class="form-text">Must be unique (e.g. College Enrollment ID).</div>
                        </div>

                        <!-- Name -->
                        <div class="col-md-6">
                            <label for="name" class="form-label fw-semibold small">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name"
                                   placeholder="e.g. Dhruv Munjal" value="${form_name}" required>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6">
                            <label for="email" class="form-label fw-semibold small">Email Address <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email"
                                   placeholder="e.g. student@college.edu" value="${form_email}" required>
                        </div>

                        <!-- Phone -->
                        <div class="col-md-6">
                            <label for="phone" class="form-label fw-semibold small">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone"
                                   placeholder="e.g. 9876543210" value="${form_phone}">
                        </div>

                        <!-- Department -->
                        <div class="col-md-6">
                            <label for="department" class="form-label fw-semibold small">Department <span class="text-danger">*</span></label>
                            <select class="form-select" id="department" name="department" required>
                                <option value="Computer Science & Engineering" ${form_department == 'Computer Science & Engineering' ? 'selected' : ''}>Computer Science &amp; Engineering</option>
                                <option value="Information Technology" ${form_department == 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                                <option value="Electronics & Communication" ${form_department == 'Electronics & Communication' ? 'selected' : ''}>Electronics &amp; Communication</option>
                                <option value="Mechanical Engineering" ${form_department == 'Mechanical Engineering' ? 'selected' : ''}>Mechanical Engineering</option>
                                <option value="Civil Engineering" ${form_department == 'Civil Engineering' ? 'selected' : ''}>Civil Engineering</option>
                            </select>
                        </div>

                        <!-- Semester -->
                        <div class="col-md-6">
                            <label for="semester" class="form-label fw-semibold small">Current Semester <span class="text-danger">*</span></label>
                            <select class="form-select" id="semester" name="semester" required>
                                <c:forEach var="s" begin="1" end="8">
                                    <option value="${s}" ${form_semester == s ? 'selected' : (empty form_semester && s == 5 ? 'selected' : '')}>
                                        Semester ${s}
                                    </option>
                                </c:forEach>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="${pageContext.request.contextPath}/students" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check2-circle me-1"></i> Register Student
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
