<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Book Management" scope="request" />
<c:set var="activePage" value="books" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="bn-card">
    <div class="bn-card-header flex-column flex-md-row gap-3">
        <div class="d-flex align-items-center gap-2">
            <h5 class="bn-card-title mb-0">
                <i class="bi bi-journal-bookmark-fill text-primary"></i> Library Books
            </h5>
            <span class="badge bg-secondary rounded-pill">${books.size()} Books</span>
        </div>

        <div class="d-flex align-items-center gap-2 w-100 w-md-auto">
            <!-- Search Form -->
            <form action="${pageContext.request.contextPath}/books" method="get" class="d-flex gap-2 flex-grow-1">
                <div class="input-group input-group-sm">
                    <input type="text" name="search" class="form-control"
                           placeholder="Search title, author, ISBN..." value="${searchQuery}">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                    <c:if test="${not empty searchQuery}">
                        <a href="${pageContext.request.contextPath}/books" class="btn btn-outline-secondary">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    </c:if>
                </div>
            </form>

            <a href="${pageContext.request.contextPath}/books?action=new" class="btn btn-sm btn-primary text-nowrap">
                <i class="bi bi-plus-lg me-1"></i> Add Book
            </a>
        </div>
    </div>

    <div class="bn-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                <tr>
                    <th>ISBN</th>
                    <th>Book Details</th>
                    <th>Author</th>
                    <th>Category</th>
                    <th class="text-center">Stock (Avail / Total)</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Actions</th>
                </tr>
                </thead>
                <tbody>
                <c:choose>
                    <c:when test="${not empty books}">
                        <c:forEach var="book" items="${books}">
                            <tr>
                                <td>
                                    <code class="text-secondary fw-semibold">${book.isbn}</code>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark">${book.title}</div>
                                    <c:if test="${not empty book.publisher}">
                                        <small class="text-muted">${book.publisher} <c:if test="${not empty book.publicationYear}">(${book.publicationYear})</c:if></small>
                                    </c:if>
                                </td>
                                <td>${book.author}</td>
                                <td>
                                    <span class="badge bg-light text-dark border">${book.category}</span>
                                </td>
                                <td class="text-center">
                                    <span class="fw-bold text-primary">${book.availableCopies}</span>
                                    <span class="text-muted">/ ${book.totalCopies}</span>
                                </td>
                                <td class="text-center">
                                    <c:choose>
                                        <c:when test="${book.availableCopies > 0}">
                                            <span class="badge badge-soft-success">In Stock</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-soft-danger">Out of Stock</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <c:if test="${book.availableCopies > 0}">
                                            <a href="${pageContext.request.contextPath}/issues?action=new&bookId=${book.bookId}"
                                               class="btn btn-outline-success" title="Quick Issue">
                                                <i class="bi bi-box-arrow-up-right"></i> Issue
                                            </a>
                                        </c:if>
                                        <a href="${pageContext.request.contextPath}/books?action=edit&id=${book.bookId}"
                                           class="btn btn-outline-primary" title="Edit Book">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="${pageContext.request.contextPath}/books?action=delete&id=${book.bookId}"
                                           class="btn btn-outline-danger btn-delete-confirm"
                                           data-name="${book.title}" title="Delete Book">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-journal-x fs-1 d-block mb-2 text-secondary"></i>
                                No books found matching your criteria.
                            </td>
                        </tr>
                    </c:otherwise>
                </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
