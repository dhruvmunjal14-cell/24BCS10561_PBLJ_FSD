<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Issue & Return Management" scope="request" />
<c:set var="activePage" value="issues" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="bn-card">
    <div class="bn-card-header flex-column flex-md-row gap-3">
        <!-- Filter Tabs -->
        <ul class="nav nav-pills small gap-1">
            <li class="nav-item">
                <a class="nav-link ${currentFilter == 'ALL' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/issues?filter=ALL">All Records</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${currentFilter == 'ISSUED' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/issues?filter=ISSUED">Currently Issued</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${currentFilter == 'OVERDUE' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/issues?filter=OVERDUE">
                    Overdue Only
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${currentFilter == 'RETURNED' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/issues?filter=RETURNED">Returned History</a>
            </li>
        </ul>

        <a href="${pageContext.request.contextPath}/issues?action=new" class="btn btn-sm btn-primary text-nowrap">
            <i class="bi bi-plus-lg me-1"></i> Issue New Book
        </a>
    </div>

    <div class="bn-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                <tr>
                    <th>Trx ID</th>
                    <th>Book Details</th>
                    <th>Student Details</th>
                    <th>Issue Date</th>
                    <th>Due Date</th>
                    <th>Return Date</th>
                    <th>Fine / Status</th>
                    <th class="text-end">Action</th>
                </tr>
                </thead>
                <tbody>
                <c:choose>
                    <c:when test="${not empty issues}">
                        <c:forEach var="item" items="${issues}">
                            <tr>
                                <td>
                                    <code class="text-secondary fw-semibold">#${item.issueId}</code>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark text-truncate" style="max-width: 200px;" title="${item.bookTitle}">
                                        ${item.bookTitle}
                                    </div>
                                    <small class="text-muted">ISBN: ${item.bookIsbn}</small>
                                </td>
                                <td>
                                    <div class="fw-semibold text-dark">${item.studentName}</div>
                                    <small class="text-muted">${item.studentCode} &bull; ${item.studentDepartment}</small>
                                </td>
                                <td>${item.formattedIssueDate}</td>
                                <td>
                                    <span class="${item.overdue ? 'text-danger fw-bold' : ''}">
                                        ${item.formattedDueDate}
                                    </span>
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${not empty item.returnDate}">
                                            ${item.formattedReturnDate}
                                        </c:when>
                                        <c:otherwise>
                                            <span class="text-muted">-</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td>
                                    <c:choose>
                                        <c:when test="${item.status == 'RETURNED'}">
                                            <span class="badge badge-soft-success mb-1">Returned</span>
                                            <c:if test="${item.fineAmount > 0}">
                                                <div class="small text-danger fw-semibold">Fine: ₹${item.fineAmount}</div>
                                            </c:if>
                                        </c:when>
                                        <c:when test="${item.overdue}">
                                            <span class="badge badge-soft-danger mb-1">Overdue (${item.overdueDays}d)</span>
                                            <div class="small text-danger fw-bold">Fine: ₹${item.computedFine}</div>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-soft-primary">Issued (Active)</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="text-end">
                                    <c:if test="${item.status == 'ISSUED'}">
                                        <button type="button" class="btn btn-sm btn-outline-success"
                                                data-bs-toggle="modal" data-bs-target="#returnModal"
                                                data-issue-id="${item.issueId}"
                                                data-book-title="${item.bookTitle}"
                                                data-student-name="${item.studentName}"
                                                data-due-date="${item.dueDate}">
                                            <i class="bi bi-box-arrow-in-down-left me-1"></i> Return
                                        </button>
                                    </c:if>
                                    <c:if test="${item.status == 'RETURNED'}">
                                        <span class="text-muted small"><i class="bi bi-check2-all text-success"></i> Completed</span>
                                    </c:if>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <tr>
                            <td colspan="8" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
                                No records found for this filter.
                            </td>
                        </tr>
                    </c:otherwise>
                </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Return Book Modal -->
<div class="modal fade" id="returnModal" tabindex="-1" aria-labelledby="returnModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-light">
                <h5 class="modal-title fs-6 fw-bold" id="returnModalLabel">
                    <i class="bi bi-arrow-return-left text-success me-1"></i> Return Book Confirmation
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="${pageContext.request.contextPath}/issues" method="post">
                <input type="hidden" name="action" value="return">
                <input type="hidden" name="issueId" id="modalIssueId">

                <div class="modal-body p-4">
                    <div class="mb-3">
                        <div class="text-muted small">Book Title</div>
                        <div class="fw-bold fs-6 text-dark" id="modalBookTitle">-</div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <div class="text-muted small">Borrowed By</div>
                            <div class="fw-semibold text-dark" id="modalStudentName">-</div>
                        </div>
                        <div class="col-6">
                            <div class="text-muted small">Scheduled Due Date</div>
                            <div class="fw-semibold text-dark" id="modalDueDate">-</div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="modalReturnDate" class="form-label fw-semibold small">Actual Return Date</label>
                        <input type="date" class="form-control" id="modalReturnDate" name="returnDate" required>
                    </div>

                    <!-- Dynamic Fine Preview Alert -->
                    <div class="mb-3">
                        <div id="modalFineBadge" class="alert alert-secondary py-2 mb-0 small">
                            Select date to calculate fine.
                        </div>
                    </div>

                    <div class="mb-1">
                        <label for="modalRemarks" class="form-label fw-semibold small">Return Remarks / Condition</label>
                        <input type="text" class="form-control" id="modalRemarks" name="remarks"
                               placeholder="e.g. Good condition / Fine collected">
                    </div>
                </div>

                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success px-4">
                        <i class="bi bi-check2-circle me-1"></i> Confirm Return
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
