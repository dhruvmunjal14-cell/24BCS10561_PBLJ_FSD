<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Add New Book" scope="request" />
<c:set var="activePage" value="books" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="bn-card">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-plus-circle text-primary"></i> Register New Book
                </h5>
                <a href="${pageContext.request.contextPath}/books" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Books
                </a>
            </div>

            <div class="bn-card-body">
                <form action="${pageContext.request.contextPath}/books" method="post" autocomplete="off">
                    <input type="hidden" name="action" value="insert">

                    <div class="row g-3">
                        <!-- ISBN -->
                        <div class="col-md-6">
                            <label for="isbn" class="form-label fw-semibold small">ISBN <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="isbn" name="isbn"
                                   placeholder="e.g. 978-0132350884" value="${form_isbn}" required>
                            <div class="form-text">Must be unique across the library inventory.</div>
                        </div>

                        <!-- Title -->
                        <div class="col-md-6">
                            <label for="title" class="form-label fw-semibold small">Book Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title"
                                   placeholder="e.g. Clean Code: A Handbook of Agile Software Craftsmanship" value="${form_title}" required>
                        </div>

                        <!-- Author -->
                        <div class="col-md-6">
                            <label for="author" class="form-label fw-semibold small">Author(s) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="author" name="author"
                                   placeholder="e.g. Robert C. Martin" value="${form_author}" required>
                        </div>

                        <!-- Category -->
                        <div class="col-md-6">
                            <label for="category" class="form-label fw-semibold small">Category / Genre</label>
                            <select class="form-select" id="category" name="category">
                                <option value="Computer Science" ${form_category == 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                                <option value="Software Engineering" ${form_category == 'Software Engineering' ? 'selected' : ''}>Software Engineering</option>
                                <option value="Data Structures" ${form_category == 'Data Structures' ? 'selected' : ''}>Data Structures &amp; Algorithms</option>
                                <option value="Database Systems" ${form_category == 'Database Systems' ? 'selected' : ''}>Database Systems</option>
                                <option value="Computer Networks" ${form_category == 'Computer Networks' ? 'selected' : ''}>Computer Networks</option>
                                <option value="Operating Systems" ${form_category == 'Operating Systems' ? 'selected' : ''}>Operating Systems</option>
                                <option value="Artificial Intelligence" ${form_category == 'Artificial Intelligence' ? 'selected' : ''}>Artificial Intelligence</option>
                                <option value="General Engineering" ${form_category == 'General Engineering' ? 'selected' : ''}>General Engineering</option>
                            </select>
                        </div>

                        <!-- Publisher -->
                        <div class="col-md-6">
                            <label for="publisher" class="form-label fw-semibold small">Publisher</label>
                            <input type="text" class="form-control" id="publisher" name="publisher"
                                   placeholder="e.g. Prentice Hall" value="${form_publisher}">
                        </div>

                        <!-- Publication Year -->
                        <div class="col-md-3">
                            <label for="publicationYear" class="form-label fw-semibold small">Year</label>
                            <input type="number" class="form-control" id="publicationYear" name="publicationYear"
                                   placeholder="e.g. 2008" min="1900" max="2099" value="${form_year}">
                        </div>

                        <!-- Total Copies -->
                        <div class="col-md-3">
                            <label for="totalCopies" class="form-label fw-semibold small">Total Copies <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="totalCopies" name="totalCopies"
                                   min="1" value="${not empty form_copies ? form_copies : '1'}" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="${pageContext.request.contextPath}/books" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check2-circle me-1"></i> Save Book
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
