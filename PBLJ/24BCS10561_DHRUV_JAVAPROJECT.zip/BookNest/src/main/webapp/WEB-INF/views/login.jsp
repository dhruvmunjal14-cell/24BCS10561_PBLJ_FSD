<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookNest – Admin Login</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/static/css/style.css">
</head>
<body class="login-page">

<div class="login-card">
    <div class="text-center">
        <div class="login-logo">
            <i class="bi bi-book-half"></i>
        </div>
        <h3 class="fw-bold mb-1 text-dark">BookNest</h3>
        <p class="text-muted small mb-4">Smart Library Management System</p>
    </div>

    <!-- Error/Success Alerts -->
    <c:if test="${not empty errorMessage}">
        <div class="alert alert-danger py-2 small mb-3 alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-circle-fill me-1"></i>
            <c:out value="${errorMessage}" />
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <c:if test="${not empty successMessage}">
        <div class="alert alert-success py-2 small mb-3 alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-1"></i>
            <c:out value="${successMessage}" />
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </c:if>

    <form action="${pageContext.request.contextPath}/login" method="post" autocomplete="off">
        <div class="mb-3">
            <label for="username" class="form-label fw-semibold small text-secondary">Username</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-muted"></i></span>
                <input type="text" class="form-control border-start-0" id="username" name="username"
                       placeholder="Enter admin username" value="${username}" required autofocus>
            </div>
        </div>

        <div class="mb-4">
            <label for="password" class="form-label fw-semibold small text-secondary">Password</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-muted"></i></span>
                <input type="password" class="form-control border-start-0" id="password" name="password"
                       placeholder="Enter admin password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
            <i class="bi bi-box-arrow-in-right me-1"></i> Sign In
        </button>
    </form>

    <!-- Demo Credentials Helper Card -->
    <div class="mt-4 p-3 bg-light rounded-3 border text-center">
        <div class="text-muted small fw-semibold mb-1">
            <i class="bi bi-shield-lock-fill text-primary me-1"></i> Demo Credentials
        </div>
        <div class="small text-secondary">
            Username: <code class="text-primary fw-bold">admin</code> &bull; Password: <code class="text-primary fw-bold">admin123</code>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
