<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Student Management" scope="request" />
<c:set var="activePage" value="students" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="bn-card">
    <div class="bn-card-header flex-column flex-md-row gap-3">
        <div class="d-flex align-items-center gap-2">
            <h5 class="bn-card-title mb-0">
                <i class="bi bi-people-fill text-primary"></i> Registered Students
            </h5>
            <span class="badge bg-secondary rounded-pill">${students.size()} Students</span>
        </div>

        <div class="d-flex align-items-center gap-2 w-100 w-md-auto">
            <!-- Search Form -->
            <form action="${pageContext.request.contextPath}/students" method="get" class="d-flex gap-2 flex-grow-1">
                <div class="input-group input-group-sm">
                    <input type="text" name="search" class="form-control"
                           placeholder="Search name, roll no, dept..." value="${searchQuery}">
                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                    <c:if test="${not empty searchQuery}">
                        <a href="${pageContext.request.contextPath}/students" class="btn btn-outline-secondary">
                            <i class="bi bi-x-lg"></i>
                        </a>
                    </c:if>
                </div>
            </form>

            <a href="${pageContext.request.contextPath}/students?action=new" class="btn btn-sm btn-primary text-nowrap">
                <i class="bi bi-person-plus me-1"></i> Add Student
            </a>
        </div>
    </div>

    <div class="bn-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                <tr>
                    <th>Roll No / ID</th>
                    <th>Student Name</th>
                    <th>Department</th>
                    <th>Semester</th>
                    <th>Contact</th>
                    <th class="text-center">Issued Books</th>
                    <th class="text-end">Actions</th>
                </tr>
                </thead>
                <tbody>
                <c:choose>
                    <c:when test="${not empty students}">
                        <c:forEach var="student" items="${students}">
                            <tr>
                                <td>
                                    <code class="text-secondary fw-semibold">${student.studentCode}</code>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark">${student.name}</div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border">${student.department}</span>
                                </td>
                                <td>Semester ${student.semester}</td>
                                <td>
                                    <div class="small"><i class="bi bi-envelope text-muted me-1"></i>${student.email}</div>
                                    <c:if test="${not empty student.phone}">
                                        <div class="small text-muted"><i class="bi bi-telephone text-muted me-1"></i>${student.phone}</div>
                                    </c:if>
                                </td>
                                <td class="text-center">
                                    <c:choose>
                                        <c:when test="${student.activeIssuedBooksCount >= 3}">
                                            <span class="badge badge-soft-danger">3 / 3 (Limit Reached)</span>
                                        </c:when>
                                        <c:when test="${student.activeIssuedBooksCount > 0}">
                                            <span class="badge badge-soft-warning">${student.activeIssuedBooksCount} / 3 Active</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge badge-soft-success">0 / 3 Active</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <c:if test="${student.canIssueMore()}">
                                            <a href="${pageContext.request.contextPath}/issues?action=new&studentId=${student.studentId}"
                                               class="btn btn-outline-success" title="Issue Book to Student">
                                                <i class="bi bi-box-arrow-up-right"></i> Issue
                                            </a>
                                        </c:if>
                                        <a href="${pageContext.request.contextPath}/students?action=edit&id=${student.studentId}"
                                           class="btn btn-outline-primary" title="Edit Student">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="${pageContext.request.contextPath}/students?action=delete&id=${student.studentId}"
                                           class="btn btn-outline-danger btn-delete-confirm"
                                           data-name="${student.name}" title="Delete Student">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        </c:forEach>
                    </c:when>
                    <c:otherwise>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-person-x fs-1 d-block mb-2 text-secondary"></i>
                                No students found.
                            </td>
                        </tr>
                    </c:otherwise>
                </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
