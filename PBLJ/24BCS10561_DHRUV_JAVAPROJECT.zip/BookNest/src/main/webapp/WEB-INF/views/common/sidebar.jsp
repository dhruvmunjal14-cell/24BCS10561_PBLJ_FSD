<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<nav class="sidebar">
    <a href="${pageContext.request.contextPath}/dashboard" class="sidebar-brand">
        <i class="bi bi-book-half"></i>
        <span>BookNest</span>
    </a>

    <ul class="sidebar-menu">
        <li class="sidebar-item">
            <a href="${pageContext.request.contextPath}/dashboard"
               class="sidebar-link ${activePage == 'dashboard' ? 'active' : ''}">
                <i class="bi bi-grid-1x2-fill"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a href="${pageContext.request.contextPath}/books"
               class="sidebar-link ${activePage == 'books' ? 'active' : ''}">
                <i class="bi bi-journal-bookmark-fill"></i>
                <span>Books</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a href="${pageContext.request.contextPath}/students"
               class="sidebar-link ${activePage == 'students' ? 'active' : ''}">
                <i class="bi bi-people-fill"></i>
                <span>Students</span>
            </a>
        </li>

        <li class="sidebar-item">
            <a href="${pageContext.request.contextPath}/issues"
               class="sidebar-link ${activePage == 'issues' ? 'active' : ''}">
                <i class="bi bi-arrow-left-right"></i>
                <span>Issue & Return</span>
            </a>
        </li>
    </ul>

    <div class="sidebar-footer">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2 text-white">
                <i class="bi bi-person-circle fs-5 text-primary"></i>
                <div>
                    <div class="fw-semibold small">${sessionScope.admin.fullName}</div>
                    <div class="text-secondary" style="font-size: 0.75rem;">Admin</div>
                </div>
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="text-secondary text-decoration-none" title="Logout">
                <i class="bi bi-box-arrow-right fs-5"></i>
            </a>
        </div>
    </div>
</nav>
