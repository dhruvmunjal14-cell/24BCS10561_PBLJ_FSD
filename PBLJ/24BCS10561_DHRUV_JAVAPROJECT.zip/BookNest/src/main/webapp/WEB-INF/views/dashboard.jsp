<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Dashboard Overview" scope="request" />
<c:set var="activePage" value="dashboard" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<!-- Dashboard Overdue Alert Banner if any overdue books exist -->
<c:if test="${overdueCount > 0}">
    <div class="alert alert-warning d-flex align-items-center justify-content-between p-3 mb-4 rounded-3 border-warning shadow-sm" role="alert">
        <div class="d-flex align-items-center gap-2">
            <i class="bi bi-exclamation-triangle-fill fs-4 text-warning"></i>
            <div>
                <strong>Action Needed:</strong> There are currently <strong>${overdueCount}</strong> overdue book(s) incurring fines at ₹2.00/day.
            </div>
        </div>
        <a href="${pageContext.request.contextPath}/issues?filter=OVERDUE" class="btn btn-sm btn-outline-dark fw-semibold">
            View Overdue Books
        </a>
    </div>
</c:if>

<!-- Metric Cards Row -->
<div class="row g-3 mb-4">
    <!-- Total Books -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="stat-card stat-primary">
            <div>
                <div class="stat-val text-primary">${totalCopies}</div>
                <div class="stat-label">Total Books</div>
                <div class="text-muted small mt-1">${totalTitles} Unique Titles</div>
            </div>
            <div class="stat-icon-wrapper">
                <i class="bi bi-journal-album"></i>
            </div>
        </div>
    </div>

    <!-- Available Copies -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="stat-card stat-success">
            <div>
                <div class="stat-val text-success">${availableCopies}</div>
                <div class="stat-label">Available Copies</div>
                <div class="text-muted small mt-1">In Library Stock</div>
            </div>
            <div class="stat-icon-wrapper">
                <i class="bi bi-check2-circle"></i>
            </div>
        </div>
    </div>

    <!-- Currently Issued -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="stat-card stat-warning">
            <div>
                <div class="stat-val text-warning">${currentlyIssued}</div>
                <div class="stat-label">Currently Issued</div>
                <div class="text-muted small mt-1">Active Loans</div>
            </div>
            <div class="stat-icon-wrapper">
                <i class="bi bi-arrow-repeat"></i>
            </div>
        </div>
    </div>

    <!-- Registered Students -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="stat-card stat-info">
            <div>
                <div class="stat-val" style="color: #7c3aed;">${totalStudents}</div>
                <div class="stat-label">Students</div>
                <div class="text-muted small mt-1">Registered Members</div>
            </div>
            <div class="stat-icon-wrapper">
                <i class="bi bi-people"></i>
            </div>
        </div>
    </div>

    <!-- Overdue Books -->
    <div class="col-12 col-sm-6 col-xl">
        <div class="stat-card stat-danger">
            <div>
                <div class="stat-val text-danger">${overdueCount}</div>
                <div class="stat-label">Overdue Books</div>
                <div class="text-muted small mt-1">Pending Fines</div>
            </div>
            <div class="stat-icon-wrapper">
                <i class="bi bi-alarm"></i>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions & Recent Transactions -->
<div class="row g-4 mb-4">
    <!-- Recent Transactions Table -->
    <div class="col-12 col-lg-8">
        <div class="bn-card h-100">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-clock-history text-primary"></i> Recent Transactions
                </h5>
                <a href="${pageContext.request.contextPath}/issues" class="btn btn-sm btn-outline-primary">
                    View All
                </a>
            </div>
            <div class="bn-card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                        <tr>
                            <th>Book Title</th>
                            <th>Student</th>
                            <th>Issue Date</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:choose>
                            <c:when test="${not empty recentActivities}">
                                <c:forEach var="item" items="${recentActivities}">
                                    <tr>
                                        <td>
                                            <div class="fw-semibold text-truncate" style="max-width: 220px;" title="${item.bookTitle}">
                                                ${item.bookTitle}
                                            </div>
                                            <small class="text-muted">ISBN: ${item.bookIsbn}</small>
                                        </td>
                                        <td>
                                            <div>${item.studentName}</div>
                                            <small class="text-muted">${item.studentCode}</small>
                                        </td>
                                        <td>${item.formattedIssueDate}</td>
                                        <td>${item.formattedDueDate}</td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${item.status == 'RETURNED'}">
                                                    <span class="badge badge-soft-success">Returned</span>
                                                </c:when>
                                                <c:when test="${item.overdue}">
                                                    <span class="badge badge-soft-danger">Overdue (${item.overdueDays}d)</span>
                                                </c:when>
                                                <c:otherwise>
                                                    <span class="badge badge-soft-primary">Issued</span>
                                                </c:otherwise>
                                            </c:choose>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>
                            <c:otherwise>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-muted">
                                        No recent transactions recorded yet.
                                    </td>
                                </tr>
                            </c:otherwise>
                        </c:choose>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links / Shortcuts & Fine Policy -->
    <div class="col-12 col-lg-4">
        <!-- Quick Actions Card -->
        <div class="bn-card mb-4">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-lightning-charge-fill text-warning"></i> Quick Actions
                </h5>
            </div>
            <div class="bn-card-body d-flex flex-column gap-2">
                <a href="${pageContext.request.contextPath}/issues?action=new" class="btn btn-primary text-start d-flex align-items-center justify-content-between p-2.5">
                    <span><i class="bi bi-plus-circle me-2"></i> Issue a Book</span>
                    <i class="bi bi-chevron-right small"></i>
                </a>
                <a href="${pageContext.request.contextPath}/books?action=new" class="btn btn-outline-primary text-start d-flex align-items-center justify-content-between p-2.5">
                    <span><i class="bi bi-book me-2"></i> Add New Book</span>
                    <i class="bi bi-chevron-right small"></i>
                </a>
                <a href="${pageContext.request.contextPath}/students?action=new" class="btn btn-outline-secondary text-start d-flex align-items-center justify-content-between p-2.5">
                    <span><i class="bi bi-person-plus me-2"></i> Register Student</span>
                    <i class="bi bi-chevron-right small"></i>
                </a>
            </div>
        </div>

        <!-- Library Rules & Fine Card -->
        <div class="bn-card">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-info-circle-fill text-info"></i> Loan & Fine Policy
                </h5>
            </div>
            <div class="bn-card-body small">
                <ul class="list-unstyled mb-0">
                    <li class="mb-2 d-flex align-items-start gap-2">
                        <i class="bi bi-check2 text-success fs-6 mt-0.5"></i>
                        <span><strong>Standard Loan Period:</strong> 14 Calendar Days.</span>
                    </li>
                    <li class="mb-2 d-flex align-items-start gap-2">
                        <i class="bi bi-check2 text-success fs-6 mt-0.5"></i>
                        <span><strong>Borrowing Quota:</strong> Max 3 active books per student.</span>
                    </li>
                    <li class="mb-2 d-flex align-items-start gap-2">
                        <i class="bi bi-check2 text-success fs-6 mt-0.5"></i>
                        <span><strong>Late Fine:</strong> ₹2.00 per day after due date.</span>
                    </li>
                    <li class="d-flex align-items-start gap-2">
                        <i class="bi bi-check2 text-success fs-6 mt-0.5"></i>
                        <span><strong>Inventory Protection:</strong> Out-of-stock books cannot be issued.</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
