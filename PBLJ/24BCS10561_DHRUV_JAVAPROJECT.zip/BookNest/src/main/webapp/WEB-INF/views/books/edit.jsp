<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:set var="pageTitle" value="Edit Book" scope="request" />
<c:set var="activePage" value="books" scope="request" />

<jsp:include page="/WEB-INF/views/common/header.jsp" />

<div class="row justify-content-center">
    <div class="col-12 col-lg-8">
        <div class="bn-card">
            <div class="bn-card-header">
                <h5 class="bn-card-title">
                    <i class="bi bi-pencil-square text-primary"></i> Edit Book Details
                </h5>
                <a href="${pageContext.request.contextPath}/books" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Books
                </a>
            </div>

            <div class="bn-card-body">
                <!-- Stock Status Notice -->
                <div class="alert alert-info d-flex align-items-center justify-content-between p-3 mb-4 rounded-3 small">
                    <div>
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Currently Issued to Students: <strong>${book.issuedCopies}</strong> &bull;
                        Available in Library: <strong>${book.availableCopies}</strong>
                    </div>
                    <span class="badge bg-primary">Minimum Total Copies: ${book.issuedCopies}</span>
                </div>

                <form action="${pageContext.request.contextPath}/books" method="post" autocomplete="off">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="bookId" value="${book.bookId}">

                    <div class="row g-3">
                        <!-- ISBN -->
                        <div class="col-md-6">
                            <label for="isbn" class="form-label fw-semibold small">ISBN <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="isbn" name="isbn"
                                   value="${book.isbn}" required>
                        </div>

                        <!-- Title -->
                        <div class="col-md-6">
                            <label for="title" class="form-label fw-semibold small">Book Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title"
                                   value="${book.title}" required>
                        </div>

                        <!-- Author -->
                        <div class="col-md-6">
                            <label for="author" class="form-label fw-semibold small">Author(s) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="author" name="author"
                                   value="${book.author}" required>
                        </div>

                        <!-- Category -->
                        <div class="col-md-6">
                            <label for="category" class="form-label fw-semibold small">Category / Genre</label>
                            <select class="form-select" id="category" name="category">
                                <option value="Computer Science" ${book.category == 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                                <option value="Software Engineering" ${book.category == 'Software Engineering' ? 'selected' : ''}>Software Engineering</option>
                                <option value="Data Structures" ${book.category == 'Data Structures' ? 'selected' : ''}>Data Structures &amp; Algorithms</option>
                                <option value="Database Systems" ${book.category == 'Database Systems' ? 'selected' : ''}>Database Systems</option>
                                <option value="Computer Networks" ${book.category == 'Computer Networks' ? 'selected' : ''}>Computer Networks</option>
                                <option value="Operating Systems" ${book.category == 'Operating Systems' ? 'selected' : ''}>Operating Systems</option>
                                <option value="Artificial Intelligence" ${book.category == 'Artificial Intelligence' ? 'selected' : ''}>Artificial Intelligence</option>
                                <option value="General Engineering" ${book.category == 'General Engineering' ? 'selected' : ''}>General Engineering</option>
                            </select>
                        </div>

                        <!-- Publisher -->
                        <div class="col-md-6">
                            <label for="publisher" class="form-label fw-semibold small">Publisher</label>
                            <input type="text" class="form-control" id="publisher" name="publisher"
                                   value="${book.publisher}">
                        </div>

                        <!-- Publication Year -->
                        <div class="col-md-3">
                            <label for="publicationYear" class="form-label fw-semibold small">Year</label>
                            <input type="number" class="form-control" id="publicationYear" name="publicationYear"
                                   min="1900" max="2099" value="${book.publicationYear}">
                        </div>

                        <!-- Total Copies -->
                        <div class="col-md-3">
                            <label for="totalCopies" class="form-label fw-semibold small">Total Copies <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="totalCopies" name="totalCopies"
                                   min="${book.issuedCopies}" value="${book.totalCopies}" required>
                            <div class="form-text">Cannot be less than ${book.issuedCopies}.</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="${pageContext.request.contextPath}/books" class="btn btn-light">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check2-circle me-1"></i> Update Book
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/WEB-INF/views/common/footer.jsp" />
