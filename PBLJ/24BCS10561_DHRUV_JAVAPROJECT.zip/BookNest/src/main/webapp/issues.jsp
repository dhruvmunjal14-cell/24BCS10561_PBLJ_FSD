<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookNest - Issue &amp; Return</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<jsp:include page="/navbar.jsp">
    <jsp:param name="page" value="issues" />
</jsp:include>

<div class="container pb-5">

    <!-- Issue Book Card -->
    <div class="card mb-4 shadow-sm border-0">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <span class="fw-bold"><i class="bi bi-box-arrow-up-right text-primary me-2"></i> Issue Book to Student</span>
            <span class="badge bg-light text-dark border">Loan: 14 Days &bull; Fine: Rs 2/day</span>
        </div>
        <div class="card-body">
            <form action="${pageContext.request.contextPath}/issues" method="post">
                <input type="hidden" name="action" value="issue">

                <div class="row g-3">
                    <!-- Book Selection -->
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Select Book <span class="text-danger">*</span></label>
                        <select name="bookId" class="form-select" required>
                            <option value="">-- Choose Book in Stock --</option>
                            <c:forEach var="b" items="${availableBooks}">
                                <option value="${b.bookId}">
                                    ${b.title} (${b.availableCopies} available) &bull; ${b.author}
                                </option>
                            </c:forEach>
                        </select>
                    </div>

                    <!-- Student Selection -->
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Select Student <span class="text-danger">*</span></label>
                        <select name="studentId" class="form-select" required>
                            <option value="">-- Choose Student --</option>
                            <c:forEach var="s" items="${students}">
                                <option value="${s.studentId}" ${s.activeIssuedBooksCount >= 3 ? 'disabled' : ''}>
                                    ${s.name} (${s.studentCode}) [${s.activeIssuedBooksCount}/3 Active Books]
                                </option>
                            </c:forEach>
                        </select>
                    </div>

                    <!-- Dates -->
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Issue Date</label>
                        <input type="date" name="issueDate" class="form-control" value="${todayDate}" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Due Date (14 Days)</label>
                        <input type="date" name="dueDate" class="form-control" value="${dueDate}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Remarks (Optional)</label>
                        <input type="text" name="remarks" class="form-control" placeholder="e.g. For project study">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-check2 me-1"></i> Issue
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Filter Pills & Transactions Table -->
    <div class="card shadow-sm">
        <div class="card-header d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
            <span class="fw-bold"><i class="bi bi-list-check text-primary me-2"></i> Transactions History</span>

            <!-- Filter Buttons -->
            <div class="btn-group btn-group-sm" role="group">
                <a href="${pageContext.request.contextPath}/issues?filter=ALL"
                   class="btn btn-outline-primary ${currentFilter == 'ALL' ? 'active' : ''}">All</a>
                <a href="${pageContext.request.contextPath}/issues?filter=ISSUED"
                   class="btn btn-outline-primary ${currentFilter == 'ISSUED' ? 'active' : ''}">Currently Issued</a>
                <a href="${pageContext.request.contextPath}/issues?filter=OVERDUE"
                   class="btn btn-outline-danger ${currentFilter == 'OVERDUE' ? 'active' : ''}">Overdue Only</a>
                <a href="${pageContext.request.contextPath}/issues?filter=RETURNED"
                   class="btn btn-outline-success ${currentFilter == 'RETURNED' ? 'active' : ''}">Returned</a>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                    <tr>
                        <th>Trx ID</th>
                        <th>Book Details</th>
                        <th>Student</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                        <th>Fine / Status</th>
                        <th class="text-end">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty issues}">
                            <c:forEach var="item" items="${issues}">
                                <tr>
                                    <td><code>#${item.issueId}</code></td>
                                    <td>
                                        <div class="fw-bold">${item.bookTitle}</div>
                                        <small class="text-muted">ISBN: ${item.bookIsbn}</small>
                                    </td>
                                    <td>
                                        <div><strong>${item.studentName}</strong></div>
                                        <small class="text-muted">${item.studentCode}</small>
                                    </td>
                                    <td>${item.formattedIssueDate}</td>
                                    <td>
                                        <span class="${item.overdue ? 'text-danger fw-bold' : ''}">
                                            ${item.formattedDueDate}
                                        </span>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${not empty item.returnDate}">${item.formattedReturnDate}</c:when>
                                            <c:otherwise><span class="text-muted">-</span></c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${item.status == 'RETURNED'}">
                                                <span class="badge bg-success">Returned</span>
                                                <c:if test="${item.fineAmount > 0}">
                                                    <div class="small text-danger fw-semibold">Fine: Rs ${item.fineAmount}</div>
                                                </c:if>
                                            </c:when>
                                            <c:when test="${item.overdue}">
                                                <span class="badge bg-danger">Overdue (${item.overdueDays}d)</span>
                                                <div class="small text-danger fw-bold">Fine: Rs ${item.computedFine}</div>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-primary">Issued</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-end">
                                        <c:if test="${item.status == 'ISSUED'}">
                                            <button type="button" class="btn btn-sm btn-outline-success"
                                                    data-bs-toggle="modal" data-bs-target="#returnModal"
                                                    data-id="${item.issueId}"
                                                    data-title="${item.bookTitle}"
                                                    data-student="${item.studentName}"
                                                    data-due="${item.dueDate}">
                                                <i class="bi bi-arrow-return-left"></i> Return
                                            </button>
                                        </c:if>
                                        <c:if test="${item.status == 'RETURNED'}">
                                            <span class="text-muted small"><i class="bi bi-check2"></i> Closed</span>
                                        </c:if>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="8" class="text-center py-5 text-muted">No records found.</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Return Book Modal -->
<div class="modal fade" id="returnModal" tabindex="-1" aria-labelledby="returnModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-6 fw-bold" id="returnModalLabel">Confirm Book Return</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/issues" method="post">
                <input type="hidden" name="action" value="return">
                <input type="hidden" name="issueId" id="modalIssueId">

                <div class="modal-body">
                    <p class="mb-1 text-muted small">Book: <strong id="modalBookTitle" class="text-dark"></strong></p>
                    <p class="mb-1 text-muted small">Student: <strong id="modalStudent" class="text-dark"></strong></p>
                    <p class="mb-3 text-muted small">Due Date: <strong id="modalDueDate" class="text-dark"></strong></p>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Return Date</label>
                        <input type="date" name="returnDate" id="modalReturnDate" class="form-control" required>
                    </div>

                    <div class="mb-3" id="finePreview"></div>

                    <div class="mb-2">
                        <label class="form-label small fw-semibold">Remarks (Optional)</label>
                        <input type="text" name="remarks" class="form-control" placeholder="e.g. Good condition">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success btn-sm">Confirm Return</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/js/script.js"></script>
</body>
</html>
