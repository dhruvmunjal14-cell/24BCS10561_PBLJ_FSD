/**
 * BookNest - Smart Library Management System
 * Client-Side Interactivity & Form Utilities
 */

document.addEventListener("DOMContentLoaded", function () {
    // 1. Auto-dismiss flash alerts after 6 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
            if (bsAlert) {
                bsAlert.close();
            }
        }, 6000);
    });

    // 2. Initialize Bootstrap tooltips if any
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // 3. Confirm Delete Prompts
    const deleteButtons = document.querySelectorAll(".btn-delete-confirm");
    deleteButtons.forEach(function (button) {
        button.addEventListener("click", function (event) {
            const itemName = button.getAttribute("data-name") || "this record";
            const confirmMsg = "Are you sure you want to delete " + itemName + "?\nThis action cannot be undone.";
            if (!confirm(confirmMsg)) {
                event.preventDefault();
            }
        });
    });

    // 4. Issue Book Page: Quota and Availability validation
    const studentSelect = document.getElementById("studentSelect");
    const quotaBadge = document.getElementById("studentQuotaBadge");

    if (studentSelect && quotaBadge) {
        studentSelect.addEventListener("change", function () {
            const selectedOpt = studentSelect.options[studentSelect.selectedIndex];
            const activeCount = parseInt(selectedOpt.getAttribute("data-active") || "0", 10);
            const remaining = Math.max(0, 3 - activeCount);

            if (remaining === 0) {
                quotaBadge.className = "badge bg-danger mt-1";
                quotaBadge.textContent = "Quota Exceeded: 3 of 3 books currently issued. Cannot issue more.";
            } else {
                quotaBadge.className = "badge bg-info text-dark mt-1";
                quotaBadge.textContent = "Active Borrowings: " + activeCount + " | Remaining Quota: " + remaining + " of 3";
            }
        });
    }

    // 5. Return Modal fine preview
    const returnModal = document.getElementById("returnModal");
    if (returnModal) {
        returnModal.addEventListener("show.bs.modal", function (event) {
            const button = event.relatedTarget;
            const issueId = button.getAttribute("data-issue-id");
            const bookTitle = button.getAttribute("data-book-title");
            const studentName = button.getAttribute("data-student-name");
            const dueDateStr = button.getAttribute("data-due-date");

            document.getElementById("modalIssueId").value = issueId;
            document.getElementById("modalBookTitle").textContent = bookTitle;
            document.getElementById("modalStudentName").textContent = studentName;
            document.getElementById("modalDueDate").textContent = dueDateStr;

            const returnDateInput = document.getElementById("modalReturnDate");
            const todayStr = new Date().toISOString().split("T")[0];
            returnDateInput.value = todayStr;

            updateFineCalculation(dueDateStr, returnDateInput.value);

            returnDateInput.addEventListener("change", function () {
                updateFineCalculation(dueDateStr, returnDateInput.value);
            });
        });
    }

    function updateFineCalculation(dueDateStr, returnDateStr) {
        const fineBadge = document.getElementById("modalFineBadge");
        if (!fineBadge) return;

        const dueDate = new Date(dueDateStr);
        const returnDate = new Date(returnDateStr);

        const diffTime = returnDate.getTime() - dueDate.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays > 0) {
            const fine = (diffDays * 2.0).toFixed(2);
            fineBadge.className = "alert alert-danger py-2 mb-0";
            fineBadge.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-1"></i> Overdue by <strong>' +
                diffDays + ' day(s)</strong>. Applicable Fine: <strong>₹' + fine + '</strong> (₹2.00/day)';
        } else {
            fineBadge.className = "alert alert-success py-2 mb-0";
            fineBadge.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i> Returned on or before due date. <strong>No fine applicable (₹0.00)</strong>';
        }
    }
});
