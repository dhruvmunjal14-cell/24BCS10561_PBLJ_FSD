<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Redirect root to dashboard (AuthFilter sends to /login if unauthenticated)
    response.sendRedirect(request.getContextPath() + "/dashboard");
%>
