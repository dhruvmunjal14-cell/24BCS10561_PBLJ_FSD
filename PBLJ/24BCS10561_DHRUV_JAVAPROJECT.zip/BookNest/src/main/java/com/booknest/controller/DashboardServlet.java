package com.booknest.controller;

import com.booknest.dao.BookDAO;
import com.booknest.dao.IssueDAO;
import com.booknest.dao.StudentDAO;
import com.booknest.model.IssueRecord;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * DashboardServlet aggregates key library metrics and recent transactions
 * to present the main administrative overview.
 */
@WebServlet(urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private BookDAO bookDAO;
    private StudentDAO studentDAO;
    private IssueDAO issueDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        this.bookDAO = new BookDAO();
        this.studentDAO = new StudentDAO();
        this.issueDAO = new IssueDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Fetch statistic counts
        int totalCopies = bookDAO.getTotalCopiesCount();
        int totalTitles = bookDAO.getTotalTitlesCount();
        int availableCopies = bookDAO.getAvailableCopiesCount();
        int totalStudents = studentDAO.getTotalStudentsCount();
        int currentlyIssued = issueDAO.getCurrentlyIssuedCount();
        int overdueCount = issueDAO.getOverdueCount();

        // Fetch recent transactions
        List<IssueRecord> recentActivities = issueDAO.getRecentIssues(8);
        List<IssueRecord> overdueIssues = issueDAO.getIssuesByFilter("OVERDUE");

        // Pass metrics to JSP
        request.setAttribute("totalCopies", totalCopies);
        request.setAttribute("totalTitles", totalTitles);
        request.setAttribute("availableCopies", availableCopies);
        request.setAttribute("totalStudents", totalStudents);
        request.setAttribute("currentlyIssued", currentlyIssued);
        request.setAttribute("overdueCount", overdueCount);
        request.setAttribute("recentActivities", recentActivities);
        request.setAttribute("overdueIssues", overdueIssues);

        request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
    }
}
