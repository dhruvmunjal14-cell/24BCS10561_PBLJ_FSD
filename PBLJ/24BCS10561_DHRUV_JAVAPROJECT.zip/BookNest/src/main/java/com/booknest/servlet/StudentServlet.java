package com.booknest.servlet;

import com.booknest.dao.StudentDAO;
import com.booknest.model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * StudentServlet - Handles student registration, viewing, updating, and deleting.
 * Student: Dhruv Munjal (24BCS10561)
 */
@WebServlet(urlPatterns = {"/students"})
public class StudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private StudentDAO studentDAO;

    @Override
    public void init() {
        this.studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            handleDelete(request, response);
            return;
        }

        // List or Search
        String search = request.getParameter("search");
        List<Student> students;
        if (search != null && !search.trim().isEmpty()) {
            students = studentDAO.searchStudents(search.trim());
            request.setAttribute("searchQuery", search.trim());
        } else {
            students = studentDAO.getAllStudents();
        }

        // Check if an edit student is requested
        String editIdParam = request.getParameter("editId");
        if (editIdParam != null && !editIdParam.trim().isEmpty()) {
            try {
                int editId = Integer.parseInt(editIdParam);
                Student editStudent = studentDAO.getStudentById(editId);
                request.setAttribute("editStudent", editStudent);
            } catch (Exception ignored) {
            }
        }

        request.setAttribute("students", students);
        request.getRequestDispatcher("/students.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            handleAdd(request, response);
        } else if ("update".equals(action)) {
            handleUpdate(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/students");
        }
    }

    private void handleAdd(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("studentCode");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String dept = request.getParameter("department");
        int semester = Integer.parseInt(request.getParameter("semester"));

        Student student = new Student(code.trim().toUpperCase(), name.trim(), email.trim(), phone, dept, semester);

        try {
            studentDAO.addStudent(student);
            request.getSession().setAttribute("msgSuccess", "Student '" + name + "' enrolled successfully!");
        } catch (SQLException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }

    private void handleUpdate(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int studentId = Integer.parseInt(request.getParameter("studentId"));
        String code = request.getParameter("studentCode");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String dept = request.getParameter("department");
        int semester = Integer.parseInt(request.getParameter("semester"));

        Student student = new Student();
        student.setStudentId(studentId);
        student.setStudentCode(code.trim().toUpperCase());
        student.setName(name.trim());
        student.setEmail(email.trim());
        student.setPhone(phone);
        student.setDepartment(dept);
        student.setSemester(semester);

        try {
            studentDAO.updateStudent(student);
            request.getSession().setAttribute("msgSuccess", "Student updated successfully!");
        } catch (SQLException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }

    private void handleDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            studentDAO.deleteStudent(id);
            request.getSession().setAttribute("msgSuccess", "Student record deleted.");
        } catch (IllegalStateException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        } catch (Exception e) {
            request.getSession().setAttribute("msgError", "Could not delete student: " + e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }
}
