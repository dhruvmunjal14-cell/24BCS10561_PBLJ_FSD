package com.booknest.controller;

import com.booknest.dao.BookDAO;
import com.booknest.dao.IssueDAO;
import com.booknest.dao.StudentDAO;
import com.booknest.model.Book;
import com.booknest.model.IssueRecord;
import com.booknest.model.Student;
import com.booknest.util.DateUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * IssueServlet handles book checkout, return processing, and fine tracking.
 */
@WebServlet(urlPatterns = {"/issues"})
public class IssueServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private IssueDAO issueDAO;
    private BookDAO bookDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        this.issueDAO = new IssueDAO();
        this.bookDAO = new BookDAO();
        this.studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "new":
                showIssueForm(request, response);
                break;
            case "list":
            default:
                listIssues(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if ("issue".equals(action)) {
            processIssueBook(request, response);
        } else if ("return".equals(action)) {
            processReturnBook(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/issues");
        }
    }

    private void listIssues(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String filter = request.getParameter("filter");
        if (filter == null || filter.trim().isEmpty()) {
            filter = "ALL";
        }

        List<IssueRecord> issues = issueDAO.getIssuesByFilter(filter);

        request.setAttribute("issues", issues);
        request.setAttribute("currentFilter", filter);
        request.getRequestDispatcher("/WEB-INF/views/issues/list.jsp").forward(request, response);
    }

    private void showIssueForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Book> availableBooks = bookDAO.getAvailableBooks();
        List<Student> students = studentDAO.getAllStudents();

        LocalDate today = LocalDate.now();
        LocalDate defaultDue = DateUtil.calculateDueDate(today);

        request.setAttribute("books", availableBooks);
        request.setAttribute("students", students);
        request.setAttribute("todayDate", DateUtil.formatIso(today));
        request.setAttribute("defaultDueDate", DateUtil.formatIso(defaultDue));

        // Pre-selection support (e.g., if user clicked "Issue" directly from Books table)
        String preBookId = request.getParameter("bookId");
        String preStudentId = request.getParameter("studentId");
        if (preBookId != null) request.setAttribute("selectedBookId", preBookId);
        if (preStudentId != null) request.setAttribute("selectedStudentId", preStudentId);

        request.getRequestDispatcher("/WEB-INF/views/issues/issue_book.jsp").forward(request, response);
    }

    private void processIssueBook(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String bookIdParam = request.getParameter("bookId");
        String studentIdParam = request.getParameter("studentId");
        String issueDateParam = request.getParameter("issueDate");
        String dueDateParam = request.getParameter("dueDate");
        String remarks = request.getParameter("remarks");

        int bookId;
        int studentId;
        try {
            bookId = Integer.parseInt(bookIdParam);
            studentId = Integer.parseInt(studentIdParam);
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Please select a valid book and student.");
            showIssueForm(request, response);
            return;
        }

        LocalDate issueDate = DateUtil.parseIso(issueDateParam);
        LocalDate dueDate = DateUtil.parseIso(dueDateParam);

        if (issueDate == null) issueDate = LocalDate.now();
        if (dueDate == null) dueDate = DateUtil.calculateDueDate(issueDate);

        if (dueDate.isBefore(issueDate)) {
            request.setAttribute("errorMessage", "Due date cannot be before the issue date.");
            showIssueForm(request, response);
            return;
        }

        try {
            int issueId = issueDAO.issueBook(bookId, studentId, issueDate, dueDate, remarks);
            if (issueId > 0) {
                request.getSession().setAttribute("successMessage", "Book issued successfully! Due date: " +
                        DateUtil.formatDisplay(dueDate));
                response.sendRedirect(request.getContextPath() + "/issues");
            } else {
                request.setAttribute("errorMessage", "Could not complete book issue.");
                showIssueForm(request, response);
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            request.setAttribute("errorMessage", e.getMessage());
            showIssueForm(request, response);
        } catch (SQLException e) {
            request.setAttribute("errorMessage", "Database transaction failed: " + e.getMessage());
            showIssueForm(request, response);
        }
    }

    private void processReturnBook(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String issueIdParam = request.getParameter("issueId");
        String returnDateParam = request.getParameter("returnDate");
        String remarks = request.getParameter("remarks");

        int issueId;
        try {
            issueId = Integer.parseInt(issueIdParam);
        } catch (NumberFormatException e) {
            request.getSession().setAttribute("errorMessage", "Invalid issue ID.");
            response.sendRedirect(request.getContextPath() + "/issues");
            return;
        }

        LocalDate returnDate = DateUtil.parseIso(returnDateParam);
        if (returnDate == null) {
            returnDate = LocalDate.now();
        }

        try {
            BigDecimal fine = issueDAO.returnBook(issueId, returnDate, remarks);

            String msg = "Book returned successfully!";
            if (fine.compareTo(BigDecimal.ZERO) > 0) {
                msg += " Late return fine applied: ₹" + fine.toPlainString();
            } else {
                msg += " Returned on time (No fine).";
            }

            request.getSession().setAttribute("successMessage", msg);
        } catch (IllegalStateException | IllegalArgumentException e) {
            request.getSession().setAttribute("errorMessage", e.getMessage());
        } catch (SQLException e) {
            request.getSession().setAttribute("errorMessage", "Database error processing return: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/issues");
    }
}
