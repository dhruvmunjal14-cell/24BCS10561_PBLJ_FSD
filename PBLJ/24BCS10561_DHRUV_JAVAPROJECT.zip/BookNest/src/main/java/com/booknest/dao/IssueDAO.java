package com.booknest.dao;

import com.booknest.model.IssueRecord;
import com.booknest.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * IssueDAO - Handles book issue and return transactions.
 * Student: Dhruv Munjal (24BCS10561)
 */
public class IssueDAO {

    public static final int MAX_BOOKS_ALLOWED = 3;

    // Issue book to student (Transactional: updates book copies and inserts record)
    public int issueBook(int bookId, int studentId, LocalDate issueDate, LocalDate dueDate, String remarks)
            throws SQLException {

        if (issueDate == null) issueDate = LocalDate.now();
        if (dueDate == null) dueDate = DBConnection.calculateDueDate(issueDate);

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Begin transaction

            // Step 1: Check if student exists
            try (PreparedStatement ps = conn.prepareStatement("SELECT student_id FROM students WHERE student_id = ?")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalArgumentException("Invalid student ID: " + studentId);
                    }
                }
            }

            // Step 2: Check student active issues (Rule: Max 3 books allowed)
            try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM issue_records WHERE student_id = ? AND status = 'ISSUED'")) {
                ps.setInt(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt(1) >= MAX_BOOKS_ALLOWED) {
                        throw new IllegalStateException("Student already has " + MAX_BOOKS_ALLOWED + " active books issued (Maximum limit reached).");
                    }
                }
            }

            // Step 3: Check and reduce available copies (Rule: Cannot issue if available == 0)
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ? AND available_copies > 0")) {
                ps.setInt(1, bookId);
                int updated = ps.executeUpdate();
                if (updated == 0) {
                    throw new IllegalStateException("Book is currently out of stock (0 available copies).");
                }
            }

            // Step 4: Insert into issue_records
            int generatedId = -1;
            String insertSql = "INSERT INTO issue_records (book_id, student_id, issue_date, due_date, status, remarks) VALUES (?, ?, ?, ?, 'ISSUED', ?)";
            try (PreparedStatement ps = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, bookId);
                ps.setInt(2, studentId);
                ps.setDate(3, Date.valueOf(issueDate));
                ps.setDate(4, Date.valueOf(dueDate));
                ps.setString(5, remarks);
                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }

            conn.commit(); // Transaction success!
            return generatedId;

        } catch (SQLException | RuntimeException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback on any failure to preserve inventory counts
                } catch (SQLException ignored) {
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    // Return an issued book (Transactional: updates issue record and increments book copies)
    public BigDecimal returnBook(int issueId, LocalDate returnDate, String remarks) throws SQLException {
        if (returnDate == null) returnDate = LocalDate.now();

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // Begin transaction

            int bookId = -1;
            LocalDate dueDate = null;
            String currentStatus = null;

            // Step 1: Check issue record
            try (PreparedStatement ps = conn.prepareStatement("SELECT book_id, due_date, status FROM issue_records WHERE issue_id = ?")) {
                ps.setInt(1, issueId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        throw new IllegalArgumentException("Issue record not found: " + issueId);
                    }
                    bookId = rs.getInt("book_id");
                    dueDate = rs.getDate("due_date").toLocalDate();
                    currentStatus = rs.getString("status");
                }
            }

            // Step 2: Prevent returning twice
            if ("RETURNED".equalsIgnoreCase(currentStatus)) {
                throw new IllegalStateException("Book has already been returned.");
            }

            // Step 3: Calculate fine (Rs 2 per day overdue)
            BigDecimal fine = DBConnection.calculateFine(dueDate, returnDate);

            // Step 4: Update issue record
            String updateSql = "UPDATE issue_records SET return_date = ?, fine_amount = ?, status = 'RETURNED', " +
                    "remarks = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE remarks END " +
                    "WHERE issue_id = ? AND status = 'ISSUED'";
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setDate(1, Date.valueOf(returnDate));
                ps.setBigDecimal(2, fine);
                ps.setString(3, remarks);
                ps.setString(4, remarks);
                ps.setString(5, remarks);
                ps.setInt(6, issueId);
                int updated = ps.executeUpdate();
                if (updated == 0) {
                    throw new IllegalStateException("Failed to update issue record.");
                }
            }

            // Step 5: Increase available copies by 1
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?")) {
                ps.setInt(1, bookId);
                ps.executeUpdate();
            }

            conn.commit(); // Transaction success!
            return fine;

        } catch (SQLException | RuntimeException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ignored) {
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    // Get all transactions or filtered by status
    public List<IssueRecord> getIssues(String filter) {
        List<IssueRecord> list = new ArrayList<>();
        String sql = "SELECT ir.issue_id, ir.book_id, ir.student_id, ir.issue_date, ir.due_date, ir.return_date, " +
                "ir.fine_amount, ir.status, ir.remarks, ir.created_at, " +
                "b.title AS book_title, b.isbn AS book_isbn, " +
                "s.name AS student_name, s.student_code, s.department AS student_department " +
                "FROM issue_records ir " +
                "JOIN books b ON ir.book_id = b.book_id " +
                "JOIN students s ON ir.student_id = s.student_id ";

        if ("ISSUED".equalsIgnoreCase(filter)) {
            sql += "WHERE ir.status = 'ISSUED' ORDER BY ir.issue_id DESC";
        } else if ("RETURNED".equalsIgnoreCase(filter)) {
            sql += "WHERE ir.status = 'RETURNED' ORDER BY ir.issue_id DESC";
        } else if ("OVERDUE".equalsIgnoreCase(filter)) {
            sql += "WHERE ir.status = 'ISSUED' AND ir.due_date < CURRENT_DATE ORDER BY ir.due_date ASC";
        } else {
            sql += "ORDER BY ir.issue_id DESC";
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapRecord(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching issues: " + e.getMessage());
        }
        return list;
    }

    // Get single issue record
    public IssueRecord getIssueById(int issueId) {
        String sql = "SELECT ir.issue_id, ir.book_id, ir.student_id, ir.issue_date, ir.due_date, ir.return_date, " +
                "ir.fine_amount, ir.status, ir.remarks, ir.created_at, " +
                "b.title AS book_title, b.isbn AS book_isbn, " +
                "s.name AS student_name, s.student_code, s.department AS student_department " +
                "FROM issue_records ir " +
                "JOIN books b ON ir.book_id = b.book_id " +
                "JOIN students s ON ir.student_id = s.student_id WHERE ir.issue_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, issueId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRecord(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching issue by ID: " + e.getMessage());
        }
        return null;
    }

    // Currently issued books count
    public int getIssuedCount() {
        String sql = "SELECT COUNT(*) FROM issue_records WHERE status = 'ISSUED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException ignored) {
        }
        return 0;
    }

    // Overdue books count
    public int getOverdueCount() {
        String sql = "SELECT COUNT(*) FROM issue_records WHERE status = 'ISSUED' AND due_date < CURRENT_DATE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException ignored) {
        }
        return 0;
    }

    // Recent 5 transactions for dashboard
    public List<IssueRecord> getRecentIssues(int limit) {
        List<IssueRecord> list = new ArrayList<>();
        String sql = "SELECT ir.issue_id, ir.book_id, ir.student_id, ir.issue_date, ir.due_date, ir.return_date, " +
                "ir.fine_amount, ir.status, ir.remarks, ir.created_at, " +
                "b.title AS book_title, b.isbn AS book_isbn, " +
                "s.name AS student_name, s.student_code, s.department AS student_department " +
                "FROM issue_records ir " +
                "JOIN books b ON ir.book_id = b.book_id " +
                "JOIN students s ON ir.student_id = s.student_id ORDER BY ir.issue_id DESC LIMIT ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRecord(rs));
                }
            }
        } catch (SQLException ignored) {
        }
        return list;
    }

    private IssueRecord mapRecord(ResultSet rs) throws SQLException {
        IssueRecord r = new IssueRecord();
        r.setIssueId(rs.getInt("issue_id"));
        r.setBookId(rs.getInt("book_id"));
        r.setStudentId(rs.getInt("student_id"));
        if (rs.getDate("issue_date") != null) r.setIssueDate(rs.getDate("issue_date").toLocalDate());
        if (rs.getDate("due_date") != null) r.setDueDate(rs.getDate("due_date").toLocalDate());
        if (rs.getDate("return_date") != null) r.setReturnDate(rs.getDate("return_date").toLocalDate());
        r.setFineAmount(rs.getBigDecimal("fine_amount"));
        r.setStatus(rs.getString("status"));
        r.setRemarks(rs.getString("remarks"));
        r.setCreatedAt(rs.getTimestamp("created_at"));
        r.setBookTitle(rs.getString("book_title"));
        r.setBookIsbn(rs.getString("book_isbn"));
        r.setStudentName(rs.getString("student_name"));
        r.setStudentCode(rs.getString("student_code"));
        r.setStudentDepartment(rs.getString("student_department"));
        return r;
    }
}
