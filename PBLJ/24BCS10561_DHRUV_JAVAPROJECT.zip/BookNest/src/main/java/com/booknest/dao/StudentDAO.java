package com.booknest.dao;

import com.booknest.model.Student;
import com.booknest.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Student Management in BookNest.
 */
public class StudentDAO {

    private static final Logger LOGGER = Logger.getLogger(StudentDAO.class.getName());

    /**
     * Retrieves all students along with their count of active issued books.
     */
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at, " +
                "COUNT(CASE WHEN ir.status = 'ISSUED' THEN 1 END) AS active_books " +
                "FROM students s " +
                "LEFT JOIN issue_records ir ON s.student_id = ir.student_id " +
                "GROUP BY s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at " +
                "ORDER BY s.student_code ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                students.add(mapResultSetToStudent(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving all students", e);
        }
        return students;
    }

    /**
     * Retrieves a student by primary key ID, including active borrowing count.
     */
    public Student getStudentById(int studentId) {
        String sql = "SELECT s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at, " +
                "COUNT(CASE WHEN ir.status = 'ISSUED' THEN 1 END) AS active_books " +
                "FROM students s " +
                "LEFT JOIN issue_records ir ON s.student_id = ir.student_id " +
                "WHERE s.student_id = ? " +
                "GROUP BY s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToStudent(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving student by ID: " + studentId, e);
        }
        return null;
    }

    /**
     * Retrieves a student by student code (Roll No).
     */
    public Student findByStudentCode(String studentCode) {
        if (studentCode == null || studentCode.trim().isEmpty()) {
            return null;
        }

        String sql = "SELECT s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at, " +
                "COUNT(CASE WHEN ir.status = 'ISSUED' THEN 1 END) AS active_books " +
                "FROM students s " +
                "LEFT JOIN issue_records ir ON s.student_id = ir.student_id " +
                "WHERE LOWER(s.student_code) = ? " +
                "GROUP BY s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentCode.trim().toLowerCase());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToStudent(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding student by code: " + studentCode, e);
        }
        return null;
    }

    /**
     * Searches students by name, student code, department, or email.
     */
    public List<Student> searchStudents(String keyword) {
        List<Student> students = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllStudents();
        }

        String sql = "SELECT s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at, " +
                "COUNT(CASE WHEN ir.status = 'ISSUED' THEN 1 END) AS active_books " +
                "FROM students s " +
                "LEFT JOIN issue_records ir ON s.student_id = ir.student_id " +
                "WHERE LOWER(s.name) LIKE ? OR LOWER(s.student_code) LIKE ? OR LOWER(s.department) LIKE ? OR LOWER(s.email) LIKE ? " +
                "GROUP BY s.student_id, s.student_code, s.name, s.email, s.phone, s.department, s.semester, s.created_at " +
                "ORDER BY s.student_code ASC";

        String searchPattern = "%" + keyword.trim().toLowerCase() + "%";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    students.add(mapResultSetToStudent(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error searching students with keyword: " + keyword, e);
        }
        return students;
    }

    /**
     * Registers a new student.
     * Validates that student code and email are not duplicates.
     */
    public boolean addStudent(Student student) throws SQLException {
        if (findByStudentCode(student.getStudentCode()) != null) {
            throw new SQLException("Student ID / Roll No '" + student.getStudentCode() + "' is already registered.");
        }

        String sql = "INSERT INTO students (student_code, name, email, phone, department, semester) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, student.getStudentCode().trim().toUpperCase());
            stmt.setString(2, student.getName().trim());
            stmt.setString(3, student.getEmail().trim().toLowerCase());
            stmt.setString(4, student.getPhone() != null ? student.getPhone().trim() : null);
            stmt.setString(5, student.getDepartment().trim());
            stmt.setInt(6, student.getSemester());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        student.setStudentId(rs.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Updates an existing student record.
     */
    public boolean updateStudent(Student student) throws SQLException {
        Student current = getStudentById(student.getStudentId());
        if (current == null) {
            throw new SQLException("Student not found with ID: " + student.getStudentId());
        }

        // Check if student code changed and conflicts with another student
        Student existingCode = findByStudentCode(student.getStudentCode());
        if (existingCode != null && existingCode.getStudentId() != student.getStudentId()) {
            throw new SQLException("Student ID / Roll No '" + student.getStudentCode() + "' is already used by another student.");
        }

        String sql = "UPDATE students SET student_code = ?, name = ?, email = ?, phone = ?, " +
                "department = ?, semester = ? WHERE student_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getStudentCode().trim().toUpperCase());
            stmt.setString(2, student.getName().trim());
            stmt.setString(3, student.getEmail().trim().toLowerCase());
            stmt.setString(4, student.getPhone() != null ? student.getPhone().trim() : null);
            stmt.setString(5, student.getDepartment().trim());
            stmt.setInt(6, student.getSemester());
            stmt.setInt(7, student.getStudentId());

            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Deletes a student if and only if they have no active issued books.
     */
    public boolean deleteStudent(int studentId) throws SQLException {
        int activeIssues = getActiveIssuesCount(studentId);
        if (activeIssues > 0) {
            throw new IllegalStateException("Cannot delete student: Student currently has " + activeIssues + " active issued book(s).");
        }

        // Clean up historical returned records if needed, then delete student
        String deleteHistorySql = "DELETE FROM issue_records WHERE student_id = ? AND status = 'RETURNED'";
        String deleteStudentSql = "DELETE FROM students WHERE student_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement delHistStmt = conn.prepareStatement(deleteHistorySql)) {
                    delHistStmt.setInt(1, studentId);
                    delHistStmt.executeUpdate();
                }

                int affected;
                try (PreparedStatement delStudStmt = conn.prepareStatement(deleteStudentSql)) {
                    delStudStmt.setInt(1, studentId);
                    affected = delStudStmt.executeUpdate();
                }

                conn.commit();
                return affected > 0;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Returns the number of currently active issued books for a student.
     */
    public int getActiveIssuesCount(int studentId) {
        String sql = "SELECT COUNT(*) FROM issue_records WHERE student_id = ? AND status = 'ISSUED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting active issues for student ID: " + studentId, e);
        }
        return 0;
    }

    /**
     * Returns total registered students count.
     */
    public int getTotalStudentsCount() {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting students", e);
        }
        return 0;
    }

    private Student mapResultSetToStudent(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setStudentId(rs.getInt("student_id"));
        student.setStudentCode(rs.getString("student_code"));
        student.setName(rs.getString("name"));
        student.setEmail(rs.getString("email"));
        student.setPhone(rs.getString("phone"));
        student.setDepartment(rs.getString("department"));
        student.setSemester(rs.getInt("semester"));
        student.setCreatedAt(rs.getTimestamp("created_at"));

        try {
            student.setActiveIssuedBooksCount(rs.getInt("active_books"));
        } catch (SQLException ignored) {
            // Column may not be present in every query
        }

        return student;
    }
}
