package com.booknest.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DatabaseConfig loads and manages the database configuration
 * from the 'db.properties' resource file.
 *
 * This allows students or evaluators to easily change their MySQL username,
 * password, or host without modifying Java source code.
 */
public class DatabaseConfig {

    private static final Logger LOGGER = Logger.getLogger(DatabaseConfig.class.getName());
    private static final Properties properties = new Properties();
    private static boolean loaded = false;

    // Load configuration once when the class is initialized
    static {
        loadProperties();
    }

    private static synchronized void loadProperties() {
        if (loaded) {
            return;
        }

        try (InputStream input = DatabaseConfig.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (input == null) {
                LOGGER.log(Level.WARNING, "db.properties not found in classpath. Using default settings.");
                setDefaultProperties();
            } else {
                properties.load(input);
                loaded = true;
                LOGGER.info("db.properties loaded successfully.");
            }
        } catch (IOException ex) {
            LOGGER.log(Level.SEVERE, "Failed to load db.properties. Falling back to defaults.", ex);
            setDefaultProperties();
        }
    }

    private static void setDefaultProperties() {
        properties.setProperty("db.driver", "com.mysql.cj.jdbc.Driver");
        properties.setProperty("db.url", "jdbc:mysql://localhost:3306/booknest?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        properties.setProperty("db.user", "root");
        properties.setProperty("db.password", "root");
        properties.setProperty("db.timeout", "5");
        loaded = true;
    }

    public static String getDriver() {
        return System.getProperty("db.driver", properties.getProperty("db.driver", "com.mysql.cj.jdbc.Driver"));
    }

    public static String getUrl() {
        return System.getProperty("db.url", properties.getProperty("db.url", "jdbc:mysql://localhost:3306/booknest?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"));
    }

    public static String getUser() {
        return System.getProperty("db.user", properties.getProperty("db.user", "root"));
    }

    public static String getPassword() {
        return System.getProperty("db.password", properties.getProperty("db.password", "root"));
    }

    public static int getTimeout() {
        try {
            return Integer.parseInt(properties.getProperty("db.timeout", "5"));
        } catch (NumberFormatException e) {
            return 5;
        }
    }

    /**
     * Allows setting custom properties (primarily used in automated tests).
     */
    public static void setCustomConfig(String driver, String url, String user, String password) {
        properties.setProperty("db.driver", driver);
        properties.setProperty("db.url", url);
        properties.setProperty("db.user", user);
        properties.setProperty("db.password", password);
        loaded = true;
    }
}
