package com.booknest.util;

import org.mindrot.jbcrypt.BCrypt;

import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Properties;

/**
 * DBConnection - Database connection and utility helper.
 * Student: Dhruv Munjal (Roll No: 24BCS10561)
 */
public class DBConnection {

    private static String url;
    private static String user;
    private static String password;
    private static String driver;

    // Load db.properties once
    static {
        try {
            Properties props = new Properties();
            InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("db.properties");
            if (in != null) {
                props.load(in);
                driver = props.getProperty("db.driver", "com.mysql.cj.jdbc.Driver");
                url = props.getProperty("db.url");
                user = props.getProperty("db.user", "root");
                password = props.getProperty("db.password", "root");
            } else {
                // Default fallback
                driver = "com.mysql.cj.jdbc.Driver";
                url = "jdbc:mysql://localhost:3306/booknest?useSSL=false&serverTimezone=UTC";
                user = "root";
                password = "root";
            }
            Class.forName(driver);
        } catch (Exception e) {
            System.err.println("Error initializing database config: " + e.getMessage());
        }
    }

    // Get a database connection
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ignored) {
        }
        return DriverManager.getConnection(url, user, password);
    }

    // Allows setting H2 in-memory URL for automated tests
    public static void setTestConfig(String testDriver, String testUrl, String testUser, String testPass) {
        driver = testDriver;
        url = testUrl;
        user = testUser;
        password = testPass;
    }

    // Safe close helper
    public static void close(AutoCloseable... closeables) {
        for (AutoCloseable c : closeables) {
            if (c != null) {
                try {
                    c.close();
                } catch (Exception ignored) {
                }
            }
        }
    }

    // --- Password Security Helpers (BCrypt) ---

    // Hashes plain text password with BCrypt
    public static String hashPassword(String plain) {
        if (plain == null || plain.trim().isEmpty()) {
            return null;
        }
        return BCrypt.hashpw(plain, BCrypt.gensalt(10));
    }

    // Verifies password against BCrypt hash
    public static boolean checkPassword(String plain, String hashed) {
        if (plain == null || hashed == null) {
            return false;
        }
        try {
            return BCrypt.checkpw(plain, hashed);
        } catch (Exception e) {
            // Fallback for plain text test strings
            return plain.equals(hashed);
        }
    }

    // --- Library Business Logic Helpers (Dates & Fines) ---

    // Standard loan period is 14 days
    public static LocalDate calculateDueDate(LocalDate issueDate) {
        if (issueDate == null) issueDate = LocalDate.now();
        return issueDate.plusDays(14);
    }

    // Overdue days calculation
    public static long getOverdueDays(LocalDate dueDate, LocalDate returnDate) {
        if (dueDate == null) return 0;
        if (returnDate == null) returnDate = LocalDate.now();
        if (returnDate.isAfter(dueDate)) {
            return ChronoUnit.DAYS.between(dueDate, returnDate);
        }
        return 0;
    }

    // Fine calculation: Rs 2 per day overdue
    public static BigDecimal calculateFine(LocalDate dueDate, LocalDate returnDate) {
        long days = getOverdueDays(dueDate, returnDate);
        if (days <= 0) {
            return new BigDecimal("0.00");
        }
        return BigDecimal.valueOf(days * 2.0).setScale(2);
    }
}
