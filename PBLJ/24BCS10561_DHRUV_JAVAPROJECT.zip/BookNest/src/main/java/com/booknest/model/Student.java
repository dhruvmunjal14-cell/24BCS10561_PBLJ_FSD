package com.booknest.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Model representing a Student in BookNest.
 */
public class Student implements Serializable {

    private static final long serialVersionUID = 1L;

    private int studentId;
    private String studentCode; // E.g. "CS2023001" or Roll Number
    private String name;
    private String email;
    private String phone;
    private String department;
    private int semester;
    private Timestamp createdAt;

    // Helper property to display current active borrowings
    private int activeIssuedBooksCount = 0;

    public Student() {
    }

    public Student(int studentId, String studentCode, String name, String email, String phone,
                   String department, int semester, Timestamp createdAt) {
        this.studentId = studentId;
        this.studentCode = studentCode;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.semester = semester;
        this.createdAt = createdAt;
    }

    public Student(String studentCode, String name, String email, String phone,
                   String department, int semester) {
        this.studentCode = studentCode;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.semester = semester;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public int getActiveIssuedBooksCount() {
        return activeIssuedBooksCount;
    }

    public void setActiveIssuedBooksCount(int activeIssuedBooksCount) {
        this.activeIssuedBooksCount = activeIssuedBooksCount;
    }

    // Business helpers
    public boolean canIssueMore() {
        return activeIssuedBooksCount < 3;
    }

    public int getRemainingIssueQuota() {
        return Math.max(0, 3 - activeIssuedBooksCount);
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentCode='" + studentCode + '\'' +
                ", name='" + name + '\'' +
                ", department='" + department + '\'' +
                ", semester=" + semester +
                '}';
    }
}
