package com.booknest.controller;

import com.booknest.dao.StudentDAO;
import com.booknest.model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * StudentServlet handles Student Registration, Updating, Deletion, and Searching.
 */
@WebServlet(urlPatterns = {"/students"})
public class StudentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        this.studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "new":
                showAddForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteStudent(request, response);
                break;
            case "list":
            default:
                listStudents(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if ("insert".equals(action)) {
            insertStudent(request, response);
        } else if ("update".equals(action)) {
            updateStudent(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/students");
        }
    }

    private void listStudents(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String search = request.getParameter("search");
        List<Student> students;

        if (search != null && !search.trim().isEmpty()) {
            students = studentDAO.searchStudents(search.trim());
            request.setAttribute("searchQuery", search.trim());
        } else {
            students = studentDAO.getAllStudents();
        }

        request.setAttribute("students", students);
        request.getRequestDispatcher("/WEB-INF/views/students/list.jsp").forward(request, response);
    }

    private void showAddForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/students/add.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }

        try {
            int studentId = Integer.parseInt(idParam);
            Student student = studentDAO.getStudentById(studentId);
            if (student == null) {
                request.getSession().setAttribute("errorMessage", "Student not found with ID: " + studentId);
                response.sendRedirect(request.getContextPath() + "/students");
                return;
            }
            request.setAttribute("student", student);
            request.getRequestDispatcher("/WEB-INF/views/students/edit.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/students");
        }
    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentCode = request.getParameter("studentCode");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String department = request.getParameter("department");
        String semesterParam = request.getParameter("semester");

        // Validate required fields
        if (studentCode == null || studentCode.trim().isEmpty() ||
                name == null || name.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                department == null || department.trim().isEmpty()) {

            request.setAttribute("errorMessage", "Student ID, Name, Email, and Department are required.");
            populateForm(request, studentCode, name, email, phone, department, semesterParam);
            request.getRequestDispatcher("/WEB-INF/views/students/add.jsp").forward(request, response);
            return;
        }

        int semester = 1;
        try {
            if (semesterParam != null && !semesterParam.trim().isEmpty()) {
                semester = Integer.parseInt(semesterParam.trim());
                if (semester < 1 || semester > 8) {
                    throw new NumberFormatException();
                }
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Semester must be a valid number between 1 and 8.");
            populateForm(request, studentCode, name, email, phone, department, semesterParam);
            request.getRequestDispatcher("/WEB-INF/views/students/add.jsp").forward(request, response);
            return;
        }

        Student student = new Student(studentCode.trim().toUpperCase(), name.trim(), email.trim(), phone, department.trim(), semester);

        try {
            boolean success = studentDAO.addStudent(student);
            if (success) {
                request.getSession().setAttribute("successMessage", "Student '" + name + "' registered successfully!");
                response.sendRedirect(request.getContextPath() + "/students");
            } else {
                request.setAttribute("errorMessage", "Failed to register student. Please try again.");
                populateForm(request, studentCode, name, email, phone, department, semesterParam);
                request.getRequestDispatcher("/WEB-INF/views/students/add.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", e.getMessage());
            populateForm(request, studentCode, name, email, phone, department, semesterParam);
            request.getRequestDispatcher("/WEB-INF/views/students/add.jsp").forward(request, response);
        }
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("studentId");
        String studentCode = request.getParameter("studentCode");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String department = request.getParameter("department");
        String semesterParam = request.getParameter("semester");

        int studentId;
        try {
            studentId = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }

        if (studentCode == null || studentCode.trim().isEmpty() ||
                name == null || name.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                department == null || department.trim().isEmpty()) {

            request.setAttribute("errorMessage", "All required fields must be filled.");
            request.setAttribute("student", studentDAO.getStudentById(studentId));
            request.getRequestDispatcher("/WEB-INF/views/students/edit.jsp").forward(request, response);
            return;
        }

        int semester = 1;
        try {
            if (semesterParam != null && !semesterParam.trim().isEmpty()) {
                semester = Integer.parseInt(semesterParam.trim());
            }
        } catch (NumberFormatException ignored) {
        }

        Student student = new Student();
        student.setStudentId(studentId);
        student.setStudentCode(studentCode.trim().toUpperCase());
        student.setName(name.trim());
        student.setEmail(email.trim());
        student.setPhone(phone);
        student.setDepartment(department.trim());
        student.setSemester(semester);

        try {
            boolean success = studentDAO.updateStudent(student);
            if (success) {
                request.getSession().setAttribute("successMessage", "Student '" + name + "' updated successfully!");
                response.sendRedirect(request.getContextPath() + "/students");
            } else {
                request.setAttribute("errorMessage", "Failed to update student.");
                request.setAttribute("student", student);
                request.getRequestDispatcher("/WEB-INF/views/students/edit.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            request.setAttribute("errorMessage", e.getMessage());
            request.setAttribute("student", studentDAO.getStudentById(studentId));
            request.getRequestDispatcher("/WEB-INF/views/students/edit.jsp").forward(request, response);
        }
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/students");
            return;
        }

        try {
            int studentId = Integer.parseInt(idParam);
            boolean deleted = studentDAO.deleteStudent(studentId);
            if (deleted) {
                request.getSession().setAttribute("successMessage", "Student record deleted successfully.");
            } else {
                request.getSession().setAttribute("errorMessage", "Student could not be found or deleted.");
            }
        } catch (IllegalStateException e) {
            request.getSession().setAttribute("errorMessage", e.getMessage());
        } catch (SQLException e) {
            request.getSession().setAttribute("errorMessage", "Database error while deleting student: " + e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/students");
    }

    private void populateForm(HttpServletRequest request, String code, String name, String email,
                              String phone, String dept, String sem) {
        request.setAttribute("form_studentCode", code);
        request.setAttribute("form_name", name);
        request.setAttribute("form_email", email);
        request.setAttribute("form_phone", phone);
        request.setAttribute("form_department", dept);
        request.setAttribute("form_semester", sem);
    }
}
