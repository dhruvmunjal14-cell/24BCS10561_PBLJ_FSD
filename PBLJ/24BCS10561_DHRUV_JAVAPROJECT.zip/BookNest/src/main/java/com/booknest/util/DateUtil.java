package com.booknest.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * DateUtil handles date calculations and fine computation for BookNest.
 *
 * Rules:
 * - Default loan period: 14 days.
 * - Fine rate: ₹2.00 per day overdue.
 */
public class DateUtil {

    public static final int DEFAULT_LOAN_DAYS = 14;
    public static final BigDecimal FINE_RATE_PER_DAY = new BigDecimal("2.00");

    public static final DateTimeFormatter ISO_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DISPLAY_FORMATTER = DateTimeFormatter.ofPattern("dd MMM yyyy");

    private DateUtil() {
        // Utility class
    }

    /**
     * Calculates the due date from an issue date using the default 14-day loan period.
     */
    public static LocalDate calculateDueDate(LocalDate issueDate) {
        if (issueDate == null) {
            issueDate = LocalDate.now();
        }
        return issueDate.plusDays(DEFAULT_LOAN_DAYS);
    }

    /**
     * Calculates overdue days between due date and return date (or current date if not yet returned).
     *
     * @param dueDate the due date
     * @param targetDate the return date, or current date if still active
     * @return number of days overdue (0 if not overdue)
     */
    public static long calculateOverdueDays(LocalDate dueDate, LocalDate targetDate) {
        if (dueDate == null) {
            return 0;
        }
        if (targetDate == null) {
            targetDate = LocalDate.now();
        }

        if (targetDate.isAfter(dueDate)) {
            return ChronoUnit.DAYS.between(dueDate, targetDate);
        }
        return 0;
    }

    /**
     * Calculates fine amount based on overdue days.
     * Fine = overdueDays * ₹2.00
     *
     * @param dueDate the date the book was due
     * @param targetDate the return date or today's date
     * @return calculated fine as BigDecimal rounded to 2 decimal places
     */
    public static BigDecimal calculateFine(LocalDate dueDate, LocalDate targetDate) {
        long overdueDays = calculateOverdueDays(dueDate, targetDate);
        if (overdueDays <= 0) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
        return FINE_RATE_PER_DAY.multiply(BigDecimal.valueOf(overdueDays)).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Checks if a book is overdue as of today.
     */
    public static boolean isOverdue(LocalDate dueDate) {
        if (dueDate == null) {
            return false;
        }
        return LocalDate.now().isAfter(dueDate);
    }

    /**
     * Formats LocalDate for HTML5 date input (yyyy-MM-dd).
     */
    public static String formatIso(LocalDate date) {
        if (date == null) {
            return "";
        }
        return date.format(ISO_FORMATTER);
    }

    /**
     * Formats LocalDate for human-readable display (dd MMM yyyy).
     */
    public static String formatDisplay(LocalDate date) {
        if (date == null) {
            return "-";
        }
        return date.format(DISPLAY_FORMATTER);
    }

    /**
     * Parses a string in yyyy-MM-dd format into LocalDate safely.
     */
    public static LocalDate parseIso(String text) {
        if (text == null || text.trim().isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(text.trim(), ISO_FORMATTER);
        } catch (Exception e) {
            return null;
        }
    }
}
