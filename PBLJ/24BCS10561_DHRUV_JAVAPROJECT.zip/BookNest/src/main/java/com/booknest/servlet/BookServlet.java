package com.booknest.servlet;

import com.booknest.dao.BookDAO;
import com.booknest.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * BookServlet - Handles adding, viewing, editing, deleting and searching books.
 * Student: Dhruv Munjal (24BCS10561)
 */
@WebServlet(urlPatterns = {"/books"})
public class BookServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private BookDAO bookDAO;

    @Override
    public void init() {
        this.bookDAO = new BookDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if ("delete".equals(action)) {
            handleDelete(request, response);
            return;
        }

        // List or Search
        String search = request.getParameter("search");
        List<Book> books;
        if (search != null && !search.trim().isEmpty()) {
            books = bookDAO.searchBooks(search.trim());
            request.setAttribute("searchQuery", search.trim());
        } else {
            books = bookDAO.getAllBooks();
        }

        // Check if an edit book is requested
        String editIdParam = request.getParameter("editId");
        if (editIdParam != null && !editIdParam.trim().isEmpty()) {
            try {
                int editId = Integer.parseInt(editIdParam);
                Book editBook = bookDAO.getBookById(editId);
                request.setAttribute("editBook", editBook);
            } catch (Exception ignored) {
            }
        }

        request.setAttribute("books", books);
        request.getRequestDispatcher("/books.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            handleAdd(request, response);
        } else if ("update".equals(action)) {
            handleUpdate(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/books");
        }
    }

    private void handleAdd(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        String copiesParam = request.getParameter("copies");

        try {
            int copies = Integer.parseInt(copiesParam.trim());
            if (copies <= 0) copies = 1;

            Book book = new Book(isbn.trim(), title.trim(), author.trim(), category, publisher, null, copies, copies);
            bookDAO.addBook(book);

            request.getSession().setAttribute("msgSuccess", "Book '" + title + "' added successfully!");
            response.sendRedirect(request.getContextPath() + "/books");
        } catch (SQLException | IllegalArgumentException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
            response.sendRedirect(request.getContextPath() + "/books");
        }
    }

    private void handleUpdate(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        int copies = Integer.parseInt(request.getParameter("copies").trim());

        Book book = new Book();
        book.setBookId(bookId);
        book.setIsbn(isbn.trim());
        book.setTitle(title.trim());
        book.setAuthor(author.trim());
        book.setCategory(category);
        book.setPublisher(publisher);
        book.setTotalCopies(copies);

        try {
            bookDAO.updateBook(book);
            request.getSession().setAttribute("msgSuccess", "Book '" + title + "' updated successfully!");
        } catch (SQLException | IllegalArgumentException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/books");
    }

    private void handleDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));
            bookDAO.deleteBook(id);
            request.getSession().setAttribute("msgSuccess", "Book deleted successfully.");
        } catch (IllegalStateException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        } catch (Exception e) {
            request.getSession().setAttribute("msgError", "Could not delete book: " + e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/books");
    }
}
