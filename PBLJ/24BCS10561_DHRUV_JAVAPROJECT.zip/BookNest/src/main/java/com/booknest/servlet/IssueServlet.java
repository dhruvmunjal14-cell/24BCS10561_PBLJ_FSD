package com.booknest.servlet;

import com.booknest.dao.BookDAO;
import com.booknest.dao.IssueDAO;
import com.booknest.dao.StudentDAO;
import com.booknest.model.Book;
import com.booknest.model.IssueRecord;
import com.booknest.model.Student;
import com.booknest.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * IssueServlet - Handles book issue and return transactions.
 * Student: Dhruv Munjal (24BCS10561)
 */
@WebServlet(urlPatterns = {"/issues"})
public class IssueServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private IssueDAO issueDAO;
    private BookDAO bookDAO;
    private StudentDAO studentDAO;

    @Override
    public void init() {
        this.issueDAO = new IssueDAO();
        this.bookDAO = new BookDAO();
        this.studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String filter = request.getParameter("filter");
        if (filter == null || filter.trim().isEmpty()) {
            filter = "ALL";
        }

        List<IssueRecord> issues = issueDAO.getIssues(filter);
        List<Book> availableBooks = bookDAO.getAvailableBooks();
        List<Student> students = studentDAO.getAllStudents();

        request.setAttribute("issues", issues);
        request.setAttribute("currentFilter", filter);
        request.setAttribute("availableBooks", availableBooks);
        request.setAttribute("students", students);

        // Default dates for the form
        LocalDate today = LocalDate.now();
        request.setAttribute("todayDate", today.toString());
        request.setAttribute("dueDate", DBConnection.calculateDueDate(today).toString());

        request.getRequestDispatcher("/issues.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("issue".equals(action)) {
            handleIssue(request, response);
        } else if ("return".equals(action)) {
            handleReturn(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/issues");
        }
    }

    private void handleIssue(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int bookId = Integer.parseInt(request.getParameter("bookId"));
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            String issueDateStr = request.getParameter("issueDate");
            String dueDateStr = request.getParameter("dueDate");
            String remarks = request.getParameter("remarks");

            LocalDate issueDate = (issueDateStr != null && !issueDateStr.isEmpty()) ? LocalDate.parse(issueDateStr) : LocalDate.now();
            LocalDate dueDate = (dueDateStr != null && !dueDateStr.isEmpty()) ? LocalDate.parse(dueDateStr) : DBConnection.calculateDueDate(issueDate);

            issueDAO.issueBook(bookId, studentId, issueDate, dueDate, remarks);
            request.getSession().setAttribute("msgSuccess", "Book issued successfully! Due date: " + dueDate);
        } catch (IllegalStateException | IllegalArgumentException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        } catch (Exception e) {
            request.getSession().setAttribute("msgError", "Could not issue book: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/issues");
    }

    private void handleReturn(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int issueId = Integer.parseInt(request.getParameter("issueId"));
            String returnDateStr = request.getParameter("returnDate");
            String remarks = request.getParameter("remarks");

            LocalDate returnDate = (returnDateStr != null && !returnDateStr.isEmpty()) ? LocalDate.parse(returnDateStr) : LocalDate.now();

            BigDecimal fine = issueDAO.returnBook(issueId, returnDate, remarks);

            if (fine.compareTo(BigDecimal.ZERO) > 0) {
                request.getSession().setAttribute("msgSuccess", "Book returned! Overdue fine of Rs " + fine + " collected.");
            } else {
                request.getSession().setAttribute("msgSuccess", "Book returned on time (No fine).");
            }
        } catch (IllegalStateException | IllegalArgumentException e) {
            request.getSession().setAttribute("msgError", e.getMessage());
        } catch (Exception e) {
            request.getSession().setAttribute("msgError", "Error returning book: " + e.getMessage());
        }

        response.sendRedirect(request.getContextPath() + "/issues");
    }
}
