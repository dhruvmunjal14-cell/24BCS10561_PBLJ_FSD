package com.booknest.controller;

import com.booknest.dao.BookDAO;
import com.booknest.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * BookServlet manages CRUD operations and search for Books.
 */
@WebServlet(urlPatterns = {"/books"})
public class BookServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private BookDAO bookDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        this.bookDAO = new BookDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "new":
                showAddForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteBook(request, response);
                break;
            case "list":
            default:
                listBooks(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if ("insert".equals(action)) {
            insertBook(request, response);
        } else if ("update".equals(action)) {
            updateBook(request, response);
        } else {
            response.sendRedirect(request.getContextPath() + "/books");
        }
    }

    private void listBooks(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String search = request.getParameter("search");
        List<Book> books;

        if (search != null && !search.trim().isEmpty()) {
            books = bookDAO.searchBooks(search.trim());
            request.setAttribute("searchQuery", search.trim());
        } else {
            books = bookDAO.getAllBooks();
        }

        request.setAttribute("books", books);
        request.getRequestDispatcher("/WEB-INF/views/books/list.jsp").forward(request, response);
    }

    private void showAddForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        try {
            int bookId = Integer.parseInt(idParam);
            Book book = bookDAO.getBookById(bookId);
            if (book == null) {
                request.getSession().setAttribute("errorMessage", "Book not found with ID: " + bookId);
                response.sendRedirect(request.getContextPath() + "/books");
                return;
            }
            request.setAttribute("book", book);
            request.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/books");
        }
    }

    private void insertBook(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        String yearParam = request.getParameter("publicationYear");
        String copiesParam = request.getParameter("totalCopies");

        // Input validation
        if (isbn == null || isbn.trim().isEmpty() ||
                title == null || title.trim().isEmpty() ||
                author == null || author.trim().isEmpty()) {

            request.setAttribute("errorMessage", "ISBN, Title, and Author are mandatory fields.");
            populateFormAttributes(request, isbn, title, author, category, publisher, yearParam, copiesParam);
            request.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(request, response);
            return;
        }

        int totalCopies = 1;
        try {
            if (copiesParam != null && !copiesParam.trim().isEmpty()) {
                totalCopies = Integer.parseInt(copiesParam.trim());
                if (totalCopies <= 0) {
                    throw new NumberFormatException();
                }
            }
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Total copies must be a positive integer (minimum 1).");
            populateFormAttributes(request, isbn, title, author, category, publisher, yearParam, copiesParam);
            request.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(request, response);
            return;
        }

        Integer pubYear = null;
        if (yearParam != null && !yearParam.trim().isEmpty()) {
            try {
                pubYear = Integer.parseInt(yearParam.trim());
            } catch (NumberFormatException ignored) {
            }
        }

        Book book = new Book(isbn.trim(), title.trim(), author.trim(), category, publisher, pubYear, totalCopies, totalCopies);

        try {
            boolean success = bookDAO.addBook(book);
            if (success) {
                request.getSession().setAttribute("successMessage", "Book '" + title + "' added successfully!");
                response.sendRedirect(request.getContextPath() + "/books");
            } else {
                request.setAttribute("errorMessage", "Failed to add book. Please try again.");
                populateFormAttributes(request, isbn, title, author, category, publisher, yearParam, copiesParam);
                request.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(request, response);
            }
        } catch (SQLException | IllegalArgumentException e) {
            request.setAttribute("errorMessage", e.getMessage());
            populateFormAttributes(request, isbn, title, author, category, publisher, yearParam, copiesParam);
            request.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(request, response);
        }
    }

    private void updateBook(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("bookId");
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String publisher = request.getParameter("publisher");
        String yearParam = request.getParameter("publicationYear");
        String copiesParam = request.getParameter("totalCopies");

        int bookId;
        try {
            bookId = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        if (isbn == null || isbn.trim().isEmpty() ||
                title == null || title.trim().isEmpty() ||
                author == null || author.trim().isEmpty()) {

            request.setAttribute("errorMessage", "ISBN, Title, and Author are mandatory fields.");
            request.setAttribute("book", bookDAO.getBookById(bookId));
            request.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(request, response);
            return;
        }

        int totalCopies = 1;
        try {
            totalCopies = Integer.parseInt(copiesParam.trim());
            if (totalCopies <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Total copies must be a positive integer.");
            request.setAttribute("book", bookDAO.getBookById(bookId));
            request.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(request, response);
            return;
        }

        Integer pubYear = null;
        if (yearParam != null && !yearParam.trim().isEmpty()) {
            try {
                pubYear = Integer.parseInt(yearParam.trim());
            } catch (NumberFormatException ignored) {
            }
        }

        Book book = new Book();
        book.setBookId(bookId);
        book.setIsbn(isbn.trim());
        book.setTitle(title.trim());
        book.setAuthor(author.trim());
        book.setCategory(category);
        book.setPublisher(publisher);
        book.setPublicationYear(pubYear);
        book.setTotalCopies(totalCopies);

        try {
            boolean success = bookDAO.updateBook(book);
            if (success) {
                request.getSession().setAttribute("successMessage", "Book '" + title + "' updated successfully!");
                response.sendRedirect(request.getContextPath() + "/books");
            } else {
                request.setAttribute("errorMessage", "Failed to update book.");
                request.setAttribute("book", book);
                request.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(request, response);
            }
        } catch (SQLException | IllegalArgumentException e) {
            request.setAttribute("errorMessage", e.getMessage());
            request.setAttribute("book", bookDAO.getBookById(bookId));
            request.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(request, response);
        }
    }

    private void deleteBook(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String idParam = request.getParameter("id");
        if (idParam == null || idParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/books");
            return;
        }

        try {
            int bookId = Integer.parseInt(idParam);
            boolean deleted = bookDAO.deleteBook(bookId);
            if (deleted) {
                request.getSession().setAttribute("successMessage", "Book deleted successfully.");
            } else {
                request.getSession().setAttribute("errorMessage", "Book could not be found or deleted.");
            }
        } catch (IllegalStateException e) {
            request.getSession().setAttribute("errorMessage", e.getMessage());
        } catch (SQLException e) {
            request.getSession().setAttribute("errorMessage", "Database error while deleting book: " + e.getMessage());
        }
        response.sendRedirect(request.getContextPath() + "/books");
    }

    private void populateFormAttributes(HttpServletRequest request, String isbn, String title,
                                        String author, String category, String publisher,
                                        String year, String copies) {
        request.setAttribute("form_isbn", isbn);
        request.setAttribute("form_title", title);
        request.setAttribute("form_author", author);
        request.setAttribute("form_category", category);
        request.setAttribute("form_publisher", publisher);
        request.setAttribute("form_year", year);
        request.setAttribute("form_copies", copies);
    }
}
