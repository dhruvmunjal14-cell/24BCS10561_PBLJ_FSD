package com.booknest.util;

import org.mindrot.jbcrypt.BCrypt;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * PasswordUtil provides secure password hashing and verification using BCrypt.
 *
 * BCrypt includes an adaptive work factor (salt rounds) and automatically
 * salts every hash, preventing dictionary and rainbow-table attacks.
 */
public class PasswordUtil {

    private static final int BCRYPT_LOG_ROUNDS = 10;

    private PasswordUtil() {
        // Utility class
    }

    /**
     * Hashes a plain-text password using BCrypt with a default workload of 10 rounds.
     *
     * @param plainPassword the plain-text password
     * @return 60-character BCrypt hashed string
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null || plainPassword.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be null or empty");
        }
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(BCRYPT_LOG_ROUNDS));
    }

    /**
     * Verifies a plain-text candidate password against a stored hash.
     * Supports BCrypt hashes, with a graceful fallback for SHA-256 in legacy environments.
     *
     * @param plainPassword  the candidate plain-text password
     * @param storedHash the hash from the database
     * @return true if candidate matches stored hash, false otherwise
     */
    public static boolean checkPassword(String plainPassword, String storedHash) {
        if (plainPassword == null || storedHash == null || storedHash.isEmpty()) {
            return false;
        }

        // BCrypt hashes start with $2a$, $2b$, or $2y$ and are 60 characters long
        if (storedHash.startsWith("$2a$") || storedHash.startsWith("$2b$") || storedHash.startsWith("$2y$")) {
            try {
                return BCrypt.checkpw(plainPassword, storedHash);
            } catch (Exception e) {
                return false;
            }
        }

        // Fallback for standard SHA-256 hex string (64 characters)
        if (storedHash.length() == 64) {
            String sha256 = sha256Hex(plainPassword);
            return sha256.equalsIgnoreCase(storedHash);
        }

        // Final fallback: direct comparison (for local test setups only)
        return plainPassword.equals(storedHash);
    }

    /**
     * Utility method for SHA-256 hashing if needed.
     */
    public static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    /**
     * CLI utility to generate BCrypt hashes from the command line.
     * Usage: java -cp target/booknest/WEB-INF/classes:... com.booknest.util.PasswordUtil [password]
     */
    public static void main(String[] args) {
        String pass = (args.length > 0) ? args[0] : "admin123";
        String hashed = hashPassword(pass);
        System.out.println("Plaintext: " + pass);
        System.out.println("BCrypt Hash: " + hashed);
        System.out.println("Verified: " + checkPassword(pass, hashed));
    }
}
