package com.booknest.model;

import com.booknest.util.DBConnection;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * IssueRecord Model - Represents book loans and returns.
 * Student: Dhruv Munjal (24BCS10561)
 */
public class IssueRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private int issueId;
    private int bookId;
    private int studentId;
    private LocalDate issueDate;
    private LocalDate dueDate;
    private LocalDate returnDate;
    private BigDecimal fineAmount = BigDecimal.ZERO;
    private String status = "ISSUED"; // ISSUED or RETURNED
    private String remarks;
    private Timestamp createdAt;

    // Joined fields from book & student for easy display in JSP table
    private String bookTitle;
    private String bookIsbn;
    private String studentName;
    private String studentCode;
    private String studentDepartment;

    public IssueRecord() {
    }

    public IssueRecord(int issueId, int bookId, int studentId, LocalDate issueDate,
                       LocalDate dueDate, LocalDate returnDate, BigDecimal fineAmount,
                       String status, String remarks, Timestamp createdAt) {
        this.issueId = issueId;
        this.bookId = bookId;
        this.studentId = studentId;
        this.issueDate = issueDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.fineAmount = fineAmount != null ? fineAmount : BigDecimal.ZERO;
        this.status = status;
        this.remarks = remarks;
        this.createdAt = createdAt;
    }

    public int getIssueId() {
        return issueId;
    }

    public void setIssueId(int issueId) {
        this.issueId = issueId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public BigDecimal getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(BigDecimal fineAmount) {
        this.fineAmount = fineAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookIsbn() {
        return bookIsbn;
    }

    public void setBookIsbn(String bookIsbn) {
        this.bookIsbn = bookIsbn;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getStudentDepartment() {
        return studentDepartment;
    }

    public void setStudentDepartment(String studentDepartment) {
        this.studentDepartment = studentDepartment;
    }

    // Helper: checks if overdue
    public boolean isOverdue() {
        if ("RETURNED".equalsIgnoreCase(status)) return false;
        return dueDate != null && LocalDate.now().isAfter(dueDate);
    }

    // Helper: get overdue days
    public long getOverdueDays() {
        LocalDate target = "RETURNED".equalsIgnoreCase(status) ? returnDate : LocalDate.now();
        return DBConnection.getOverdueDays(dueDate, target);
    }

    // Helper: get current fine
    public BigDecimal getComputedFine() {
        if ("RETURNED".equalsIgnoreCase(status)) {
            return fineAmount != null ? fineAmount : BigDecimal.ZERO;
        }
        return DBConnection.calculateFine(dueDate, LocalDate.now());
    }

    public String getFormattedIssueDate() {
        return formatDate(issueDate);
    }

    public String getFormattedDueDate() {
        return formatDate(dueDate);
    }

    public String getFormattedReturnDate() {
        return returnDate != null ? formatDate(returnDate) : "-";
    }

    private String formatDate(LocalDate date) {
        if (date == null) return "-";
        return date.format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
    }
}
