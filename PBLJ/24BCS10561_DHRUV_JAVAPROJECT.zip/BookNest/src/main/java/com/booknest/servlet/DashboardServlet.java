package com.booknest.servlet;

import com.booknest.dao.BookDAO;
import com.booknest.dao.IssueDAO;
import com.booknest.dao.StudentDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * DashboardServlet - Prepares counts and statistics for the main dashboard screen.
 * Student: Dhruv Munjal (24BCS10561)
 */
@WebServlet(urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private BookDAO bookDAO;
    private StudentDAO studentDAO;
    private IssueDAO issueDAO;

    @Override
    public void init() {
        this.bookDAO = new BookDAO();
        this.studentDAO = new StudentDAO();
        this.issueDAO = new IssueDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Fetch counts for stat cards
        request.setAttribute("totalBooks", bookDAO.getTotalCopiesCount());
        request.setAttribute("availableBooks", bookDAO.getAvailableCopiesCount());
        request.setAttribute("issuedBooks", issueDAO.getIssuedCount());
        request.setAttribute("totalStudents", studentDAO.getTotalStudentsCount());
        request.setAttribute("overdueBooks", issueDAO.getOverdueCount());

        // Recent 5 issues for activity table
        request.setAttribute("recentIssues", issueDAO.getRecentIssues(5));

        request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
    }
}
