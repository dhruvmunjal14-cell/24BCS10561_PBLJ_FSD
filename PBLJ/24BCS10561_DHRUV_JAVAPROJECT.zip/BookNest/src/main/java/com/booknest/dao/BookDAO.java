package com.booknest.dao;

import com.booknest.model.Book;
import com.booknest.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Book Management in BookNest.
 */
public class BookDAO {

    private static final Logger LOGGER = Logger.getLogger(BookDAO.class.getName());

    /**
     * Retrieves all books ordered by title.
     */
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT book_id, isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies, created_at FROM books ORDER BY title ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                books.add(mapResultSetToBook(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving all books", e);
        }
        return books;
    }

    /**
     * Retrieves only books that currently have at least one copy available.
     */
    public List<Book> getAvailableBooks() {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT book_id, isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies, created_at FROM books WHERE available_copies > 0 ORDER BY title ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                books.add(mapResultSetToBook(rs));
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving available books", e);
        }
        return books;
    }

    /**
     * Retrieves a book by its primary key ID.
     */
    public Book getBookById(int bookId) {
        String sql = "SELECT book_id, isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies, created_at FROM books WHERE book_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bookId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBook(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving book by ID: " + bookId, e);
        }
        return null;
    }

    /**
     * Retrieves a book by its ISBN number.
     */
    public Book findByIsbn(String isbn) {
        if (isbn == null || isbn.trim().isEmpty()) {
            return null;
        }

        String sql = "SELECT book_id, isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies, created_at FROM books WHERE isbn = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, isbn.trim());
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBook(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding book by ISBN: " + isbn, e);
        }
        return null;
    }

    /**
     * Searches books by title, author, ISBN, or category.
     */
    public List<Book> searchBooks(String keyword) {
        List<Book> books = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllBooks();
        }

        String sql = "SELECT book_id, isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies, created_at FROM books " +
                "WHERE LOWER(title) LIKE ? OR LOWER(author) LIKE ? OR LOWER(isbn) LIKE ? OR LOWER(category) LIKE ? " +
                "ORDER BY title ASC";

        String searchPattern = "%" + keyword.trim().toLowerCase() + "%";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, searchPattern);
            stmt.setString(2, searchPattern);
            stmt.setString(3, searchPattern);
            stmt.setString(4, searchPattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    books.add(mapResultSetToBook(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error searching books with keyword: " + keyword, e);
        }
        return books;
    }

    /**
     * Adds a new book to the library inventory.
     * Available copies is initialized equal to total copies.
     */
    public boolean addBook(Book book) throws SQLException {
        if (book.getTotalCopies() <= 0) {
            throw new IllegalArgumentException("Total copies must be at least 1");
        }

        // Check for duplicate ISBN
        Book existing = findByIsbn(book.getIsbn());
        if (existing != null) {
            throw new SQLException("A book with ISBN '" + book.getIsbn() + "' already exists.");
        }

        String sql = "INSERT INTO books (isbn, title, author, category, publisher, publication_year, " +
                "total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, book.getIsbn().trim());
            stmt.setString(2, book.getTitle().trim());
            stmt.setString(3, book.getAuthor().trim());
            stmt.setString(4, book.getCategory() != null ? book.getCategory().trim() : "General");
            stmt.setString(5, book.getPublisher() != null ? book.getPublisher().trim() : null);

            if (book.getPublicationYear() != null && book.getPublicationYear() > 0) {
                stmt.setInt(6, book.getPublicationYear());
            } else {
                stmt.setNull(6, Types.INTEGER);
            }

            stmt.setInt(7, book.getTotalCopies());
            stmt.setInt(8, book.getTotalCopies()); // When added, all copies are available

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        book.setBookId(rs.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Updates an existing book.
     * Preserves copy count integrity: total copies cannot be reduced below the number of currently issued copies.
     */
    public boolean updateBook(Book book) throws SQLException {
        Book current = getBookById(book.getBookId());
        if (current == null) {
            throw new SQLException("Book not found with ID: " + book.getBookId());
        }

        // Duplicate ISBN check (if changed)
        Book existingWithIsbn = findByIsbn(book.getIsbn());
        if (existingWithIsbn != null && existingWithIsbn.getBookId() != book.getBookId()) {
            throw new SQLException("ISBN '" + book.getIsbn() + "' is already assigned to another book.");
        }

        int currentlyIssued = current.getTotalCopies() - current.getAvailableCopies();
        if (book.getTotalCopies() < currentlyIssued) {
            throw new IllegalArgumentException("Cannot reduce total copies to " + book.getTotalCopies() +
                    " because " + currentlyIssued + " copies are currently issued to students.");
        }

        int newAvailableCopies = book.getTotalCopies() - currentlyIssued;

        String sql = "UPDATE books SET isbn = ?, title = ?, author = ?, category = ?, publisher = ?, " +
                "publication_year = ?, total_copies = ?, available_copies = ? WHERE book_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, book.getIsbn().trim());
            stmt.setString(2, book.getTitle().trim());
            stmt.setString(3, book.getAuthor().trim());
            stmt.setString(4, book.getCategory() != null ? book.getCategory().trim() : "General");
            stmt.setString(5, book.getPublisher() != null ? book.getPublisher().trim() : null);

            if (book.getPublicationYear() != null && book.getPublicationYear() > 0) {
                stmt.setInt(6, book.getPublicationYear());
            } else {
                stmt.setNull(6, Types.INTEGER);
            }

            stmt.setInt(7, book.getTotalCopies());
            stmt.setInt(8, newAvailableCopies);
            stmt.setInt(9, book.getBookId());

            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Deletes a book if and only if no copies are currently issued.
     */
    public boolean deleteBook(int bookId) throws SQLException {
        // 1. Check if any copies are currently issued
        String checkIssuedSql = "SELECT COUNT(*) FROM issue_records WHERE book_id = ? AND status = 'ISSUED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkIssuedSql)) {

            checkStmt.setInt(1, bookId);
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    throw new IllegalStateException("Cannot delete book: " + rs.getInt(1) + " copies are currently issued.");
                }
            }
        }

        // 2. Delete past historical issue records first if foreign key requires it, or delete directly
        String deleteHistorySql = "DELETE FROM issue_records WHERE book_id = ? AND status = 'RETURNED'";
        String deleteBookSql = "DELETE FROM books WHERE book_id = ?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement delHistStmt = conn.prepareStatement(deleteHistorySql)) {
                    delHistStmt.setInt(1, bookId);
                    delHistStmt.executeUpdate();
                }

                int affected;
                try (PreparedStatement delBookStmt = conn.prepareStatement(deleteBookSql)) {
                    delBookStmt.setInt(1, bookId);
                    affected = delBookStmt.executeUpdate();
                }

                conn.commit();
                return affected > 0;
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    /**
     * Total physical book copies in library.
     */
    public int getTotalCopiesCount() {
        String sql = "SELECT COALESCE(SUM(total_copies), 0) FROM books";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting total book copies", e);
        }
        return 0;
    }

    /**
     * Total distinct book titles in library.
     */
    public int getTotalTitlesCount() {
        String sql = "SELECT COUNT(*) FROM books";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting total book titles", e);
        }
        return 0;
    }

    /**
     * Total available copies currently in library.
     */
    public int getAvailableCopiesCount() {
        String sql = "SELECT COALESCE(SUM(available_copies), 0) FROM books";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting available book copies", e);
        }
        return 0;
    }

    private Book mapResultSetToBook(ResultSet rs) throws SQLException {
        Book book = new Book();
        book.setBookId(rs.getInt("book_id"));
        book.setIsbn(rs.getString("isbn"));
        book.setTitle(rs.getString("title"));
        book.setAuthor(rs.getString("author"));
        book.setCategory(rs.getString("category"));
        book.setPublisher(rs.getString("publisher"));

        int pubYear = rs.getInt("publication_year");
        book.setPublicationYear(rs.wasNull() ? null : pubYear);

        book.setTotalCopies(rs.getInt("total_copies"));
        book.setAvailableCopies(rs.getInt("available_copies"));
        book.setCreatedAt(rs.getTimestamp("created_at"));
        return book;
    }
}
