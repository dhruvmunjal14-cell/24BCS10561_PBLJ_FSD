package com.booknest.dao;

import com.booknest.model.Admin;
import com.booknest.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * AdminDAO - Handles Admin login verification and database operations.
 * Student: Dhruv Munjal (24BCS10561)
 */
public class AdminDAO {

    // Authenticate admin by username and password (using BCrypt)
    public Admin authenticate(String username, String plainPassword) {
        if (username == null || plainPassword == null) {
            return null;
        }

        String sql = "SELECT admin_id, username, password_hash, full_name, email, created_at FROM admins WHERE username = ?";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, username.trim());
            rs = ps.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password_hash");
                // Check if plain password matches BCrypt hash
                if (DBConnection.checkPassword(plainPassword, storedHash)) {
                    Admin admin = new Admin();
                    admin.setAdminId(rs.getInt("admin_id"));
                    admin.setUsername(rs.getString("username"));
                    admin.setPasswordHash(storedHash);
                    admin.setFullName(rs.getString("full_name"));
                    admin.setEmail(rs.getString("email"));
                    admin.setCreatedAt(rs.getTimestamp("created_at"));
                    return admin;
                }
            }
        } catch (SQLException e) {
            System.err.println("Login error: " + e.getMessage());
        } finally {
            DBConnection.close(rs, ps, conn);
        }
        return null;
    }

    // Insert new admin (hashes password before storing)
    public boolean createAdmin(Admin admin) {
        String sql = "INSERT INTO admins (username, password_hash, full_name, email) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, admin.getUsername());
            ps.setString(2, DBConnection.hashPassword(admin.getPasswordHash()));
            ps.setString(3, admin.getFullName());
            ps.setString(4, admin.getEmail());

            int rows = ps.executeUpdate();
            if (rows > 0) {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    admin.setAdminId(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating admin: " + e.getMessage());
        } finally {
            DBConnection.close(rs, ps, conn);
        }
        return false;
    }
}
