package com.booknest.dao;

import com.booknest.config.DatabaseConfig;
import com.booknest.util.DBConnection;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import java.sql.Connection;
import java.sql.Statement;

/**
 * Base test class that initializes an in-memory H2 database in MySQL mode.
 * Creates the exact schema used by BookNest so that DAOs and business rules
 * can be tested thoroughly without requiring a running MySQL server.
 */
public abstract class BaseDAOTest {

    @BeforeAll
    public static void setupDatabaseConfiguration() {
        // Configure DBConnection to use in-memory H2 in MySQL compatibility mode
        DatabaseConfig.setCustomConfig(
                "org.h2.Driver",
                "jdbc:h2:mem:booknest_test;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1",
                "sa",
                ""
        );
    }

    @BeforeEach
    public void initSchema() throws Exception {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Drop existing tables
            stmt.execute("DROP TABLE IF EXISTS issue_records");
            stmt.execute("DROP TABLE IF EXISTS books");
            stmt.execute("DROP TABLE IF EXISTS students");
            stmt.execute("DROP TABLE IF EXISTS admins");

            // Create Admins Table
            stmt.execute("CREATE TABLE admins (" +
                    "admin_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "password_hash VARCHAR(255) NOT NULL, " +
                    "full_name VARCHAR(100) NOT NULL, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")");

            // Create Books Table
            stmt.execute("CREATE TABLE books (" +
                    "book_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "isbn VARCHAR(20) NOT NULL UNIQUE, " +
                    "title VARCHAR(150) NOT NULL, " +
                    "author VARCHAR(100) NOT NULL, " +
                    "category VARCHAR(50) NOT NULL, " +
                    "publisher VARCHAR(100), " +
                    "publication_year INT, " +
                    "total_copies INT NOT NULL DEFAULT 1, " +
                    "available_copies INT NOT NULL DEFAULT 1, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")");

            // Create Students Table
            stmt.execute("CREATE TABLE students (" +
                    "student_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_code VARCHAR(30) NOT NULL UNIQUE, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "email VARCHAR(100) NOT NULL UNIQUE, " +
                    "phone VARCHAR(20), " +
                    "department VARCHAR(50) NOT NULL, " +
                    "semester INT NOT NULL, " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")");

            // Create Issue Records Table
            stmt.execute("CREATE TABLE issue_records (" +
                    "issue_id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "book_id INT NOT NULL, " +
                    "student_id INT NOT NULL, " +
                    "issue_date DATE NOT NULL, " +
                    "due_date DATE NOT NULL, " +
                    "return_date DATE DEFAULT NULL, " +
                    "fine_amount DECIMAL(8,2) DEFAULT 0.00, " +
                    "status VARCHAR(20) NOT NULL DEFAULT 'ISSUED', " +
                    "remarks VARCHAR(255), " +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "FOREIGN KEY (book_id) REFERENCES books(book_id), " +
                    "FOREIGN KEY (student_id) REFERENCES students(student_id)" +
                    ")");
        }
    }
}
