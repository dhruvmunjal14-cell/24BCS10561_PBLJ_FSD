package com.booknest.dao;

import com.booknest.model.Book;
import com.booknest.model.IssueRecord;
import com.booknest.model.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Validates all required PBL project business rules:
 * 1. Max 3 active issued books per student.
 * 2. Cannot issue if available copies == 0.
 * 3. Issuing decreases available copies by 1.
 * 4. Returning increases available copies by 1.
 * 5. Book cannot be returned twice.
 * 6. Invalid student and book IDs rejected.
 * 7. Duplicate ISBN and Student Code prevented.
 * 8. Fine calculation based on ₹2/day after 14-day loan.
 * 9. Atomicity and copy count consistency.
 */
public class BusinessRulesTest extends BaseDAOTest {

    private BookDAO bookDAO;
    private StudentDAO studentDAO;
    private IssueDAO issueDAO;

    private Book testBookA;
    private Book testBookB;
    private Book singleCopyBook;
    private Student testStudent;

    @BeforeEach
    public void setupSampleData() throws SQLException {
        bookDAO = new BookDAO();
        studentDAO = new StudentDAO();
        issueDAO = new IssueDAO();

        testBookA = new Book("978-0132350884", "Clean Code", "Robert C. Martin", "SE", "Prentice", 2008, 5, 5);
        bookDAO.addBook(testBookA);

        testBookB = new Book("978-0262033848", "Introduction to Algorithms", "Cormen", "CS", "MIT", 2009, 2, 2);
        bookDAO.addBook(testBookB);

        singleCopyBook = new Book("978-0000000001", "Rare First Edition", "Author X", "Rare", "Press", 2020, 1, 1);
        bookDAO.addBook(singleCopyBook);

        testStudent = new Student("CS2023001", "Dhruv Munjal", "dhruv@college.edu", "9876543210", "CS", 5);
        studentDAO.addStudent(testStudent);
    }

    @Test
    public void testRule3And4_IssueDecrementsAndReturnIncrementsCopies() throws SQLException {
        int initialAvail = testBookA.getAvailableCopies(); // 5

        LocalDate issueDate = LocalDate.now();
        LocalDate dueDate = issueDate.plusDays(14);

        // Issue book
        int issueId = issueDAO.issueBook(testBookA.getBookId(), testStudent.getStudentId(), issueDate, dueDate, "Test issue");
        assertTrue(issueId > 0);

        // Verify available copies decreased by 1
        Book afterIssue = bookDAO.getBookById(testBookA.getBookId());
        assertEquals(initialAvail - 1, afterIssue.getAvailableCopies(), "Available copies must decrease by 1 upon issue");

        // Return book
        BigDecimal fine = issueDAO.returnBook(issueId, issueDate.plusDays(5), "Returned on time");
        assertEquals(new BigDecimal("0.00"), fine, "No fine for return within 14 days");

        // Verify available copies increased back
        Book afterReturn = bookDAO.getBookById(testBookA.getBookId());
        assertEquals(initialAvail, afterReturn.getAvailableCopies(), "Available copies must increment by 1 upon return");
    }

    @Test
    public void testRule1_MaxThreeActiveBooksPerStudent() throws SQLException {
        // Create 3 additional books
        Book b1 = new Book("ISBN-1", "Book 1", "Author", "CS", "P", 2021, 2, 2);
        Book b2 = new Book("ISBN-2", "Book 2", "Author", "CS", "P", 2021, 2, 2);
        Book b3 = new Book("ISBN-3", "Book 3", "Author", "CS", "P", 2021, 2, 2);
        Book b4 = new Book("ISBN-4", "Book 4", "Author", "CS", "P", 2021, 2, 2);

        bookDAO.addBook(b1);
        bookDAO.addBook(b2);
        bookDAO.addBook(b3);
        bookDAO.addBook(b4);

        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        // Student borrows 3 books
        int i1 = issueDAO.issueBook(b1.getBookId(), testStudent.getStudentId(), today, due, null);
        int i2 = issueDAO.issueBook(b2.getBookId(), testStudent.getStudentId(), today, due, null);
        int i3 = issueDAO.issueBook(b3.getBookId(), testStudent.getStudentId(), today, due, null);

        assertTrue(i1 > 0 && i2 > 0 && i3 > 0);
        assertEquals(3, studentDAO.getActiveIssuesCount(testStudent.getStudentId()));

        // Attempting to borrow a 4th book must fail
        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            issueDAO.issueBook(b4.getBookId(), testStudent.getStudentId(), today, due, null);
        }, "Student cannot borrow more than 3 active books");

        assertTrue(ex.getMessage().contains("maximum borrowing limit"));

        // If student returns one book, they should be able to borrow again
        issueDAO.returnBook(i1, today, "Returned one book");
        assertEquals(2, studentDAO.getActiveIssuesCount(testStudent.getStudentId()));

        int i4 = issueDAO.issueBook(b4.getBookId(), testStudent.getStudentId(), today, due, "Now allowed");
        assertTrue(i4 > 0);
    }

    @Test
    public void testRule2_CannotIssueOutOfStockBook() throws SQLException {
        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        // Single copy book has 1 available copy
        assertEquals(1, singleCopyBook.getAvailableCopies());

        // First issue succeeds
        int issueId = issueDAO.issueBook(singleCopyBook.getBookId(), testStudent.getStudentId(), today, due, null);
        assertTrue(issueId > 0);

        Book updated = bookDAO.getBookById(singleCopyBook.getBookId());
        assertEquals(0, updated.getAvailableCopies(), "Available copies must now be 0");

        // Create second student
        Student student2 = new Student("IT2023002", "Second Student", "sec@college.edu", "12345", "IT", 4);
        studentDAO.addStudent(student2);

        // Second issue must fail because available copies == 0
        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            issueDAO.issueBook(singleCopyBook.getBookId(), student2.getStudentId(), today, due, null);
        }, "Issuing out of stock book must fail");

        assertTrue(ex.getMessage().contains("out of stock"));
    }

    @Test
    public void testRule5_CannotReturnTwice() throws SQLException {
        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        int issueId = issueDAO.issueBook(testBookA.getBookId(), testStudent.getStudentId(), today, due, null);
        assertTrue(issueId > 0);

        // First return succeeds
        issueDAO.returnBook(issueId, today, "First return");

        // Second return must fail
        IllegalStateException ex = assertThrows(IllegalStateException.class, () -> {
            issueDAO.returnBook(issueId, today, "Second return attempt");
        }, "Returning a book twice must fail");

        assertTrue(ex.getMessage().contains("already been returned"));
    }

    @Test
    public void testRule6_InvalidStudentOrBookRejected() {
        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        // Invalid student ID 99999
        assertThrows(IllegalArgumentException.class, () -> {
            issueDAO.issueBook(testBookA.getBookId(), 99999, today, due, null);
        });

        // Invalid book ID 88888
        assertThrows(IllegalStateException.class, () -> {
            issueDAO.issueBook(88888, testStudent.getStudentId(), today, due, null);
        });
    }

    @Test
    public void testRule8_OverdueFineCalculation() throws SQLException {
        LocalDate issueDate = LocalDate.of(2026, 10, 1);
        LocalDate dueDate = LocalDate.of(2026, 10, 15); // 14-day loan

        int issueId = issueDAO.issueBook(testBookA.getBookId(), testStudent.getStudentId(), issueDate, dueDate, null);
        assertTrue(issueId > 0);

        // Returned on 2026-10-20 (5 days overdue) -> 5 * ₹2.00 = ₹10.00 fine
        LocalDate actualReturnDate = LocalDate.of(2026, 10, 20);
        BigDecimal fine = issueDAO.returnBook(issueId, actualReturnDate, "Late return with fine");

        assertEquals(new BigDecimal("10.00"), fine, "Fine should be ₹10.00 for 5 overdue days");

        IssueRecord record = issueDAO.getIssueById(issueId);
        assertNotNull(record);
        assertEquals("RETURNED", record.getStatus());
        assertEquals(new BigDecimal("10.00"), record.getFineAmount());
        assertEquals(actualReturnDate, record.getReturnDate());
    }
}
