package com.booknest.dao;

import com.booknest.model.Student;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class StudentDAOTest extends BaseDAOTest {

    @Test
    public void testAddAndRetrieveStudent() throws SQLException {
        StudentDAO studentDAO = new StudentDAO();

        Student student = new Student("CS2023001", "Dhruv Munjal", "dhruv@college.edu",
                "9876543210", "Computer Science", 5);

        boolean added = studentDAO.addStudent(student);
        assertTrue(added);
        assertTrue(student.getStudentId() > 0);

        Student fetched = studentDAO.getStudentById(student.getStudentId());
        assertNotNull(fetched);
        assertEquals("CS2023001", fetched.getStudentCode());
        assertEquals("Dhruv Munjal", fetched.getName());
        assertEquals(5, fetched.getSemester());

        Student byCode = studentDAO.findByStudentCode("cs2023001");
        assertNotNull(byCode);
        assertEquals(student.getStudentId(), byCode.getStudentId());
    }

    @Test
    public void testPreventDuplicateStudentCode() throws SQLException {
        StudentDAO studentDAO = new StudentDAO();

        Student s1 = new Student("CS2023002", "Alice Johnson", "alice@college.edu", "1111111111", "CS", 5);
        assertTrue(studentDAO.addStudent(s1));

        Student s2 = new Student("CS2023002", "Bob Smith", "bob@college.edu", "2222222222", "CS", 5);
        assertThrows(SQLException.class, () -> studentDAO.addStudent(s2),
                "Duplicate student ID/roll number must be rejected");
    }

    @Test
    public void testSearchStudents() throws SQLException {
        StudentDAO studentDAO = new StudentDAO();

        studentDAO.addStudent(new Student("IT2023010", "Rahul Sharma", "rahul@college.edu", "3333333333", "Information Technology", 4));
        studentDAO.addStudent(new Student("EC2023020", "Priya Patel", "priya@college.edu", "4444444444", "Electronics", 3));

        List<Student> results = studentDAO.searchStudents("rahul");
        assertEquals(1, results.size());
        assertEquals("Rahul Sharma", results.get(0).getName());

        List<Student> itResults = studentDAO.searchStudents("Information Technology");
        assertEquals(1, itResults.size());
    }
}
