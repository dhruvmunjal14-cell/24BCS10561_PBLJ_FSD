package com.booknest.dao;

import com.booknest.model.Book;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BookDAOTest extends BaseDAOTest {

    @Test
    public void testAddAndRetrieveBook() throws SQLException {
        BookDAO bookDAO = new BookDAO();

        Book book = new Book("978-0132350884", "Clean Code", "Robert C. Martin",
                "Software Engineering", "Prentice Hall", 2008, 5, 5);

        boolean added = bookDAO.addBook(book);
        assertTrue(added);
        assertTrue(book.getBookId() > 0);

        Book fetched = bookDAO.getBookById(book.getBookId());
        assertNotNull(fetched);
        assertEquals("Clean Code", fetched.getTitle());
        assertEquals(5, fetched.getAvailableCopies());
        assertEquals(5, fetched.getTotalCopies());

        Book byIsbn = bookDAO.findByIsbn("978-0132350884");
        assertNotNull(byIsbn);
        assertEquals(book.getBookId(), byIsbn.getBookId());
    }

    @Test
    public void testPreventDuplicateIsbn() throws SQLException {
        BookDAO bookDAO = new BookDAO();

        Book book1 = new Book("978-0262033848", "Introduction to Algorithms", "Thomas H. Cormen",
                "Computer Science", "MIT Press", 2009, 3, 3);
        assertTrue(bookDAO.addBook(book1));

        Book book2 = new Book("978-0262033848", "Duplicate Cormen", "Thomas H. Cormen",
                "Computer Science", "MIT Press", 2009, 2, 2);

        assertThrows(SQLException.class, () -> bookDAO.addBook(book2),
                "Adding book with existing ISBN must throw SQLException");
    }

    @Test
    public void testSearchBooks() throws SQLException {
        BookDAO bookDAO = new BookDAO();

        bookDAO.addBook(new Book("978-1", "Design Patterns", "Erich Gamma", "Software Engineering", "Addison-Wesley", 1994, 2, 2));
        bookDAO.addBook(new Book("978-2", "Operating System Concepts", "Abraham Silberschatz", "OS", "Wiley", 2018, 4, 4));

        List<Book> searchResults = bookDAO.searchBooks("patterns");
        assertEquals(1, searchResults.size());
        assertEquals("Design Patterns", searchResults.get(0).getTitle());

        List<Book> authorResults = bookDAO.searchBooks("silberschatz");
        assertEquals(1, authorResults.size());
        assertEquals("Operating System Concepts", authorResults.get(0).getTitle());
    }

    @Test
    public void testDeleteBook() throws SQLException {
        BookDAO bookDAO = new BookDAO();

        Book book = new Book("978-999", "Temporary Book", "Test Author", "Testing", "Test Press", 2024, 1, 1);
        bookDAO.addBook(book);

        boolean deleted = bookDAO.deleteBook(book.getBookId());
        assertTrue(deleted);
        assertNull(bookDAO.getBookById(book.getBookId()));
    }
}
