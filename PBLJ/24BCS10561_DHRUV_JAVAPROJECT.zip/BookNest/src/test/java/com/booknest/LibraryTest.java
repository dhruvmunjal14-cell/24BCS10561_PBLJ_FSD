package com.booknest;

import com.booknest.dao.AdminDAO;
import com.booknest.dao.BookDAO;
import com.booknest.dao.IssueDAO;
import com.booknest.dao.StudentDAO;
import com.booknest.model.Admin;
import com.booknest.model.Book;
import com.booknest.model.IssueRecord;
import com.booknest.model.Student;
import com.booknest.util.DBConnection;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

/**
 * LibraryTest - Unit and Integration Tests for BookNest PBL Project.
 * Student: Dhruv Munjal (24BCS10561)
 */
public class LibraryTest {

    private BookDAO bookDAO;
    private StudentDAO studentDAO;
    private IssueDAO issueDAO;
    private AdminDAO adminDAO;

    @BeforeAll
    public static void setupTestDatabase() {
        // Use in-memory H2 in MySQL mode so tests run cleanly anywhere
        DBConnection.setTestConfig(
                "org.h2.Driver",
                "jdbc:h2:mem:booknest_test;MODE=MySQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1",
                "sa",
                ""
        );
    }

    @BeforeEach
    public void createSchema() throws SQLException {
        bookDAO = new BookDAO();
        studentDAO = new StudentDAO();
        issueDAO = new IssueDAO();
        adminDAO = new AdminDAO();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute("DROP TABLE IF EXISTS issue_records");
            stmt.execute("DROP TABLE IF EXISTS books");
            stmt.execute("DROP TABLE IF EXISTS students");
            stmt.execute("DROP TABLE IF EXISTS admins");

            stmt.execute("CREATE TABLE admins (admin_id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            stmt.execute("CREATE TABLE books (book_id INT AUTO_INCREMENT PRIMARY KEY, isbn VARCHAR(20) NOT NULL UNIQUE, title VARCHAR(150) NOT NULL, author VARCHAR(100) NOT NULL, category VARCHAR(50), publisher VARCHAR(100), publication_year INT, total_copies INT NOT NULL DEFAULT 1, available_copies INT NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            stmt.execute("CREATE TABLE students (student_id INT AUTO_INCREMENT PRIMARY KEY, student_code VARCHAR(30) NOT NULL UNIQUE, name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL UNIQUE, phone VARCHAR(20), department VARCHAR(50) NOT NULL, semester INT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
            stmt.execute("CREATE TABLE issue_records (issue_id INT AUTO_INCREMENT PRIMARY KEY, book_id INT NOT NULL, student_id INT NOT NULL, issue_date DATE NOT NULL, due_date DATE NOT NULL, return_date DATE, fine_amount DECIMAL(8,2) DEFAULT 0.00, status VARCHAR(20) NOT NULL DEFAULT 'ISSUED', remarks VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (book_id) REFERENCES books(book_id), FOREIGN KEY (student_id) REFERENCES students(student_id))");
        }
    }

    @Test
    public void testAdminLogin() {
        Admin admin = new Admin("admin", "admin123", "Head Librarian", "admin@booknest.edu");
        assertTrue(adminDAO.createAdmin(admin));

        // Correct password
        Admin loggedIn = adminDAO.authenticate("admin", "admin123");
        assertNotNull(loggedIn);
        assertEquals("Head Librarian", loggedIn.getFullName());

        // Wrong password
        assertNull(adminDAO.authenticate("admin", "wrongpassword"));
    }

    @Test
    public void testBookManagement() throws SQLException {
        Book book = new Book("978-0132350884", "Clean Code", "Robert C. Martin", "Software", "Prentice", 2008, 5, 5);
        assertTrue(bookDAO.addBook(book));

        Book fetched = bookDAO.getBookById(book.getBookId());
        assertNotNull(fetched);
        assertEquals("Clean Code", fetched.getTitle());
        assertEquals(5, fetched.getAvailableCopies());

        // Duplicate ISBN rejection
        Book duplicate = new Book("978-0132350884", "Another Copy", "Author", "SE", "P", 2020, 1, 1);
        assertThrows(SQLException.class, () -> bookDAO.addBook(duplicate));
    }

    @Test
    public void testStudentManagement() throws SQLException {
        Student s = new Student("24BCS10561", "Dhruv Munjal", "dhruv@college.edu", "9876543210", "Computer Science", 5);
        assertTrue(studentDAO.addStudent(s));

        Student fetched = studentDAO.getStudentById(s.getStudentId());
        assertNotNull(fetched);
        assertEquals("24BCS10561", fetched.getStudentCode());

        // Duplicate roll number rejection
        Student duplicate = new Student("24BCS10561", "Other Student", "other@college.edu", "11111", "CS", 5);
        assertThrows(SQLException.class, () -> studentDAO.addStudent(duplicate));
    }

    @Test
    public void testIssueAndReturnBook() throws SQLException {
        Book book = new Book("978-1", "Test Book", "Author", "CS", "P", 2021, 3, 3);
        bookDAO.addBook(book);

        Student student = new Student("24BCS10561", "Dhruv Munjal", "dhruv@college.edu", "9876543210", "CS", 5);
        studentDAO.addStudent(student);

        LocalDate issueDate = LocalDate.now();
        LocalDate dueDate = issueDate.plusDays(14);

        // Issue book
        int issueId = issueDAO.issueBook(book.getBookId(), student.getStudentId(), issueDate, dueDate, "Test");
        assertTrue(issueId > 0);

        // Verify available copies decreased by 1 (3 -> 2)
        Book afterIssue = bookDAO.getBookById(book.getBookId());
        assertEquals(2, afterIssue.getAvailableCopies());

        // Return book within 14 days -> fine = 0.00
        BigDecimal fine = issueDAO.returnBook(issueId, issueDate.plusDays(5), "Returned on time");
        assertEquals(new BigDecimal("0.00"), fine);

        // Verify available copies increased back to 3
        Book afterReturn = bookDAO.getBookById(book.getBookId());
        assertEquals(3, afterReturn.getAvailableCopies());
    }

    @Test
    public void testMaxThreeBooksLimit() throws SQLException {
        Student student = new Student("24BCS10561", "Dhruv", "dhruv@college.edu", "9876543210", "CS", 5);
        studentDAO.addStudent(student);

        Book b1 = new Book("ISBN-1", "Book 1", "Author", "CS", "P", 2021, 2, 2);
        Book b2 = new Book("ISBN-2", "Book 2", "Author", "CS", "P", 2021, 2, 2);
        Book b3 = new Book("ISBN-3", "Book 3", "Author", "CS", "P", 2021, 2, 2);
        Book b4 = new Book("ISBN-4", "Book 4", "Author", "CS", "P", 2021, 2, 2);
        bookDAO.addBook(b1);
        bookDAO.addBook(b2);
        bookDAO.addBook(b3);
        bookDAO.addBook(b4);

        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        issueDAO.issueBook(b1.getBookId(), student.getStudentId(), today, due, null);
        issueDAO.issueBook(b2.getBookId(), student.getStudentId(), today, due, null);
        issueDAO.issueBook(b3.getBookId(), student.getStudentId(), today, due, null);

        // 4th issue attempt must throw error (Rule: Max 3 books per student)
        assertThrows(IllegalStateException.class, () -> {
            issueDAO.issueBook(b4.getBookId(), student.getStudentId(), today, due, null);
        });
    }

    @Test
    public void testOutOfStockRejection() throws SQLException {
        Book rareBook = new Book("ISBN-RARE", "Rare Book", "Author", "Rare", "P", 2020, 1, 1);
        bookDAO.addBook(rareBook);

        Student s1 = new Student("S1", "Student 1", "s1@college.edu", "111", "CS", 5);
        Student s2 = new Student("S2", "Student 2", "s2@college.edu", "222", "CS", 5);
        studentDAO.addStudent(s1);
        studentDAO.addStudent(s2);

        LocalDate today = LocalDate.now();
        LocalDate due = today.plusDays(14);

        issueDAO.issueBook(rareBook.getBookId(), s1.getStudentId(), today, due, null);

        // Second issue must fail because available copies == 0
        assertThrows(IllegalStateException.class, () -> {
            issueDAO.issueBook(rareBook.getBookId(), s2.getStudentId(), today, due, null);
        });
    }

    @Test
    public void testOverdueFineCalculation() throws SQLException {
        Book book = new Book("ISBN-FINE", "Fine Test Book", "Author", "CS", "P", 2021, 2, 2);
        bookDAO.addBook(book);

        Student student = new Student("24BCS10561", "Dhruv", "dhruv@college.edu", "9876543210", "CS", 5);
        studentDAO.addStudent(student);

        LocalDate issueDate = LocalDate.of(2026, 10, 1);
        LocalDate dueDate = LocalDate.of(2026, 10, 15); // 14-day loan

        int issueId = issueDAO.issueBook(book.getBookId(), student.getStudentId(), issueDate, dueDate, null);

        // Returned on 2026-10-20 (5 days overdue) -> 5 * Rs 2.00 = Rs 10.00
        BigDecimal fine = issueDAO.returnBook(issueId, LocalDate.of(2026, 10, 20), "Late");
        assertEquals(new BigDecimal("10.00"), fine);

        IssueRecord record = issueDAO.getIssueById(issueId);
        assertNotNull(record);
        assertEquals("RETURNED", record.getStatus());
        assertEquals(new BigDecimal("10.00"), record.getFineAmount());
    }
}
