package com.booknest.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PasswordUtilTest {

    @Test
    public void testHashAndVerifyPassword() {
        String rawPassword = "admin123";
        String hash = PasswordUtil.hashPassword(rawPassword);

        assertNotNull(hash);
        assertTrue(hash.startsWith("$2a$10$"), "BCrypt hash should start with $2a$10$");
        assertEquals(60, hash.length(), "BCrypt hash length should be 60 characters");

        assertTrue(PasswordUtil.checkPassword("admin123", hash), "Password should verify successfully");
        assertFalse(PasswordUtil.checkPassword("wrongpass", hash), "Wrong password should be rejected");
        assertFalse(PasswordUtil.checkPassword("", hash), "Empty password should be rejected");
        assertFalse(PasswordUtil.checkPassword(null, hash), "Null password should be rejected");
    }

    @Test
    public void testSha256Hex() {
        String hash = PasswordUtil.sha256Hex("admin123");
        assertNotNull(hash);
        assertEquals(64, hash.length());
        assertTrue(PasswordUtil.checkPassword("admin123", hash));
    }
}
