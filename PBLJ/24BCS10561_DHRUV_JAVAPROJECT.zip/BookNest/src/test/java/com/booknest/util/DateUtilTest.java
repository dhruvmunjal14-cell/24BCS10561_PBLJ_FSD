package com.booknest.util;

import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class DateUtilTest {

    @Test
    public void testDueDateCalculation() {
        LocalDate issueDate = LocalDate.of(2026, 11, 1);
        LocalDate dueDate = DateUtil.calculateDueDate(issueDate);
        assertEquals(LocalDate.of(2026, 11, 15), dueDate, "Due date should be 14 days after issue date");
    }

    @Test
    public void testOverdueDaysAndFineCalculation() {
        LocalDate dueDate = LocalDate.of(2026, 11, 10);

        // Returned on time (same day) -> 0 fine
        assertEquals(0, DateUtil.calculateOverdueDays(dueDate, LocalDate.of(2026, 11, 10)));
        assertEquals(new BigDecimal("0.00"), DateUtil.calculateFine(dueDate, LocalDate.of(2026, 11, 10)));

        // Returned early -> 0 fine
        assertEquals(0, DateUtil.calculateOverdueDays(dueDate, LocalDate.of(2026, 11, 5)));
        assertEquals(new BigDecimal("0.00"), DateUtil.calculateFine(dueDate, LocalDate.of(2026, 11, 5)));

        // Returned 3 days late -> ₹6.00 fine (3 * ₹2.00)
        assertEquals(3, DateUtil.calculateOverdueDays(dueDate, LocalDate.of(2026, 11, 13)));
        assertEquals(new BigDecimal("6.00"), DateUtil.calculateFine(dueDate, LocalDate.of(2026, 11, 13)));

        // Returned 10 days late -> ₹20.00 fine
        assertEquals(10, DateUtil.calculateOverdueDays(dueDate, LocalDate.of(2026, 11, 20)));
        assertEquals(new BigDecimal("20.00"), DateUtil.calculateFine(dueDate, LocalDate.of(2026, 11, 20)));
    }

    @Test
    public void testDateFormattingAndParsing() {
        LocalDate date = LocalDate.of(2026, 11, 14);
        assertEquals("2026-11-14", DateUtil.formatIso(date));
        assertEquals("14 Nov 2026", DateUtil.formatDisplay(date));
        assertEquals(date, DateUtil.parseIso("2026-11-14"));
    }
}
