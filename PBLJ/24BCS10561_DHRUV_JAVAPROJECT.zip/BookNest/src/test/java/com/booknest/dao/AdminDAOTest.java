package com.booknest.dao;

import com.booknest.model.Admin;
import com.booknest.util.PasswordUtil;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AdminDAOTest extends BaseDAOTest {

    @Test
    public void testCreateAndAuthenticateAdmin() {
        AdminDAO adminDAO = new AdminDAO();

        Admin admin = new Admin();
        admin.setUsername("admin");
        admin.setPasswordHash("admin123");
        admin.setFullName("System Administrator");
        admin.setEmail("admin@booknest.edu");

        boolean created = adminDAO.createAdmin(admin);
        assertTrue(created, "Admin should be created successfully");
        assertTrue(admin.getAdminId() > 0, "Admin ID should be generated");

        // Authenticate with correct credentials
        Admin auth = adminDAO.authenticate("admin", "admin123");
        assertNotNull(auth, "Authentication should succeed with valid credentials");
        assertEquals("System Administrator", auth.getFullName());

        // Authenticate with incorrect password
        Admin failedAuth = adminDAO.authenticate("admin", "wrongpassword");
        assertNull(failedAuth, "Authentication should fail with wrong password");

        // Authenticate with non-existent username
        Admin notFound = adminDAO.authenticate("ghost", "admin123");
        assertNull(notFound, "Authentication should fail with unknown username");
    }
}
