-- ==============================================================================
-- BookNest: Smart Library Management System
-- Database Schema and Sample Data Script
-- Compatible with MySQL 5.7+ / 8.0+ / MariaDB
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS booknest
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE booknest;

-- Disable foreign key checks during schema re-creation
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS issue_records;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS admins;

SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------------------------
-- 1. Table: admins
-- Stores library administrator accounts with BCrypt-hashed passwords.
-- ------------------------------------------------------------------------------
CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 2. Table: books
-- Tracks book catalog, editions, total physical copies, and available copies.
-- ------------------------------------------------------------------------------
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    author VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL DEFAULT 'General',
    publisher VARCHAR(100),
    publication_year INT,
    total_copies INT NOT NULL DEFAULT 1,
    available_copies INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_copies CHECK (available_copies >= 0 AND available_copies <= total_copies)
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 3. Table: students
-- Stores enrolled student members, enrollment roll numbers, and contact details.
-- ------------------------------------------------------------------------------
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_code VARCHAR(30) NOT NULL UNIQUE, -- College Roll No / Enrollment ID
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(50) NOT NULL,
    semester INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 4. Table: issue_records
-- Records book loans, return dates, overdue fines, and borrowing history.
-- ------------------------------------------------------------------------------
CREATE TABLE issue_records (
    issue_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    student_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE DEFAULT NULL,
    fine_amount DECIMAL(8,2) DEFAULT 0.00,
    status ENUM('ISSUED', 'RETURNED') NOT NULL DEFAULT 'ISSUED',
    remarks VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- Performance Indexes
-- ------------------------------------------------------------------------------
CREATE INDEX idx_books_isbn ON books(isbn);
CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_students_code ON students(student_code);
CREATE INDEX idx_issues_status ON issue_records(status);
CREATE INDEX idx_issues_due ON issue_records(due_date);

-- ==============================================================================
-- SAMPLE DATA POPULATION
-- ==============================================================================

-- 1. Insert Default Administrator (Username: admin, Password: admin123)
-- BCrypt Workload: 10 rounds
INSERT INTO admins (username, password_hash, full_name, email)
VALUES (
    'admin',
    '$2a$10$iTDO4xfHqSpXaG49tPrteuOldyXkm72c8OFxEoGOtcNzHQPx0dK9q',
    'Head Librarian',
    'admin@booknest.edu'
);

-- 2. Insert Sample Core Computer Science Books
-- Note: available_copies initially set to reflect the issued books below
INSERT INTO books (isbn, title, author, category, publisher, publication_year, total_copies, available_copies) VALUES
('978-0132350884', 'Clean Code: A Handbook of Agile Software Craftsmanship', 'Robert C. Martin', 'Software Engineering', 'Prentice Hall', 2008, 5, 4),
('978-0262033848', 'Introduction to Algorithms (4th Edition)', 'Thomas H. Cormen', 'Data Structures', 'MIT Press', 2022, 4, 3),
('978-0078022159', 'Database System Concepts (7th Edition)', 'Abraham Silberschatz', 'Database Systems', 'McGraw-Hill', 2019, 6, 5),
('978-0133594140', 'Computer Networks (5th Edition)', 'Andrew S. Tanenbaum', 'Computer Networks', 'Pearson', 2011, 4, 4),
('978-1118063330', 'Operating System Concepts (10th Edition)', 'Abraham Silberschatz', 'Operating Systems', 'Wiley', 2018, 5, 4),
('978-0134685991', 'Effective Java (3rd Edition)', 'Joshua Bloch', 'Software Engineering', 'Addison-Wesley', 2017, 3, 3),
('978-0201633610', 'Design Patterns: Elements of Reusable Object-Oriented Software', 'Erich Gamma', 'Software Engineering', 'Addison-Wesley', 1994, 3, 3),
('978-0136042594', 'Artificial Intelligence: A Modern Approach (4th Edition)', 'Stuart Russell', 'Artificial Intelligence', 'Pearson', 2020, 4, 4),
('978-1449373320', 'Designing Data-Intensive Applications', 'Martin Kleppmann', 'Database Systems', 'O''Reilly Media', 2017, 4, 4),
('978-0131103627', 'The C Programming Language (2nd Edition)', 'Brian W. Kernighan', 'Computer Science', 'Prentice Hall', 1988, 5, 5);

-- 3. Insert Sample Students
INSERT INTO students (student_code, name, email, phone, department, semester) VALUES
('24BCS10561', 'Dhruv Munjal', 'dhruv.munjal@college.edu', '9876543210', 'Computer Science & Engineering', 5),
('24BCS10562', 'Aarav Sharma', 'aarav.sharma@college.edu', '9812345678', 'Computer Science & Engineering', 5),
('24BIT10215', 'Ananya Gupta', 'ananya.gupta@college.edu', '9823456789', 'Information Technology', 5),
('24BIT10222', 'Rohan Verma', 'rohan.verma@college.edu', '9834567890', 'Information Technology', 3),
('24BEC10108', 'Sneha Iyer', 'sneha.iyer@college.edu', '9845678901', 'Electronics & Communication', 5),
('24BME10330', 'Karan Patel', 'karan.patel@college.edu', '9856789012', 'Mechanical Engineering', 3);

-- 4. Insert Sample Transactions
-- Transaction 1: Active Loan on time (Dhruv borrowed Clean Code)
INSERT INTO issue_records (book_id, student_id, issue_date, due_date, return_date, fine_amount, status, remarks)
VALUES (1, 1, CURRENT_DATE - INTERVAL 3 DAY, CURRENT_DATE + INTERVAL 11 DAY, NULL, 0.00, 'ISSUED', 'PBL project study');

-- Transaction 2: Active Loan on time (Aarav borrowed Database System Concepts)
INSERT INTO issue_records (book_id, student_id, issue_date, due_date, return_date, fine_amount, status, remarks)
VALUES (3, 2, CURRENT_DATE - INTERVAL 7 DAY, CURRENT_DATE + INTERVAL 7 DAY, NULL, 0.00, 'ISSUED', 'Midterm preparation');

-- Transaction 3: Overdue Loan (Ananya borrowed Introduction to Algorithms, due 4 days ago)
-- Overdue fine accumulated: 4 days * ₹2 = ₹8.00
INSERT INTO issue_records (book_id, student_id, issue_date, due_date, return_date, fine_amount, status, remarks)
VALUES (2, 3, CURRENT_DATE - INTERVAL 18 DAY, CURRENT_DATE - INTERVAL 4 DAY, NULL, 0.00, 'ISSUED', 'Algorithm contest preparation');

-- Transaction 4: Returned Loan with fine paid (Rohan returned Operating Systems 3 days late)
-- Fine collected: 3 days * ₹2 = ₹6.00
INSERT INTO issue_records (book_id, student_id, issue_date, due_date, return_date, fine_amount, status, remarks)
VALUES (5, 4, CURRENT_DATE - INTERVAL 25 DAY, CURRENT_DATE - INTERVAL 11 DAY, CURRENT_DATE - INTERVAL 8 DAY, 6.00, 'RETURNED', 'Returned late - fine collected');
